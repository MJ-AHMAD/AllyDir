"use client"

import Link from "next/link"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useMediaQuery } from "@/hooks/use-media-query"

export default function SupportPage() {
  const [paymentMethod, setPaymentMethod] = useState("bank")
  const isMobile = useMediaQuery("(max-width: 768px)")

  // Handle tab change
  const handleTabChange = (value: string) => {
    setPaymentMethod(value)
  }

  // Render payment details based on selected method
  const renderPaymentDetails = () => {
    switch (paymentMethod) {
      case "bank":
        return (
          <div className="space-y-4">
            <div className="bg-green-50 p-4 rounded-md">
              <h3 className="font-semibold text-lg mb-2">USD Account</h3>
              <div className="space-y-1 text-sm">
                <p>
                  <span className="font-medium">A/C No:</span> 111869395099
                </p>
                <p>
                  <span className="font-medium">ABA Router no:</span> 103913434
                </p>
                <p>
                  <span className="font-medium">Bank:</span> Regent Bank, USA
                </p>
              </div>
            </div>

            <div className="bg-green-50 p-4 rounded-md">
              <h3 className="font-semibold text-lg mb-2">BDT Account</h3>
              <div className="space-y-1 text-sm">
                <p>
                  <span className="font-medium">A/C No:</span> 1058614360001
                </p>
                <p>
                  <span className="font-medium">Bank:</span> Brac Bank, BD
                </p>
              </div>
            </div>
          </div>
        )

      case "mobile":
        return (
          <div className="space-y-4">
            <div className="bg-green-50 p-4 rounded-md">
              <h3 className="font-semibold text-lg mb-2">bKash</h3>
              <div className="space-y-1 text-sm">
                <p>
                  <span className="font-medium">A/C No:</span> 01920082926
                </p>
                <p>
                  <span className="font-medium">Type:</span> Personal
                </p>
              </div>
            </div>

            <div className="bg-green-50 p-4 rounded-md">
              <h3 className="font-semibold text-lg mb-2">Nagad</h3>
              <div className="space-y-1 text-sm">
                <p>
                  <span className="font-medium">A/C No:</span> 01788856628
                </p>
                <p>
                  <span className="font-medium">Type:</span> Personal
                </p>
              </div>
            </div>

            <div className="bg-green-50 p-4 rounded-md">
              <h3 className="font-semibold text-lg mb-2">Rocket</h3>
              <div className="space-y-1 text-sm">
                <p>
                  <span className="font-medium">A/C No:</span> 01920082926-6
                </p>
                <p>
                  <span className="font-medium">Type:</span> Personal
                </p>
              </div>
            </div>
          </div>
        )

      case "card":
        return (
          <div className="space-y-4">
            <div className="bg-green-50 p-4 rounded-md">
              <h3 className="font-semibold text-lg mb-2">PayPal</h3>
              <div className="space-y-1 text-sm">
                <p>
                  <span className="font-medium">Email:</span> mjahmad2024@outlook.com
                </p>
              </div>
            </div>

            <div className="text-center py-4">
              <Button className="bg-green-600 hover:bg-green-700">
                <span className="mr-2">💳</span>
                Donate via Card
              </Button>
            </div>
          </div>
        )

      default:
        return null
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-3xl mx-auto">
        <div className="mb-8">
          <Button variant="ghost" asChild>
            <Link href="/">
              <span className="mr-2">←</span>
              Back to Home
            </Link>
          </Button>
        </div>

        <Card className="shadow-lg">
          <CardHeader className="bg-green-600 text-white text-center py-6 rounded-t-lg">
            <CardTitle className="text-2xl">Support Options</CardTitle>
            <p className="mt-2">Choose your preferred method to contribute</p>
          </CardHeader>

          <CardContent className="p-6">
            {isMobile ? (
              // Mobile view - Dropdown select
              <div className="space-y-6">
                <div className="mb-4">
                  <label htmlFor="payment-method" className="block text-sm font-medium mb-2">
                    Select Payment Method
                  </label>
                  <Select value={paymentMethod} onValueChange={setPaymentMethod}>
                    <SelectTrigger id="payment-method" className="w-full">
                      <SelectValue placeholder="Select payment method" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="bank">
                        <span className="mr-2">💵</span> Bank Transfer
                      </SelectItem>
                      <SelectItem value="mobile">
                        <span className="mr-2">📱</span> Mobile Banking
                      </SelectItem>
                      <SelectItem value="card">
                        <span className="mr-2">💳</span> Card/PayPal
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {renderPaymentDetails()}
              </div>
            ) : (
              // Desktop view - Tabs
              <Tabs defaultValue="bank" onValueChange={handleTabChange} className="space-y-6">
                <TabsList className="grid grid-cols-3 w-full">
                  <TabsTrigger value="bank">
                    <span className="mr-2">💵</span>
                    Bank Transfer
                  </TabsTrigger>
                  <TabsTrigger value="mobile">
                    <span className="mr-2">📱</span>
                    Mobile Banking
                  </TabsTrigger>
                  <TabsTrigger value="card">
                    <span className="mr-2">💳</span>
                    Card/PayPal
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="bank">{renderPaymentDetails()}</TabsContent>

                <TabsContent value="mobile">{renderPaymentDetails()}</TabsContent>

                <TabsContent value="card">{renderPaymentDetails()}</TabsContent>
              </Tabs>
            )}

            <div className="mt-8 text-center">
              <p className="text-gray-600">
                Your contribution, no matter how small, will make a significant difference in my life. Thank you for
                your kindness and generosity.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

