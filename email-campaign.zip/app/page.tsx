import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-3xl mx-auto">
        <Card className="shadow-lg">
          <CardHeader className="bg-green-600 text-white text-center py-8 rounded-t-lg">
            <div className="flex items-center justify-center mb-2">
              <span className="text-3xl mr-2">🤝</span>
              <h1 className="text-3xl font-bold">Your Support Can Help Me Regain My Health</h1>
            </div>
          </CardHeader>

          <CardContent className="p-6 sm:p-8 space-y-6">
            <div className="space-y-4">
              <p className="text-lg">Dear Brothers and Sisters!</p>

              <p>
                With a heavy heart, I share that I am currently suffering from a severe illness and have been living a
                solitary and difficult life for a long time. Both physically and mentally, I am shattered, and in this
                challenging time, I need your support.
              </p>

              <h3 className="text-xl font-semibold text-green-600 mt-6">Help Me</h3>

              <p>
                For the first time in my life, I am asking for financial assistance for myself. The burden of debt and
                the constant inhuman words from some people have left me feeling helpless. If you could support me by
                donating any amount
                <Link
                  href="https://v0-trusted-ally-website-ten.vercel.app/projects/techally-ventures"
                  className="text-green-600 hover:text-green-800 font-medium mx-1 underline"
                >
                  or by purchasing a product or service from me
                </Link>
                , it might help me regain a healthy and bright life.
              </p>

              <p>
                Your smallest contribution would be a huge blessing for me. Once I recover, I promise to deliver your
                service with the utmost efficiency and help you achieve your institutional success.
              </p>

              <div className="text-center py-4">
                <Button asChild className="bg-green-600 hover:bg-green-700 text-lg px-8 py-6 h-auto">
                  <Link href="/support">
                    <span className="mr-2">❤️</span>
                    Support Please
                  </Link>
                </Button>
              </div>

              <div className="mt-6">
                <p className="font-medium">Sincerely,</p>
                <div className="mt-2 bg-gray-50 p-4 rounded-md">
                  <p className="font-semibold">Md Jafor Ahmad</p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-2 text-sm">
                    <p>
                      <span className="font-medium">NID:</span> 3734108768
                    </p>
                    <p>
                      <span className="font-medium">Pass. no:</span> A02019678
                    </p>
                    <p>
                      <span className="font-medium">TIN:</span> 425092691933
                    </p>
                    <p>
                      <span className="font-medium">Mobile:</span> 017 25463886
                    </p>
                    <p>
                      <span className="font-medium">Email:</span> mjahmad2024@outlook.com
                    </p>
                    <p>
                      <span className="font-medium">Address:</span> Dhaka, Bangladesh
                    </p>
                  </div>
                </div>
              </div>

              <div className="w-full">
                <div className="float-left space-y-2 py-4">
                  <div>
                    <Link href="#" className="text-green-600 hover:text-green-800 block">
                      My Website
                    </Link>
                  </div>
                  <div>
                    <Link href="#" className="text-green-600 hover:text-green-800 block">
                      LinkedIn
                    </Link>
                  </div>
                  <div>
                    <Link href="#" className="text-green-600 hover:text-green-800 block">
                      GitHub
                    </Link>
                  </div>
                </div>
              </div>

              <div className="clear-both italic text-gray-600 border-l-4 border-green-500 pl-4 py-2 bg-green-50 mt-4">
                My goal is to make education an indispensable part of every child's life, enabling them to pursue their
                dreams and aspirations.
              </div>
            </div>
          </CardContent>

          <CardFooter className="bg-gray-100 px-6 py-4 text-center text-gray-600 text-sm rounded-b-lg">
            <p>Thank you for your kindness and consideration. Your support means the world to me.</p>
          </CardFooter>
        </Card>
      </div>
    </div>
  )
}

