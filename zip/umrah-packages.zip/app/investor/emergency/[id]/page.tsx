"use client"

import { useEffect, useState } from "react"
import { useParams, useRouter } from "next/navigation"
import Image from "next/image"
import Link from "next/link"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts"

// Define emergency investor data type
interface EmergencyInvestorData {
  id: string
  name: string
  fatherName: string
  address: string
  division: string
  district: string
  postCode: string
  dateOfBirth: string
  occupation: string
  mobileNo: string
  email: string
  emergencyContact: string
  relationship: string
  bankName: string
  accountHolder: string
  accountNo: string
  branch: string
  bkashNo: string
  position: string
  investmentHistory: {
    date: string
    amount: number
    duration: string
    returnDate: string
    returnAmount: number
    status: string
    profit: number
  }[]
  benefitsReceived: {
    date: string
    description: string
    value: number
    category: string
  }[]
  currentInvestment: {
    date: string
    amount: number
    pendingAmount: number
    totalAgreedAmount: number
    duration: string
    returnDate: string
    status: string
  }
  upcomingBenefits: {
    description: string
    estimatedValue: number
    condition: string
    status: string
  }[]
}

// Sample emergency investor data
const emergencyInvestorsData: Record<string, EmergencyInvestorData> = {
  "EINV-00027": {
    id: "EINV-00027",
    name: "Md Anwarul Hoque",
    fatherName: "H. Abdur Rashid",
    address: "42/1K, RND Road",
    division: "Lalbag",
    district: "Dhaka",
    postCode: "1211",
    dateOfBirth: "13 July-1971",
    occupation: "Business",
    mobileNo: "01685667828",
    email: "ah6002819@gmail.com",
    emergencyContact: "MD Abrar",
    relationship: "Son",
    bankName: "Al-Arafah Islami Bank Ltd.",
    accountHolder: "Anwarul Hoque",
    accountNo: "0031120004477",
    branch: "Moulvi Bazar",
    bkashNo: "01685667828",
    position: "Bridge Financier",
    investmentHistory: [
      {
        date: "৩ এপ্রিল, ২০২৩",
        amount: 200000,
        duration: "৪৫ দিন",
        returnDate: "২১ মে, ২০২৩",
        returnAmount: 210800,
        status: "সম্পন্ন",
        profit: 10800,
      },
      {
        date: "২৫ অক্টোবর, ২০২৪",
        amount: 10000,
        duration: "৪০ দিন",
        returnDate: "৩ ডিসেম্বর, ২০২৪",
        returnAmount: 10000,
        status: "সম্পন্ন",
        profit: 0,
      },
    ],
    benefitsReceived: [
      {
        date: "২১ মে, ২০২৩",
        description: "সৌদি রিয়াল (৬,৭০০ SAR) বিশেষ রেটে (২৮.৬১ টাকা)",
        value: 191687,
        category: "মুদ্রা বিনিময়",
      },
      {
        date: "৩ ডিসেম্বর, ২০২৪",
        description: "প্রতিষ্ঠানের জন্য ১৯২ পিস কোরআন মাজিদ বিশেষ মূল্যে",
        value: 28800,
        category: "পণ্য",
      },
    ],
    currentInvestment: {
      date: "১১ ফেব্রুয়ারি, ২০২৫",
      amount: 200000,
      pendingAmount: 300000,
      totalAgreedAmount: 500000,
      duration: "৪৫ দিন",
      returnDate: "২৮ মার্চ, ২০২৫",
      status: "চলমান",
    },
    upcomingBenefits: [
      {
        description: "প্রতিষ্ঠানের জন্য ৩২ পিস কোরআন মাজিদ উপহার",
        estimatedValue: 12800,
        condition: "পূর্ণ বিনিয়োগ (৫ লক্ষ) সম্পন্ন হলে",
        status: "অপেক্ষমান",
      },
      {
        description: "ঢাকা-জেদ্দা-ঢাকা বিমান টিকেট",
        estimatedValue: 85000,
        condition: "পূর্ণ বিনিয়োগ (৫ লক্ষ) সম্পন্ন হলে",
        status: "অপেক্ষমান",
      },
    ],
  },
}

// Colors for charts
const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042", "#8884d8"]

export default function EmergencyInvestorDashboard() {
  const params = useParams()
  const router = useRouter()
  const [investor, setInvestor] = useState<EmergencyInvestorData | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Get investor ID from URL
    const id = params.id as string

    // Check if investor exists
    if (emergencyInvestorsData[id]) {
      setInvestor(emergencyInvestorsData[id])
    } else {
      // Redirect to login if investor not found
      router.push("/investor/login")
    }

    setLoading(false)
  }, [params.id, router])

  const handleLogout = () => {
    router.push("/investor/login")
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-green-600 border-t-transparent rounded-full animate-spin mx-auto"></div>
          <p className="mt-4 text-gray-600">লোড হচ্ছে...</p>
        </div>
      </div>
    )
  }

  if (!investor) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <p className="text-red-600">বিনিয়োগকারী খুঁজে পাওয়া যায়নি। অনুগ্রহ করে আবার লগইন করুন।</p>
          <button
            onClick={() => router.push("/investor/login")}
            className="mt-4 bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700 transition-colors"
          >
            লগইন পেইজে ফিরে যান
          </button>
        </div>
      </div>
    )
  }

  // Format number with commas
  const formatNumber = (num: number) => {
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")
  }

  // Calculate total investment
  const totalInvestment =
    investor.investmentHistory.reduce((sum, item) => sum + item.amount, 0) + investor.currentInvestment.amount

  // Calculate total returns
  const totalReturns = investor.investmentHistory.reduce((sum, item) => sum + item.profit, 0)

  // Calculate total benefits value
  const totalBenefitsValue = investor.benefitsReceived.reduce((sum, item) => sum + item.value, 0)

  // Prepare data for benefits category chart
  const benefitsCategoryData = investor.benefitsReceived.reduce((acc: any[], item) => {
    const existingCategory = acc.find((cat) => cat.name === item.category)
    if (existingCategory) {
      existingCategory.value += item.value
    } else {
      acc.push({ name: item.category, value: item.value })
    }
    return acc
  }, [])

  // Prepare data for investment history chart
  const investmentHistoryData = investor.investmentHistory.map((item) => ({
    date: item.date,
    amount: item.amount,
    profit: item.profit,
  }))

  // Add this function before the return statement
  const getAgreementLink = () => {
    if (investor.id === "EINV-00027") {
      return "/investor/agreements/bridge-financier"
    } else {
      return "/investor/agreements/long-term"
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-green-600 text-white py-4">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center gap-2">
              <Image
                src="https://mj-ahmad.github.io/mja2025/img/logo.png"
                alt="TRUSTED-ALLY Logo"
                width={40}
                height={40}
                className="h-10 w-auto"
              />
              <span className="font-bold text-xl">T-Ally Umrah Sr.</span>
            </Link>
            <div className="flex items-center space-x-4">
              <div className="text-right">
                <p className="text-sm">স্বাগতম, {investor.name}</p>
                <p className="text-xs">আইডি: {investor.id}</p>
              </div>
              <button
                onClick={handleLogout}
                className="bg-white text-green-600 px-3 py-1 rounded-md text-sm hover:bg-gray-100 transition-colors"
              >
                লগআউট
              </button>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-bold">বিনিয়োগকারি ডেশবোর্ড</h1>
          <div className="bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm font-medium">
            {investor.position}
          </div>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-white p-6 rounded-lg shadow-md">
            <h2 className="text-sm text-gray-600 mb-1">মোট বিনিয়োগ</h2>
            <p className="text-2xl font-bold text-gray-800">৳ {formatNumber(totalInvestment)}</p>
            <p className="text-xs text-gray-500 mt-1">সর্বমোট বিনিয়োগকৃত অর্থ</p>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-md">
            <h2 className="text-sm text-gray-600 mb-1">বর্তমান বিনিয়োগ</h2>
            <p className="text-2xl font-bold text-green-600">৳ {formatNumber(investor.currentInvestment.amount)}</p>
            <p className="text-xs text-gray-500 mt-1">
              <span className="text-green-600 font-medium">
                {Math.round((investor.currentInvestment.amount / investor.currentInvestment.totalAgreedAmount) * 100)}%
              </span>{" "}
              সম্পন্ন ({formatNumber(investor.currentInvestment.pendingAmount)} টাকা বাকি)
            </p>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-md">
            <h2 className="text-sm text-gray-600 mb-1">মোট লভ্যাংশ</h2>
            <p className="text-2xl font-bold text-gray-800">৳ {formatNumber(totalReturns)}</p>
            <p className="text-xs text-gray-500 mt-1">সরাসরি প্রাপ্ত লভ্যাংশ</p>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-md">
            <h2 className="text-sm text-gray-600 mb-1">মোট সুবিধা মূল্য</h2>
            <p className="text-2xl font-bold text-gray-800">৳ {formatNumber(totalBenefitsValue)}</p>
            <p className="text-xs text-gray-500 mt-1">বিশেষ সুবিধাসমূহের আনুমানিক মূল্য</p>
            <Link
              href={`/investor/emergency/${investor.id}/statement`}
              className="text-xs text-blue-600 hover:underline mt-1 block"
            >
              বিস্তারিত স্টেটমেন্ট দেখুন
            </Link>
          </div>
        </div>

        {/* Current Investment Status */}
        <div className="bg-white p-6 rounded-lg shadow-md mb-8">
          <h2 className="text-lg font-bold mb-4">বর্তমান বিনিয়োগের অবস্থা</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <div className="mb-4">
                <div className="flex justify-between mb-1">
                  <span className="text-sm font-medium text-gray-700">বিনিয়োগ অগ্রগতি</span>
                  <span className="text-sm font-medium text-gray-700">
                    {Math.round(
                      (investor.currentInvestment.amount / investor.currentInvestment.totalAgreedAmount) * 100,
                    )}
                    %
                  </span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2.5">
                  <div
                    className="bg-green-600 h-2.5 rounded-full"
                    style={{
                      width: `${(investor.currentInvestment.amount / investor.currentInvestment.totalAgreedAmount) * 100}%`,
                    }}
                  ></div>
                </div>
              </div>

              <ul className="space-y-2">
                <li className="flex justify-between">
                  <span className="text-gray-600">বিনিয়োগের তারিখ:</span>
                  <span className="font-medium">{investor.currentInvestment.date}</span>
                </li>
                <li className="flex justify-between">
                  <span className="text-gray-600">বিনিয়োগকৃত অর্থ:</span>
                  <span className="font-medium">৳ {formatNumber(investor.currentInvestment.amount)}</span>
                </li>
                <li className="flex justify-between">
                  <span className="text-gray-600">বাকি অর্থ:</span>
                  <span className="font-medium">৳ {formatNumber(investor.currentInvestment.pendingAmount)}</span>
                </li>
                <li className="flex justify-between">
                  <span className="text-gray-600">মোট চুক্তিকৃত অর্থ:</span>
                  <span className="font-medium">৳ {formatNumber(investor.currentInvestment.totalAgreedAmount)}</span>
                </li>
              </ul>
            </div>

            <ul className="space-y-2">
              <li className="flex justify-between">
                <span className="text-gray-600">সময়কাল:</span>
                <span className="font-medium">{investor.currentInvestment.duration}</span>
              </li>
              <li className="flex justify-between">
                <span className="text-gray-600">ফেরত প্রদানের তারিখ:</span>
                <span className="font-medium">{investor.currentInvestment.returnDate}</span>
              </li>
              <li className="flex justify-between">
                <span className="text-gray-600">অবস্থা:</span>
                <span className="font-medium px-2 py-1 bg-yellow-100 text-yellow-800 rounded-full text-xs">
                  {investor.currentInvestment.status}
                </span>
              </li>
            </ul>
          </div>
        </div>

        {/* Upcoming Benefits */}
        <div className="bg-white p-6 rounded-lg shadow-md mb-8">
          <h2 className="text-lg font-bold mb-4">আসন্ন সুবিধাসমূহ</h2>
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th
                    scope="col"
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                  >
                    বিবরণ
                  </th>
                  <th
                    scope="col"
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                  >
                    আনুমানিক মূল্য
                  </th>
                  <th
                    scope="col"
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                  >
                    শর্ত
                  </th>
                  <th
                    scope="col"
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                  >
                    অবস্থা
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {investor.upcomingBenefits.map((benefit, index) => (
                  <tr key={index}>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{benefit.description}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 font-medium">
                      ৳ {formatNumber(benefit.estimatedValue)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{benefit.condition}</td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-yellow-100 text-yellow-800">
                        {benefit.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          {/* Investment History Chart */}
          <div className="bg-white p-6 rounded-lg shadow-md">
            <h2 className="text-lg font-bold mb-4">বিনিয়োগের ইতিহাস</h2>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={investmentHistoryData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis />
                  <Tooltip formatter={(value) => [`৳ ${formatNumber(value as number)}`, ""]} />
                  <Legend />
                  <Bar dataKey="amount" name="বিনিয়োগ" fill="#0088FE" />
                  <Bar dataKey="profit" name="লভ্যাংশ" fill="#00C49F" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Benefits Category Chart */}
          <div className="bg-white p-6 rounded-lg shadow-md">
            <h2 className="text-lg font-bold mb-4">সুবিধার ধরন অনুযায়ী বিভাজন</h2>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={benefitsCategoryData}
                    cx="50%"
                    cy="50%"
                    labelLine={true}
                    label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {benefitsCategoryData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value) => [`৳ ${formatNumber(value as number)}`, ""]} />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        {/* Investment History */}
        <div className="bg-white p-6 rounded-lg shadow-md mb-8">
          <h2 className="text-lg font-bold mb-4">বিনিয়োগের ইতিহাস</h2>
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th
                    scope="col"
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                  >
                    তারিখ
                  </th>
                  <th
                    scope="col"
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                  >
                    পরিমাণ
                  </th>
                  <th
                    scope="col"
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                  >
                    সময়কাল
                  </th>
                  <th
                    scope="col"
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                  >
                    ফেরত তারিখ
                  </th>
                  <th
                    scope="col"
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                  >
                    ফেরত পরিমাণ
                  </th>
                  <th
                    scope="col"
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                  >
                    লভ্যাংশ
                  </th>
                  <th
                    scope="col"
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                  >
                    অবস্থা
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {investor.investmentHistory.map((investment, index) => (
                  <tr key={index}>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{investment.date}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 font-medium">
                      ৳ {formatNumber(investment.amount)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{investment.duration}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{investment.returnDate}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 font-medium">
                      ৳ {formatNumber(investment.returnAmount)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-green-600 font-medium">
                      ৳ {formatNumber(investment.profit)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                        {investment.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Benefits Received */}
        <div className="bg-white p-6 rounded-lg shadow-md mb-8">
          <h2 className="text-lg font-bold mb-4">প্রাপ্ত সুবিধাসমূহ</h2>
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th
                    scope="col"
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                  >
                    তারিখ
                  </th>
                  <th
                    scope="col"
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                  >
                    বিবরণ
                  </th>
                  <th
                    scope="col"
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                  >
                    আনুমানিক মূল্য
                  </th>
                  <th
                    scope="col"
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                  >
                    ধরন
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {investor.benefitsReceived.map((benefit, index) => (
                  <tr key={index}>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{benefit.date}</td>
                    <td className="px-6 py-4 text-sm text-gray-900">{benefit.description}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 font-medium">
                      ৳ {formatNumber(benefit.value)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-blue-100 text-blue-800">
                        {benefit.category}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Personal Information */}
        <div className="bg-white p-6 rounded-lg shadow-md mb-8">
          <h2 className="text-lg font-bold mb-4">ব্যক্তিগত তথ্য</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="text-md font-semibold mb-2">ব্যক্তিগত বিবরণ</h3>
              <ul className="space-y-2">
                <li className="flex justify-between">
                  <span className="text-gray-600">নাম:</span>
                  <span className="font-medium">{investor.name}</span>
                </li>
                <li className="flex justify-between">
                  <span className="text-gray-600">পিতার নাম:</span>
                  <span className="font-medium">{investor.fatherName}</span>
                </li>
                <li className="flex justify-between">
                  <span className="text-gray-600">ঠিকানা:</span>
                  <span className="font-medium">{investor.address}</span>
                </li>
                <li className="flex justify-between">
                  <span className="text-gray-600">বিভাগ:</span>
                  <span className="font-medium">{investor.division}</span>
                </li>
                <li className="flex justify-between">
                  <span className="text-gray-600">জেলা:</span>
                  <span className="font-medium">{investor.district}</span>
                </li>
                <li className="flex justify-between">
                  <span className="text-gray-600">পোস্ট কোড:</span>
                  <span className="font-medium">{investor.postCode}</span>
                </li>
                <li className="flex justify-between">
                  <span className="text-gray-600">জন্ম তারিখ:</span>
                  <span className="font-medium">{investor.dateOfBirth}</span>
                </li>
                <li className="flex justify-between">
                  <span className="text-gray-600">পেশা:</span>
                  <span className="font-medium">{investor.occupation}</span>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="text-md font-semibold mb-2">যোগাযোগ তথ্য</h3>
              <ul className="space-y-2">
                <li className="flex justify-between">
                  <span className="text-gray-600">মোবাইল নম্বর:</span>
                  <span className="font-medium">{investor.mobileNo}</span>
                </li>
                <li className="flex justify-between">
                  <span className="text-gray-600">ইমেইল:</span>
                  <span className="font-medium">{investor.email}</span>
                </li>
                <li className="flex justify-between">
                  <span className="text-gray-600">জরুরি যোগাযোগ:</span>
                  <span className="font-medium">{investor.emergencyContact}</span>
                </li>
                <li className="flex justify-between">
                  <span className="text-gray-600">সম্পর্ক:</span>
                  <span className="font-medium">{investor.relationship}</span>
                </li>
              </ul>

              <h3 className="text-md font-semibold mt-4 mb-2">ব্যাংক বিবরণ</h3>
              <ul className="space-y-2">
                <li className="flex justify-between">
                  <span className="text-gray-600">ব্যাংকের নাম:</span>
                  <span className="font-medium">{investor.bankName}</span>
                </li>
                <li className="flex justify-between">
                  <span className="text-gray-600">অ্যাকাউন্ট হোল্ডার:</span>
                  <span className="font-medium">{investor.accountHolder}</span>
                </li>
                <li className="flex justify-between">
                  <span className="text-gray-600">অ্যাকাউন্ট নম্বর:</span>
                  <span className="font-medium">{investor.accountNo}</span>
                </li>
                <li className="flex justify-between">
                  <span className="text-gray-600">শাখা:</span>
                  <span className="font-medium">{investor.branch}</span>
                </li>
                <li className="flex justify-between">
                  <span className="text-gray-600">বিকাশ নম্বর:</span>
                  <span className="font-medium">{investor.bkashNo}</span>
                </li>
              </ul>
            </div>
          </div>
        </div>

        {/* Help and Support */}
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h2 className="text-lg font-bold mb-4">সাহায্য ও সহযোগিতা</h2>
          <p className="text-gray-600 mb-4">আপনার বিনিয়োগ সম্পর্কে কোন প্রশ্ন বা জিজ্ঞাসা থাকলে আমাদের সাথে যোগাযোগ করুন।</p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="flex items-center">
              <svg className="h-6 w-6 text-green-600 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"
                />
              </svg>
              <span>+880 1892051303</span>
            </div>
            <div className="flex items-center">
              <svg className="h-6 w-6 text-green-600 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"
                />
              </svg>
              <span>t-ally@outlook.com</span>
            </div>
            <div className="flex items-center">
              <svg className="h-6 w-6 text-green-600 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"
                />
              </svg>
              <span>রবি - বৃহঃ  সকাল ১০টা - বিকাল ৫টা</span>
            </div>
          </div>
        </div>
        {/* Footer Links - Clearly visible at the bottom */}
        <footer className="mt-12 py-6 bg-gray-100 rounded-lg">
          <div className="container mx-auto px-4">
            <div className="flex flex-col items-center justify-center">
              <div className="flex space-x-8 mb-4">
                <Link href="/terms" className="text-green-600 hover:underline font-medium">
                  শর্তাবলী
                </Link>
                <Link href="/privacy" className="text-green-600 hover:underline font-medium">
                  গোপনীয়তা নীতি
                </Link>
                <Link href={getAgreementLink()} className="text-green-600 hover:underline font-medium">
                  বিনিয়োগ চুক্তি নামা
                </Link>
              </div>
              <p className="text-center text-gray-600">
                &copy; {new Date().getFullYear()} টি-অ্যাল্লি হজ্জ ও উমরাহ। সর্বস্বত্ব সংরক্ষিত।
              </p>
            </div>
          </div>
        </footer>
      </main>
    </div>
  )
}

