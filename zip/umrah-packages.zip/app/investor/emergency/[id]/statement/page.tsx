"use client"

import { useEffect, useState } from "react"
import { useParams, useRouter } from "next/navigation"
import Image from "next/image"
import Link from "next/link"
import { ArrowLeft, Printer, Download, Share2 } from "lucide-react"

// Define benefit data type
interface Benefit {
  date: string
  description: string
  value: number
  category: string
  details?: string
  breakdown?: {
    item: string
    quantity: number
    marketRate: number
    providedRate: number
    savings: number
  }[]
}

// Define emergency investor data type
interface EmergencyInvestorData {
  id: string
  name: string
  fatherName: string
  address: string
  division: string
  district: string
  postCode: string
  dateOfBirth: string
  occupation: string
  mobileNo: string
  email: string
  position: string
  benefitsReceived: Benefit[]
}

// Sample emergency investor data
const emergencyInvestorsData: Record<string, EmergencyInvestorData> = {
  "EINV-00027": {
    id: "EINV-00027",
    name: "Anwarul Hoque",
    fatherName: "H. Abdur Rashid",
    address: "42/1K, RND Road",
    division: "Lalbag",
    district: "Dhaka",
    postCode: "1211",
    dateOfBirth: "13 July-1971",
    occupation: "Business",
    mobileNo: "01685667828",
    email: "ah6002819@gmail.com",
    position: "Bridge Financier",
    benefitsReceived: [
      {
        date: "২১ মে, ২০২৩",
        description: "সৌদি রিয়াল (৬,৭০০ SAR) বিশেষ রেটে (২৮.৬১ টাকা)",
        value: 191687,
        category: "মুদ্রা বিনিময়",
        details: "উমরাহ সফরের জন্য বিশেষ রেটে সৌদি রিয়াল প্রদান করা হয়েছে। বাজার রেটের তুলনায় প্রতি রিয়ালে ৩.৫ টাকা সাশ্রয় হয়েছে।",
        breakdown: [
          {
            item: "সৌদি রিয়াল",
            quantity: 6700,
            marketRate: 32.11,
            providedRate: 28.61,
            savings: 23450,
          },
        ],
      },
      {
        date: "৩ ডিসেম্বর, ২০২৪",
        description: "প্রতিষ্ঠানের জন্য ১৯২ পিস কোরআন মাজিদ বিশেষ মূল্যে",
        value: 28800,
        category: "পণ্য",
        details:
          "বিনিয়োগকারীর প্রতিষ্ঠানের শিক্ষার্থীদের জন্য বিশেষ মূল্যে কোরআন মাজিদ প্রদান করা হয়েছে। প্রতি পিসে ১৫০ টাকা সাশ্রয় হয়েছে।",
        breakdown: [
          {
            item: "কোরআন মাজিদ",
            quantity: 192,
            marketRate: 500,
            providedRate: 350,
            savings: 28800,
          },
        ],
      },
    ],
  },
}

export default function BenefitsStatement() {
  const params = useParams()
  const router = useRouter()
  const [investor, setInvestor] = useState<EmergencyInvestorData | null>(null)
  const [loading, setLoading] = useState(true)
  const [currentDate] = useState(
    new Date().toLocaleDateString("bn-BD", {
      year: "numeric",
      month: "long",
      day: "numeric",
    }),
  )

  useEffect(() => {
    // Get investor ID from URL
    const id = params.id as string

    // Check if investor exists
    if (emergencyInvestorsData[id]) {
      setInvestor(emergencyInvestorsData[id])
    } else {
      // Redirect to login if investor not found
      router.push("/investor/login")
    }

    setLoading(false)
  }, [params.id, router])

  const handlePrint = () => {
    window.print()
  }

  const handleDownload = () => {
    window.print()
  }

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: `${investor?.name} - বিশেষ সুবিধা স্টেটমেন্ট`,
        text: `${investor?.name} এর বিশেষ সুবিধা স্টেটমেন্ট`,
        url: window.location.href,
      })
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-green-600 border-t-transparent rounded-full animate-spin mx-auto"></div>
          <p className="mt-4 text-gray-600">লোড হচ্ছে...</p>
        </div>
      </div>
    )
  }

  if (!investor) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <p className="text-red-600">বিনিয়োগকারী খুঁজে পাওয়া যায়নি। অনুগ্রহ করে আবার লগইন করুন।</p>
          <button
            onClick={() => router.push("/investor/login")}
            className="mt-4 bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700 transition-colors"
          >
            লগইন পেইজে ফিরে যান
          </button>
        </div>
      </div>
    )
  }

  // Format number with commas
  const formatNumber = (num: number) => {
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")
  }

  // Calculate total benefits value
  const totalBenefitsValue = investor.benefitsReceived.reduce((sum, item) => sum + item.value, 0)

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        {/* Header with navigation and actions */}
        <div className="flex justify-between items-center mb-6 print:hidden">
          <Link
            href={`/investor/emergency/${investor.id}`}
            className="flex items-center text-green-600 hover:text-green-700"
          >
            <ArrowLeft className="w-4 h-4 mr-1" />
            <span>ড্যাশবোর্ডে ফিরে যান</span>
          </Link>

          <div className="flex space-x-2">
            <button
              onClick={handlePrint}
              className="flex items-center bg-blue-600 text-white px-3 py-2 rounded-md text-sm hover:bg-blue-700 transition-colors"
            >
              <Printer className="w-4 h-4 mr-1" />
              <span>প্রিন্ট করুন</span>
            </button>

            <button
              onClick={handleDownload}
              className="flex items-center bg-green-600 text-white px-3 py-2 rounded-md text-sm hover:bg-green-700 transition-colors"
            >
              <Download className="w-4 h-4 mr-1" />
              <span>ডাউনলোড</span>
            </button>

            <button
              onClick={handleShare}
              className="flex items-center bg-purple-600 text-white px-3 py-2 rounded-md text-sm hover:bg-purple-700 transition-colors"
            >
              <Share2 className="w-4 h-4 mr-1" />
              <span>শেয়ার</span>
            </button>
          </div>
        </div>

        {/* Statement Paper */}
        <div className="bg-white rounded-lg shadow-md p-8 print:shadow-none">
          {/* Statement Header */}
          <div className="flex justify-between items-center border-b border-gray-200 pb-6 mb-6">
            <div className="flex items-center">
              <Image
                src="https://mj-ahmad.github.io/mja2025/img/logo.png"
                alt="TRUSTED-ALLY Logo"
                width={60}
                height={60}
                className="h-16 w-auto mr-4"
              />
              <div>
                <h1 className="text-2xl font-bold text-gray-800">T-Ally Umrah Sr.</h1>
                <p className="text-gray-600">বিশেষ সুবিধা স্টেটমেন্ট</p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-gray-600">স্টেটমেন্ট তারিখ:</p>
              <p className="font-medium">{currentDate}</p>
              <p className="text-gray-600 mt-2">স্টেটমেন্ট নং:</p>
              <p className="font-medium">
                BS-{investor.id}-{new Date().getFullYear()}
              </p>
            </div>
          </div>

          {/* Investor Information */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            <div>
              <h2 className="text-lg font-semibold mb-3">বিনিয়োগকারীর তথ্য</h2>
              <table className="w-full">
                <tbody>
                  <tr>
                    <td className="py-1 text-gray-600">নাম:</td>
                    <td className="py-1 font-medium">{investor.name}</td>
                  </tr>
                  <tr>
                    <td className="py-1 text-gray-600">আইডি:</td>
                    <td className="py-1 font-medium">{investor.id}</td>
                  </tr>
                  <tr>
                    <td className="py-1 text-gray-600">ঠিকানা:</td>
                    <td className="py-1 font-medium">
                      {investor.address}, {investor.district}
                    </td>
                  </tr>
                  <tr>
                    <td className="py-1 text-gray-600">মোবাইল:</td>
                    <td className="py-1 font-medium">{investor.mobileNo}</td>
                  </tr>
                </tbody>
              </table>
            </div>
            <div>
              <h2 className="text-lg font-semibold mb-3">সারসংক্ষেপ</h2>
              <table className="w-full">
                <tbody>
                  <tr>
                    <td className="py-1 text-gray-600">বিনিয়োগকারীর ধরন:</td>
                    <td className="py-1 font-medium">{investor.position}</td>
                  </tr>
                  <tr>
                    <td className="py-1 text-gray-600">মোট সুবিধা সংখ্যা:</td>
                    <td className="py-1 font-medium">{investor.benefitsReceived.length}</td>
                  </tr>
                  <tr>
                    <td className="py-1 text-gray-600">মোট সুবিধা মূল্য:</td>
                    <td className="py-1 font-medium">৳ {formatNumber(totalBenefitsValue)}</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          {/* Statement Title */}
          <div className="text-center mb-6">
            <h2 className="text-xl font-bold">বিশেষ সুবিধা স্টেটমেন্ট</h2>
            <p className="text-gray-600">সকল সুবিধার বিস্তারিত বিবরণ</p>
          </div>

          {/* Benefits Details */}
          <div className="mb-8">
            <table className="min-w-full border border-gray-200">
              <thead>
                <tr className="bg-gray-50">
                  <th className="py-3 px-4 text-left border-b border-gray-200 font-semibold">তারিখ</th>
                  <th className="py-3 px-4 text-left border-b border-gray-200 font-semibold">বিবরণ</th>
                  <th className="py-3 px-4 text-left border-b border-gray-200 font-semibold">ধরন</th>
                  <th className="py-3 px-4 text-right border-b border-gray-200 font-semibold">মূল্য (৳)</th>
                </tr>
              </thead>
              <tbody>
                {investor.benefitsReceived.map((benefit, index) => (
                  <tr key={index} className={index % 2 === 0 ? "bg-white" : "bg-gray-50"}>
                    <td className="py-3 px-4 border-b border-gray-200">{benefit.date}</td>
                    <td className="py-3 px-4 border-b border-gray-200">{benefit.description}</td>
                    <td className="py-3 px-4 border-b border-gray-200">
                      <span className="px-2 py-1 bg-blue-100 text-blue-800 rounded-full text-xs">
                        {benefit.category}
                      </span>
                    </td>
                    <td className="py-3 px-4 border-b border-gray-200 text-right font-medium">
                      ৳ {formatNumber(benefit.value)}
                    </td>
                  </tr>
                ))}
                <tr className="bg-gray-50">
                  <td colSpan={3} className="py-3 px-4 text-right font-bold">
                    মোট:
                  </td>
                  <td className="py-3 px-4 text-right font-bold">৳ {formatNumber(totalBenefitsValue)}</td>
                </tr>
              </tbody>
            </table>
          </div>

          {/* Detailed Breakdown */}
          <div className="mb-8">
            <h3 className="text-lg font-semibold mb-4">বিস্তারিত বিশ্লেষণ</h3>

            {investor.benefitsReceived.map((benefit, index) => (
              <div key={index} className="mb-6 border border-gray-200 rounded-lg overflow-hidden">
                <div className="bg-gray-50 px-4 py-3 border-b border-gray-200">
                  <h4 className="font-medium">{benefit.description}</h4>
                  <p className="text-sm text-gray-600">{benefit.date}</p>
                </div>

                <div className="p-4">
                  <p className="text-gray-700 mb-4">{benefit.details}</p>

                  {benefit.breakdown && (
                    <table className="min-w-full">
                      <thead>
                        <tr className="bg-gray-50">
                          <th className="py-2 px-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            আইটেম
                          </th>
                          <th className="py-2 px-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                            পরিমাণ
                          </th>
                          <th className="py-2 px-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                            বাজার রেট (৳)
                          </th>
                          <th className="py-2 px-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                            প্রদত্ত রেট (৳)
                          </th>
                          <th className="py-2 px-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                            সাশ্রয় (৳)
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                        {benefit.breakdown.map((item, idx) => (
                          <tr key={idx} className={idx % 2 === 0 ? "bg-white" : "bg-gray-50"}>
                            <td className="py-2 px-3 whitespace-nowrap">{item.item}</td>
                            <td className="py-2 px-3 text-right">{formatNumber(item.quantity)}</td>
                            <td className="py-2 px-3 text-right">{formatNumber(item.marketRate)}</td>
                            <td className="py-2 px-3 text-right">{formatNumber(item.providedRate)}</td>
                            <td className="py-2 px-3 text-right font-medium">৳ {formatNumber(item.savings)}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  )}
                </div>
              </div>
            ))}
          </div>

          {/* Terms and Notes */}
          <div className="border-t border-gray-200 pt-6 text-sm text-gray-600">
            <h3 className="font-semibold mb-2">বিশেষ দ্রষ্টব্য:</h3>
            <ul className="list-disc pl-5 space-y-1">
              <li>এই স্টেটমেন্টে উল্লিখিত সকল মূল্য বাজার মূল্যের উপর ভিত্তি করে নির্ধারিত।</li>
              <li>বিশেষ সুবিধাসমূহ বিনিয়োগকারীর সাথে পূর্ব চুক্তি অনুযায়ী প্রদান করা হয়েছে।</li>
              <li>এই স্টেটমেন্ট শুধুমাত্র তথ্যগত উদ্দেশ্যে প্রদান করা হয়েছে।</li>
              <li>কোন প্রশ্ন বা জিজ্ঞাসা থাকলে অনুগ্রহ করে আমাদের সাথে যোগাযোগ করুন।</li>
            </ul>
          </div>

          {/* Footer */}
          <div className="border-t border-gray-200 mt-8 pt-6 flex justify-between items-center">
            <div>
              <p className="text-sm text-gray-600">T-Ally Umrah Sr.</p>
              <p className="text-xs text-gray-500">ইমেইল: t-ally@outlook.com</p>
              <p className="text-xs text-gray-500">ফোন: +880 1892051303</p>
            </div>
            <div className="text-right">
              <p className="text-sm text-gray-600">অফিসিয়াল ডকুমেন্ট</p>
              <p className="text-xs text-gray-500">পৃষ্ঠা 1/1</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

