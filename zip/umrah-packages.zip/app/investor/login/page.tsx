"use client"

import type React from "react"

import { useState } from "react"
import Image from "next/image"
import { useRouter } from "next/navigation"
import Link from "next/link"

export default function InvestorLogin() {
  const [investorId, setInvestorId] = useState("")
  const [error, setError] = useState("")
  const router = useRouter()

  // Sample investor IDs (in a real app, these would be stored in a database)
  const validInvestorIds = ["INV-9045", "INV-0065", "INV-2080", "EINV-70092"]

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault()

    if (validInvestorIds.includes(investorId)) {
      if (investorId.startsWith("EINV")) {
        router.push(`/investor/emergency/${investorId}`)
      } else {
        router.push(`/investor/dashboard/${investorId}`)
      }
    } else {
      setError("আইডি নাম্বারটি সঠিক নয়। অনুগ্রহ করে সঠিক আইডি নাম্বার দিন।")
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-green-600 text-white py-4">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center gap-2">
              <Image
                src="https://mj-ahmad.github.io/mja2025/img/logo.png"
                alt="TRUSTED-ALLY Logo"
                width={40}
                height={40}
                className="h-10 w-auto"
              />
              <span className="font-bold text-xl">T-Ally Umrah Sr.</span>
            </Link>
            <nav className="hidden md:flex space-x-6">
              <Link href="/" className="hover:text-green-200 transition-colors">
                হোম
              </Link>
              <Link href="/packages" className="hover:text-green-200 transition-colors">
                প্যাকেজসমূহ
              </Link>
              <Link href="/investment" className="hover:text-green-200 transition-colors">
                বিনিয়োগ
              </Link>
              <Link href="/about" className="hover:text-green-200 transition-colors">
                আমাদের সম্পর্কে
              </Link>
              <Link href="/contact" className="hover:text-green-200 transition-colors">
                যোগাযোগ
              </Link>
            </nav>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-12">
        <div className="max-w-md mx-auto bg-white rounded-lg shadow-lg overflow-hidden">
          <div className="bg-green-600 p-6 text-white text-center">
            <h1 className="text-2xl font-bold">বিনিয়োগকারী ড্যাশবোর্ড</h1>
            <p className="mt-2">আপনার আইডি নাম্বার দিয়ে লগইন করুন</p>
          </div>

          <div className="p-6">
            <form onSubmit={handleLogin} className="space-y-6">
              <div>
                <label htmlFor="investorId" className="block text-sm font-medium text-gray-700 mb-1">
                  আইডি নাম্বার
                </label>
                <input
                  type="text"
                  id="investorId"
                  value={investorId}
                  onChange={(e) => setInvestorId(e.target.value)}
                  placeholder="আপনার আইডি নাম্বার লিখুন (উদাহরণ: INV-5077)"
                  className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  required
                />
              </div>

              {error && <div className="bg-red-50 text-red-600 p-3 rounded-md text-sm">{error}</div>}

              <div className="flex flex-col space-y-4">
                <button
                  type="submit"
                  className="w-full bg-green-600 text-white py-2 rounded-md hover:bg-green-700 transition-colors"
                >
                  লগইন করুন
                </button>

                <div className="text-center text-sm text-gray-600">
                  <p className="mt-2">
                    আইডি নাম্বার পরিবর্তন করতে চাইলে{" "}
                    <Link href="/contact" className="text-green-600 hover:underline">
                      আমাদের সাথে যোগাযোগ করুন
                    </Link>
                  </p>
                </div>
              </div>
            </form>
          </div>
        </div>
      </main>
    </div>
  )
}

