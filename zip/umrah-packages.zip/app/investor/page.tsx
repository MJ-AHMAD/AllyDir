import { redirect } from "next/navigation"

export default function InvestorPage() {
  redirect("/investor/login")
  return null
}

