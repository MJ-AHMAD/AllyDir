"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"

export default function LongTermAgreement() {
  const [investorName, setInvestorName] = useState("আব্দুল করিম")
  const [investorId, setInvestorId] = useState("INV-5001")
  const [amount, setAmount] = useState("500000")
  const [package_type, setPackageType] = useState("স্টার্টার")
  const [duration, setDuration] = useState("3")
  const [returnRate, setReturnRate] = useState("12")
  const [startDate, setStartDate] = useState("২০২৫-০৩-০১")
  const [endDate, setEndDate] = useState("২০২৮-০৩-০১")

  return (
    <div className="bg-white min-h-screen">
      <div className="max-w-4xl mx-auto p-8 bg-white shadow-lg my-8">
        {/* Print and Download buttons */}
        <div className="flex justify-end mb-6 gap-4">
          <button
            onClick={() => window.print()}
            className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700 print:hidden"
          >
            প্রিন্ট করুন
          </button>
          <Link
            href="/investor/dashboard/INV-5001"
            className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 print:hidden"
          >
            ড্যাশবোর্ডে ফিরে যান
          </Link>
        </div>

        {/* Header */}
        <div className="text-center mb-8 border-b-2 border-green-700 pb-4">
          <div className="flex justify-center mb-4">
            <div className="w-24 h-24 relative">
              <Image src="https://mj-ahmad.github.io/mja2025/img/logo.png" alt="টি-অ্যাল্লি Logo" width={96} height={96} />
            </div>
          </div>
          <h1 className="text-2xl font-bold text-green-800 mb-2">টি-অ্যাল্লি হজ্জ ও উমরাহ এজেন্সি</h1>
          <p className="text-gray-600">৪২/১ কে, আর এন ডি রোড, লালবাগ, ঢাকা-১২১১</p>
          <h2 className="text-3xl font-bold mt-6 text-green-900">দীর্ঘ মেয়াদি বিনিয়োগ চুক্তিনামা</h2>
        </div>

        {/* Agreement Body */}
        <div className="space-y-6 text-gray-800">
          <div className="mb-6">
            <p className="mb-4">
              <span className="font-semibold">তারিখ:</span> {new Date().toLocaleDateString("bn-BD")}
            </p>

            <p className="mb-4">এই চুক্তিনামা নিম্নলিখিত পক্ষদ্বয়ের মধ্যে সম্পাদিত হলো:</p>

            <div className="pl-4 border-l-4 border-green-600 mb-4">
              <p className="font-semibold">প্রথম পক্ষ:</p>
              <p>টি-অ্যাল্লি হজ্জ ও উমরাহ এজেন্সি</p>
              <p>৪২/১ কে, আর এন ডি রোড, লালবাগ, ঢাকা-১২১১</p>
              <p>প্রতিনিধি: মোহাম্মদ আবদুল্লাহ আল মামুন</p>
              <p>পদবী: ব্যবস্থাপনা পরিচালক</p>
            </div>

            <div className="pl-4 border-l-4 border-blue-600 mb-4">
              <p className="font-semibold">দ্বিতীয় পক্ষ:</p>
              <p>নাম: {investorName}</p>
              <p>আইডি: {investorId}</p>
              <p>ঠিকানা: ৪২/১ কে, আর এন ডি রোড, লালবাগ, ঢাকা-১২১১</p>
              <p>মোবাইল: ০১৭১২৩৪৫৬৭৮</p>
            </div>
          </div>

          <div className="bg-gray-50 p-4 rounded-lg border border-gray-200 mb-6">
            <h3 className="text-xl font-semibold mb-4 text-green-800">বিনিয়োগের বিবরণ:</h3>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="font-medium">বিনিয়োগের পরিমাণ:</p>
                <p className="text-lg">{amount} টাকা</p>
              </div>
              <div>
                <p className="font-medium">প্যাকেজ:</p>
                <p className="text-lg">{package_type}</p>
              </div>
              <div>
                <p className="font-medium">সময়কাল:</p>
                <p className="text-lg">{duration} বছর</p>
              </div>
              <div>
                <p className="font-medium">বার্ষিক রিটার্ন:</p>
                <p className="text-lg">{returnRate}%</p>
              </div>
              <div>
                <p className="font-medium">শুরুর তারিখ:</p>
                <p className="text-lg">{startDate}</p>
              </div>
              <div>
                <p className="font-medium">শেষের তারিখ:</p>
                <p className="text-lg">{endDate}</p>
              </div>
            </div>
          </div>

          <div className="mb-6">
            <h3 className="text-xl font-semibold mb-4 text-green-800">লভ্যাংশ বিবরণ:</h3>
            <ul className="list-disc pl-6 space-y-2">
              <li>বার্ষিক লভ্যাংশ হার: {returnRate}%</li>
              <li>লভ্যাংশ প্রদানের সময়সূচি: ত্রৈমাসিক</li>
              <li>প্রতি তিন মাসে লভ্যাংশ প্রদান করা হবে</li>
              <li>বার্ষিক বোনাস লভ্যাংশ: বিনিয়োগের ১% (যদি কোম্পানি লক্ষ্যমাত্রা অর্জন করে)</li>
            </ul>
          </div>

          <div className="mb-6">
            <h3 className="text-xl font-semibold mb-4 text-green-800">বিনিয়োগ প্রত্যাহারের শর্তাবলী:</h3>
            <ul className="list-disc pl-6 space-y-2">
              <li>পূর্ণ মেয়াদে প্রত্যাহার: কোনো জরিমানা ছাড়া সম্পূর্ণ মূলধন ফেরত</li>
              <li>আংশিক প্রত্যাহার: ৬ মাস পর থেকে সর্বোচ্চ ৩০% প্রত্যাহার করা যাবে</li>
              <li>জরুরী প্রত্যাহার: ১ বছরের আগে প্রত্যাহার করলে ৫% সার্ভিস চার্জ প্রযোজ্য</li>
            </ul>
          </div>

          <div className="mb-8">
            <h3 className="text-xl font-semibold mb-4 text-green-800">অধিকার ও দায়িত্ব:</h3>
            <ol className="list-decimal pl-6 space-y-3">
              <li>বিনিয়োগকারী ত্রৈমাসিক রিপোর্ট পাওয়ার অধিকার রাখেন।</li>
              <li>বিনিয়োগকারী যেকোনো সময় তার বিনিয়োগের অবস্থা জানতে পারবেন।</li>
              <li>কোম্পানি বিনিয়োগকারীর তথ্য গোপন রাখতে বাধ্য থাকবে।</li>
              <li>কোম্পানি নির্ধারিত সময়ে লভ্যাংশ প্রদান করতে বাধ্য থাকবে।</li>
              <li>যেকোনো বিরোধ উভয় পক্ষের আলোচনার মাধ্যমে সমাধান করা হবে।</li>
            </ol>
          </div>

          {/* Signature Section */}
          <div className="mt-16 grid grid-cols-2 gap-16">
            <div className="text-center">
              <div className="border-t-2 border-black pt-2">
                <p className="font-semibold">প্রথম পক্ষের স্বাক্ষর</p>
                <p>টি-অ্যাল্লি হজ্জ ও উমরাহ এজেন্সি</p>
              </div>
            </div>
            <div className="text-center">
              <div className="border-t-2 border-black pt-2">
                <p className="font-semibold">দ্বিতীয় পক্ষের স্বাক্ষর</p>
                <p>{investorName}</p>
              </div>
            </div>
          </div>

          {/* Witness Section */}
          <div className="mt-16 grid grid-cols-2 gap-16">
            <div className="text-center">
              <div className="border-t-2 border-black pt-2">
                <p className="font-semibold">সাক্ষী (১)</p>
                <p>নাম: ________________</p>
              </div>
            </div>
            <div className="text-center">
              <div className="border-t-2 border-black pt-2">
                <p className="font-semibold">সাক্ষী (২)</p>
                <p>নাম: ________________</p>
              </div>
            </div>
          </div>

          {/* Company Seal */}
          <div className="mt-12 text-center">
            <div className="inline-block border-2 border-dashed border-gray-400 rounded-full p-8">
              <p className="text-gray-500">কোম্পানির সিল</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

