"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"

export default function BridgeFinancierAgreement() {
  const [investorName, setInvestorName] = useState("আনোয়ারুল হক")
  const [investorId, setInvestorId] = useState("EINV-00027")
  const [amount, setAmount] = useState("500000")
  const [duration, setDuration] = useState("45")
  const [startDate, setStartDate] = useState("২০২৫-০২-১১")
  const [endDate, setEndDate] = useState("২০২৫-০৩-২৮")

  return (
    <div className="bg-white min-h-screen">
      <div className="max-w-4xl mx-auto p-8 bg-white shadow-lg my-8">
        {/* Print and Download buttons */}
        <div className="flex justify-end mb-6 gap-4">
          <button
            onClick={() => window.print()}
            className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700 print:hidden"
          >
            প্রিন্ট করুন
          </button>
          <Link
            href="/investor/emergency/EINV-00027"
            className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 print:hidden"
          >
            ড্যাশবোর্ডে ফিরে যান
          </Link>
        </div>

        {/* Header */}
        <div className="text-center mb-8 border-b-2 border-green-700 pb-4">
          <div className="flex justify-center mb-4">
            <div className="w-24 h-24 relative">
              <Image src="https://mj-ahmad.github.io/mja2025/img/logo.png" alt="টি-অ্যাল্লি Logo" width={96} height={96} />
            </div>
          </div>
          <h1 className="text-2xl font-bold text-green-800 mb-2">ট্রাস্টেড-অ্যাল্লি</h1>
          <p className="text-gray-600">কোরআনের ফেরিওয়ালা, ২৭ পুরানো পল্টন, ঢাকা-১০০০</p>
          <h2 className="text-3xl font-bold mt-6 text-green-900">স্বল্প মেয়াদি বিনিয়োগ চুক্তিনামা</h2>
        </div>

        {/* Agreement Body */}
        <div className="space-y-6 text-gray-800">
          <div className="mb-6">
            <p className="mb-4">
              <span className="font-semibold">তারিখ:</span> {new Date().toLocaleDateString("bn-BD")}
            </p>

            <p className="mb-4">এই চুক্তিনামা নিম্নলিখিত পক্ষদ্বয়ের মধ্যে ২০২৫-০২-১১ ইং তারিখে সম্পাদিত হলো:</p>

            <div className="pl-4 border-l-4 border-green-600 mb-4">
              <p className="font-semibold">প্রথম পক্ষ:</p>
              <p>ট্রাস্টেড-অ্যাল্লি</p>
              <p>কোরআনের ফেরিওয়ালা, ২৭ পুরানো পল্টন, ঢাকা-১০০০</p>
              <p>প্রতিনিধি: মোঃ জাফর আহমদ</p>
              <p>পদবী: ব্যবস্থাপনা পরিচালক</p>
            </div>

            <div className="pl-4 border-l-4 border-blue-600 mb-4">
              <p className="font-semibold">দ্বিতীয় পক্ষ:</p>
              <p>নাম: {investorName}</p>
              <p>আইডি: {investorId}</p>
              <p>ঠিকানা: ৪২/১ কে, আর এন ডি রোড, লালবাগ, ঢাকা-১২১১</p>
              <p>মোবাইল: ০১৬৮৫৬৬৭৮২৮</p>
            </div>
          </div>

          <div className="bg-gray-50 p-4 rounded-lg border border-gray-200 mb-6">
            <h3 className="text-xl font-semibold mb-4 text-green-800">বিনিয়োগের বিবরণ:</h3>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="font-medium">বিনিয়োগের পরিমাণ:</p>
                <p className="text-lg">{amount} টাকা</p>
              </div>
              <div>
                <p className="font-medium">সময়কাল:</p>
                <p className="text-lg">{duration} দিন</p>
              </div>
              <div>
                <p className="font-medium">শুরুর তারিখ:</p>
                <p className="text-lg">{startDate}</p>
              </div>
              <div>
                <p className="font-medium">শেষের তারিখ:</p>
                <p className="text-lg">{endDate}</p>
              </div>
            </div>
          </div>

          <div className="mb-6">
            <h3 className="text-xl font-semibold mb-4 text-green-800">বিশেষ সুবিধাসমূহ:</h3>
            <ul className="list-disc pl-6 space-y-2">
              <li>৩২ পিস কোরআন মাজিদ উপহার (প্রতিষ্ঠানের জন্য)</li>
              <li>ঢাকা-জেদ্দা-ঢাকা রিটার্ন বিমান টিকেট</li>
              <li>মূল বিনিয়োগের সাথে সন্তোষজনক লভ্যাংশ</li>
            </ul>
          </div>

          <div className="mb-8">
            <h3 className="text-xl font-semibold mb-4 text-green-800">শর্তাবলী:</h3>
            <ol className="list-decimal pl-6 space-y-3">
              <li>দ্বিতীয় পক্ষ কর্তৃক প্রদত্ত অর্থ প্রথম পক্ষ গ্রহণ করবে এবং নির্ধারিত সময়ের জন্য ব্যবহার করবে।</li>
              <li>নির্ধারিত সময় শেষে প্রথম পক্ষ দ্বিতীয় পক্ষকে সম্পূর্ণ মূলধন ফেরত দিতে বাধ্য থাকবে।</li>
              <li>উল্লেখিত বিশেষ সুবিধাসমূহ চুক্তি অনুযায়ী প্রদান করা হবে।</li>
              <li>অনাকাঙ্ক্ষিত ভাবে পূর্ব পরিকল্পনা ব্যতিত ২৭ জানুয়ারি ২০২৫ বিকেলে বিনিয়োগ কারির কর্মস্থল ঢাকা ইসলামপুর জুব্বু খানন জামে মসজিদে (খতিব) ট্রাস্টের অ্যাল্লি'র ব্যবস্থাপনা পরিচালক মোঃ জাফর আহমদ এর সাথে সাক্ষাত হয়, এবং বিভিন্ন বিষয়ে আলোচনার এক পর্যায়ে মোঃ জাফর আহমদ এর পক্ষ থেকে  স্বল্প মেয়াদি বিনিয়োগের প্রস্তাব করা হলে বিনিয়োগকারী সাথে সাথেই আনন্দের সাথে সম্মতি প্রকাশ করেন। পরবর্তীতে  দ্বিতীয় পক্ষ ১১ ফেব্রুয়ারি ২০২৫ ইং তারিখে ব্যাংক চেকের মাধ্যমে ২০০,০০০ টাকা প্রদান করেছেন,চেক নাম্বার - AIB-3866186, অবশিষ্ট ৩০০,০০০ টাকা আগামী ১৫ দিনের মধ্যে প্রদান করবেন।</li>
              <li>যেকোনো বিরোধ উভয় পক্ষের আলোচনার মাধ্যমে সমাধান করা হবে।</li>
            </ol>
          </div>

          {/* Signature Section */}
          <div className="mt-16 grid grid-cols-2 gap-16">
            <div className="text-center">
              <div className="border-t-2 border-black pt-2">
                <p className="font-semibold">প্রথম পক্ষের স্বাক্ষর</p>
                <p>ট্রাস্টেড-অ্যাল্লি</p>
              </div>
            </div>
            <div className="text-center">
              <div className="border-t-2 border-black pt-2">
                <p className="font-semibold">দ্বিতীয় পক্ষের স্বাক্ষর</p>
                <p>{investorName}</p>
              </div>
            </div>
          </div>

          {/* Witness Section */}
          <div className="mt-16 grid grid-cols-2 gap-16">
            <div className="text-center">
              <div className="border-t-2 border-black pt-2">
                <p className="font-semibold">সাক্ষী (১)</p>
                <p>নাম: ________________</p>
              </div>
            </div>
            <div className="text-center">
              <div className="border-t-2 border-black pt-2">
                <p className="font-semibold">সাক্ষী (২)</p>
                <p>নাম: ________________</p>
              </div>
            </div>
          </div>

          {/* Company Seal */}
          <div className="mt-12 text-center">
            <div className="inline-block border-2 border-dashed border-gray-400 rounded-full p-8">
              <p className="text-gray-500">কোম্পানির সিল</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

