"use client"

import { useEffect, useState } from "react"
import { useParams, useRouter } from "next/navigation"
import Image from "next/image"
import Link from "next/link"
import {
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from "recharts"

// Define investor data type
interface InvestorData {
  id: string
  name: string
  investmentAmount: number
  investmentDate: string
  packageType: string
  returnRate: number
  totalReturns: number
  nextPaymentDate: string
  paymentHistory: {
    date: string
    amount: number
  }[]
  projectAllocation: {
    name: string
    value: number
  }[]
  monthlyReturns: {
    month: string
    returns: number
  }[]
}

// Sample investor data (in a real app, this would come from a database)
const investorsData: Record<string, InvestorData> = {
  "EINV-00027": {
    id: "EINV-00027",
    name: "আনোয়ারুল হক",
    investmentAmount: 500000,
    investmentDate: "২০২৪-০২-১৫",
    packageType: "ব্রিজ ফাইন্যান্সিয়ার",
    returnRate: 15,
    totalReturns: 75000,
    nextPaymentDate: "২০২৫-০২-১৫",
    paymentHistory: [
      { date: "২০২৪-০৩-১৫", amount: 18750 },
      { date: "২০২৪-০৪-১৫", amount: 18750 },
      { date: "২০২৪-০৫-১৫", amount: 18750 },
      { date: "২০২৪-০৬-১৫", amount: 18750 },
    ],
    projectAllocation: [
      { name: "হজ্জ প্যাকেজ", value: 35 },
      { name: "উমরাহ প্যাকেজ", value: 35 },
      { name: "হোটেল ও পরিবহন", value: 20 },
      { name: "অন্যান্য", value: 10 },
    ],
    monthlyReturns: [
      { month: "জানুয়ারি", returns: 6250 },
      { month: "ফেব্রুয়ারি", returns: 6250 },
      { month: "মার্চ", returns: 6250 },
      { month: "এপ্রিল", returns: 6250 },
      { month: "মে", returns: 6250 },
      { month: "জুন", returns: 6250 },
      { month: "জুলাই", returns: 6250 },
      { month: "আগস্ট", returns: 6250 },
      { month: "সেপ্টেম্বর", returns: 6250 },
      { month: "অক্টোবর", returns: 6250 },
      { month: "নভেম্বর", returns: 6250 },
      { month: "ডিসেম্বর", returns: 6250 },
    ],
  },
  "INV-5001": {
    id: "INV-5001",
    name: "আব্দুল করিম",
    investmentAmount: 500000,
    investmentDate: "২০২৩-০৬-১৫",
    packageType: "স্টার্টার প্যাকেজ",
    returnRate: 12,
    totalReturns: 60000,
    nextPaymentDate: "২০২৫-০৬-১৫",
    paymentHistory: [
      { date: "২০২৩-০৯-১৫", amount: 15000 },
      { date: "২০২৩-১২-১৫", amount: 15000 },
      { date: "২০২৪-০৩-১৫", amount: 15000 },
      { date: "২০২৪-০৬-১৫", amount: 15000 },
    ],
    projectAllocation: [
      { name: "হজ্জ প্যাকেজ", value: 30 },
      { name: "উমরাহ প্যাকেজ", value: 40 },
      { name: "হোটেল ও পরিবহন", value: 20 },
      { name: "অন্যান্য", value: 10 },
    ],
    monthlyReturns: [
      { month: "জানুয়ারি", returns: 5000 },
      { month: "ফেব্রুয়ারি", returns: 5000 },
      { month: "মার্চ", returns: 5000 },
      { month: "এপ্রিল", returns: 5000 },
      { month: "মে", returns: 5000 },
      { month: "জুন", returns: 5000 },
      { month: "জুলাই", returns: 5000 },
      { month: "আগস্ট", returns: 5000 },
      { month: "সেপ্টেম্বর", returns: 5000 },
      { month: "অক্টোবর", returns: 5000 },
      { month: "নভেম্বর", returns: 5000 },
      { month: "ডিসেম্বর", returns: 5000 },
    ],
  },
  "INV-2502": {
    id: "INV-2502",
    name: "ফারহানা আহমেদ",
    investmentAmount: 2500000,
    investmentDate: "২০২৩-০৪-১০",
    packageType: "প্রিমিয়াম প্যাকেজ",
    returnRate: 18,
    totalReturns: 450000,
    nextPaymentDate: "২০২৬-০৪-১০",
    paymentHistory: [
      { date: "২০২৩-০৫-১০", amount: 37500 },
      { date: "২০২৩-০৬-১০", amount: 37500 },
      { date: "২০২৩-০৭-১০", amount: 37500 },
      { date: "২০২৩-০৮-১০", amount: 37500 },
      { date: "২০২৩-০৯-১০", amount: 37500 },
      { date: "২০২৩-১০-১০", amount: 37500 },
      { date: "২০২৩-১১-১০", amount: 37500 },
      { date: "২০২৩-১২-১০", amount: 37500 },
      { date: "২০২৪-০১-১০", amount: 37500 },
      { date: "২০২৪-০২-১০", amount: 37500 },
      { date: "২০২৪-০৩-১০", amount: 37500 },
      { date: "২০২৪-০৪-১০", amount: 37500 },
    ],
    projectAllocation: [
      { name: "হজ্জ প্যাকেজ", value: 35 },
      { name: "উমরাহ প্যাকেজ", value: 30 },
      { name: "হোটেল ও পরিবহন", value: 25 },
      { name: "অন্যান্য", value: 10 },
    ],
    monthlyReturns: [
      { month: "জানুয়ারি", returns: 37500 },
      { month: "ফেব্রুয়ারি", returns: 37500 },
      { month: "মার্চ", returns: 37500 },
      { month: "এপ্রিল", returns: 37500 },
      { month: "মে", returns: 37500 },
      { month: "জুন", returns: 37500 },
      { month: "জুলাই", returns: 37500 },
      { month: "আগস্ট", returns: 37500 },
      { month: "সেপ্টেম্বর", returns: 37500 },
      { month: "অক্টোবর", returns: 37500 },
      { month: "নভেম্বর", returns: 37500 },
      { month: "ডিসেম্বর", returns: 37500 },
    ],
  },
  "INV-1003": {
    id: "INV-1003",
    name: "মোহাম্মদ রফিক",
    investmentAmount: 10000000,
    investmentDate: "২০২২-১১-২০",
    packageType: "এন্টারপ্রাইজ প্যাকেজ",
    returnRate: 20,
    totalReturns: 2000000,
    nextPaymentDate: "২০২৭-১১-২০",
    paymentHistory: [
      { date: "২০২২-১২-২০", amount: 166667 },
      { date: "২০২৩-০১-২০", amount: 166667 },
      { date: "২০২৩-০২-২০", amount: 166667 },
      { date: "২০২৩-০৩-২০", amount: 166667 },
      { date: "২০২৩-০৪-২০", amount: 166667 },
      { date: "২০২৩-০৫-২০", amount: 166667 },
      { date: "২০২৩-০৬-২০", amount: 166667 },
      { date: "২০২৩-০৭-২০", amount: 166667 },
      { date: "২০২৩-০৮-২০", amount: 166667 },
      { date: "২০২৩-০৯-২০", amount: 166667 },
      { date: "২০২৩-১০-২০", amount: 166667 },
      { date: "২০২৩-১১-২০", amount: 166667 },
    ],
    projectAllocation: [
      { name: "হজ্জ প্যাকেজ", value: 40 },
      { name: "উমরাহ প্যাকেজ", value: 25 },
      { name: "হোটেল ও পরিবহন", value: 25 },
      { name: "অন্যান্য", value: 10 },
    ],
    monthlyReturns: [
      { month: "জানুয়ারি", returns: 166667 },
      { month: "ফেব্রুয়ারি", returns: 166667 },
      { month: "মার্চ", returns: 166667 },
      { month: "এপ্রিল", returns: 166667 },
      { month: "মে", returns: 166667 },
      { month: "জুন", returns: 166667 },
      { month: "জুলাই", returns: 166667 },
      { month: "আগস্ট", returns: 166667 },
      { month: "সেপ্টেম্বর", returns: 166667 },
      { month: "অক্টোবর", returns: 166667 },
      { month: "নভেম্বর", returns: 166667 },
      { month: "ডিসেম্বর", returns: 166667 },
    ],
  },
}

// Colors for pie chart
const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042"]

export default function InvestorDashboard() {
  const params = useParams()
  const router = useRouter()
  const [investor, setInvestor] = useState<InvestorData | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Get investor ID from URL
    const id = params.id as string

    // Check if investor exists
    if (investorsData[id]) {
      setInvestor(investorsData[id])
    } else {
      // Redirect to login if investor not found
      router.push("/investor/login")
    }

    setLoading(false)
  }, [params.id, router])

  const handleLogout = () => {
    router.push("/investor/login")
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-green-600 border-t-transparent rounded-full animate-spin mx-auto"></div>
          <p className="mt-4 text-gray-600">লোড হচ্ছে...</p>
        </div>
      </div>
    )
  }

  if (!investor) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <p className="text-red-600">বিনিয়োগকারী খুঁজে পাওয়া যায়নি। অনুগ্রহ করে আবার লগইন করুন।</p>
          <button
            onClick={() => router.push("/investor/login")}
            className="mt-4 bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700 transition-colors"
          >
            লগইন পেইজে ফিরে যান
          </button>
        </div>
      </div>
    )
  }

  // Format number with commas
  const formatNumber = (num: number) => {
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")
  }

  // Determine which agreement link to show based on investor ID
  const getAgreementLink = () => {
    if (investor.id === "EINV-00027") {
      return "/investor/agreements/bridge-financier"
    } else {
      return "/investor/agreements/long-term"
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-green-600 text-white py-4">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center gap-2">
              <Image
                src="https://mj-ahmad.github.io/mja2025/img/logo.png"
                alt="TRUSTED-ALLY Logo"
                width={40}
                height={40}
                className="h-10 w-auto"
              />
              <span className="font-bold text-xl">টি-অ্যাল্লি উমরাহ</span>
            </Link>
            <div className="flex items-center space-x-4">
              <div className="text-right">
                <p className="text-sm">স্বাগতম, {investor.name}</p>
                <p className="text-xs">আইডি: {investor.id}</p>
              </div>
              <button
                onClick={handleLogout}
                className="bg-white text-green-600 px-3 py-1 rounded-md text-sm hover:bg-gray-100 transition-colors"
              >
                লগআউট
              </button>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <h1 className="text-2xl font-bold mb-6">বিনিয়োগকারী ড্যাশবোর্ড</h1>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-white p-6 rounded-lg shadow-md">
            <h2 className="text-sm text-gray-600 mb-1">মোট বিনিয়োগ</h2>
            <p className="text-2xl font-bold text-gray-800">৳ {formatNumber(investor.investmentAmount)}</p>
            <p className="text-xs text-gray-500 mt-1">বিনিয়োগের তারিখ: {investor.investmentDate}</p>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-md">
            <h2 className="text-sm text-gray-600 mb-1">বার্ষিক রিটার্ন রেট</h2>
            <p className="text-2xl font-bold text-green-600">{investor.returnRate}%</p>
            <p className="text-xs text-gray-500 mt-1">প্যাকেজ: {investor.packageType}</p>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-md">
            <h2 className="text-sm text-gray-600 mb-1">মোট প্রাপ্ত লভ্যাংশ</h2>
            <p className="text-2xl font-bold text-gray-800">৳ {formatNumber(investor.totalReturns)}</p>
            <p className="text-xs text-gray-500 mt-1">এ পর্যন্ত প্রাপ্ত লভ্যাংশ</p>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-md">
            <h2 className="text-sm text-gray-600 mb-1">পরবর্তী পেমেন্ট তারিখ</h2>
            <p className="text-2xl font-bold text-gray-800">{investor.nextPaymentDate}</p>
            <p className="text-xs text-gray-500 mt-1">পরবর্তী লভ্যাংশ প্রদানের তারিখ</p>
          </div>
        </div>

        {/* Charts and Tables */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          {/* Project Allocation Chart */}
          <div className="bg-white p-6 rounded-lg shadow-md">
            <h2 className="text-lg font-bold mb-4">প্রকল্প বরাদ্দ</h2>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={investor.projectAllocation}
                    cx="50%"
                    cy="50%"
                    labelLine={true}
                    label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {investor.projectAllocation.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="mt-4">
              <p className="text-sm text-gray-600">
                আপনার বিনিয়োগ বিভিন্ন প্রকল্পে বরাদ্দ করা হয়েছে। উপরের চার্টে প্রকল্প অনুযায়ী বরাদ্দের শতকরা হার দেখানো হয়েছে।
              </p>
            </div>
          </div>

          {/* Monthly Returns Chart */}
          <div className="bg-white p-6 rounded-lg shadow-md">
            <h2 className="text-lg font-bold mb-4">মাসিক রিটার্ন</h2>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={investor.monthlyReturns} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip formatter={(value) => [`৳ ${formatNumber(value as number)}`, "রিটার্ন"]} />
                  <Legend />
                  <Bar dataKey="returns" name="মাসিক রিটার্ন" fill="#00C49F" />
                </BarChart>
              </ResponsiveContainer>
            </div>
            <div className="mt-4">
              <p className="text-sm text-gray-600">উপরের চার্টে আপনার বিনিয়োগের মাসিক রিটার্ন দেখানো হয়েছে।</p>
            </div>
          </div>
        </div>

        {/* Payment History */}
        <div className="bg-white p-6 rounded-lg shadow-md mb-8">
          <h2 className="text-lg font-bold mb-4">পেমেন্ট হিস্টোরি</h2>
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th
                    scope="col"
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                  >
                    ক্রমিক নং
                  </th>
                  <th
                    scope="col"
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                  >
                    তারিখ
                  </th>
                  <th
                    scope="col"
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                  >
                    পরিমাণ
                  </th>
                  <th
                    scope="col"
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                  >
                    স্ট্যাটাস
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {investor.paymentHistory.map((payment, index) => (
                  <tr key={index}>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{index + 1}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{payment.date}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 font-medium">
                      ৳ {formatNumber(payment.amount)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                        পরিশোধিত
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Investment Details */}
        <div className="bg-white p-6 rounded-lg shadow-md mb-8">
          <h2 className="text-lg font-bold mb-4">বিনিয়োগের বিস্তারিত তথ্য</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="text-md font-semibold mb-2">বিনিয়োগকারীর তথ্য</h3>
              <ul className="space-y-2">
                <li className="flex justify-between">
                  <span className="text-gray-600">নাম:</span>
                  <span className="font-medium">{investor.name}</span>
                </li>
                <li className="flex justify-between">
                  <span className="text-gray-600">আইডি নাম্বার:</span>
                  <span className="font-medium">{investor.id}</span>
                </li>
                <li className="flex justify-between">
                  <span className="text-gray-600">প্যাকেজ:</span>
                  <span className="font-medium">{investor.packageType}</span>
                </li>
                <li className="flex justify-between">
                  <span className="text-gray-600">বিনিয়োগের তারিখ:</span>
                  <span className="font-medium">{investor.investmentDate}</span>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="text-md font-semibold mb-2">রিটার্ন বিবরণ</h3>
              <ul className="space-y-2">
                <li className="flex justify-between">
                  <span className="text-gray-600">বার্ষিক রিটার্ন রেট:</span>
                  <span className="font-medium">{investor.returnRate}%</span>
                </li>
                <li className="flex justify-between">
                  <span className="text-gray-600">বার্ষিক রিটার্ন পরিমাণ:</span>
                  <span className="font-medium">
                    ৳ {formatNumber((investor.investmentAmount * investor.returnRate) / 100)}
                  </span>
                </li>
                <li className="flex justify-between">
                  <span className="text-gray-600">মোট প্রাপ্ত লভ্যাংশ:</span>
                  <span className="font-medium">৳ {formatNumber(investor.totalReturns)}</span>
                </li>
                <li className="flex justify-between">
                  <span className="text-gray-600">পরবর্তী পেমেন্ট তারিখ:</span>
                  <span className="font-medium">{investor.nextPaymentDate}</span>
                </li>
              </ul>
            </div>
          </div>
        </div>

        {/* Help and Support */}
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h2 className="text-lg font-bold mb-4">সাহায্য ও সহযোগিতা</h2>
          <p className="text-gray-600 mb-4">আপনার বিনিয়োগ সম্পর্কে কোন প্রশ্ন বা জিজ্ঞাসা থাকলে আমাদের সাথে যোগাযোগ করুন।</p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="flex items-center">
              <svg className="h-6 w-6 text-green-600 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"
                />
              </svg>
              <span>+880 1892051303</span>
            </div>
            <div className="flex items-center">
              <svg className="h-6 w-6 text-green-600 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"
                />
              </svg>
              <span>t-ally@outlook.com</span>
            </div>
            <div className="flex items-center">
              <svg className="h-6 w-6 text-green-600 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"
                />
              </svg>
              <span>সোম - শুক্র: সকাল ১০টা - বিকাল ৫টা</span>
            </div>
          </div>
        </div>
        {/* Footer Links - Clearly visible at the bottom */}
        <footer className="mt-12 py-6 bg-gray-100 rounded-lg">
          <div className="container mx-auto px-4">
            <div className="flex flex-col items-center justify-center">
              <div className="flex space-x-8 mb-4">
                <Link href="/terms" className="text-green-600 hover:underline font-medium">
                  শর্তাবলী
                </Link>
                <Link href="/privacy" className="text-green-600 hover:underline font-medium">
                  গোপনীয়তা নীতি
                </Link>
                <Link href={getAgreementLink()} className="text-green-600 hover:underline font-medium">
                  বিনিয়োগ চুক্তি নামা
                </Link>
              </div>
              <p className="text-center text-gray-600">
                &copy; {new Date().getFullYear()} টি-অ্যাল্লি হজ্জ ও উমরাহ এজেন্সি। সর্বস্বত্ব সংরক্ষিত।
              </p>
            </div>
          </div>
        </footer>
      </main>
    </div>
  )
}

