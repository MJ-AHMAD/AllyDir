"use client"

import type React from "react"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { Footer } from "@/components/footer"

// Flight data structure
interface Flight {
  id: string
  airline: string
  flightNumber: string
  departureCity: string
  arrivalCity: string
  departureTime: string
  arrivalTime: string
  duration: string
  price: string
  stops: number
  date: string
}

// Sample flight data with dates from 10/03/2025 to 17/03/2025 for all routes
const flightsData: Flight[] = [
  // DAC - JED (Dhaka to Jeddah) flights
  // March 10, 2025
  {
    id: "biman-dhaka-jeddah-20250310",
    airline: "Biman Bangladesh",
    flightNumber: "BG-335",
    departureCity: "Dhaka (DAC)",
    arrivalCity: "Jeddah (JED)",
    departureTime: "10:30",
    arrivalTime: "14:45",
    duration: "6h 15m",
    price: "65,000",
    stops: 0,
    date: "2025-03-10",
  },
  {
    id: "emirates-dhaka-jeddah-20250310",
    airline: "Emirates",
    flightNumber: "EK-585",
    departureCity: "Dhaka (DAC)",
    arrivalCity: "Jeddah (JED)",
    departureTime: "09:15",
    arrivalTime: "15:30",
    duration: "8h 15m",
    stops: 1,
    price: "85,000",
    date: "2025-03-10",
  },
  // March 11, 2025
  {
    id: "biman-dhaka-jeddah-20250311",
    airline: "Biman Bangladesh",
    flightNumber: "BG-336",
    departureCity: "Dhaka (DAC)",
    arrivalCity: "Jeddah (JED)",
    departureTime: "11:30",
    arrivalTime: "15:45",
    duration: "6h 15m",
    price: "66,000",
    stops: 0,
    date: "2025-03-11",
  },
  // March 12, 2025
  {
    id: "qatar-dhaka-jeddah-20250312",
    airline: "Qatar Airways",
    flightNumber: "QR-643",
    departureCity: "Dhaka (DAC)",
    arrivalCity: "Jeddah (JED)",
    departureTime: "08:05",
    arrivalTime: "16:50",
    duration: "10h 45m",
    stops: 1,
    price: "92,000",
    date: "2025-03-12",
  },
  // March 13, 2025
  {
    id: "saudia-dhaka-jeddah-20250313",
    airline: "Saudia",
    flightNumber: "SV-803",
    departureCity: "Dhaka (DAC)",
    arrivalCity: "Jeddah (JED)",
    departureTime: "11:45",
    arrivalTime: "16:20",
    duration: "6h 35m",
    stops: 0,
    price: "72,000",
    date: "2025-03-13",
  },
  // March 14, 2025
  {
    id: "flynas-dhaka-jeddah-20250314",
    airline: "Flynas",
    flightNumber: "XY-545",
    departureCity: "Dhaka (DAC)",
    arrivalCity: "Jeddah (JED)",
    departureTime: "14:20",
    arrivalTime: "19:10",
    duration: "6h 50m",
    stops: 0,
    price: "68,000",
    date: "2025-03-14",
  },
  // March 15, 2025
  {
    id: "usbangla-dhaka-jeddah-20250315",
    airline: "US-Bangla Airlines",
    flightNumber: "BS-325",
    departureCity: "Dhaka (DAC)",
    arrivalCity: "Jeddah (JED)",
    departureTime: "12:30",
    arrivalTime: "17:45",
    duration: "7h 15m",
    stops: 0,
    price: "63,500",
    date: "2025-03-15",
  },
  // March 16, 2025
  {
    id: "biman-dhaka-jeddah-20250316",
    airline: "Biman Bangladesh",
    flightNumber: "BG-338",
    departureCity: "Dhaka (DAC)",
    arrivalCity: "Jeddah (JED)",
    departureTime: "09:30",
    arrivalTime: "13:45",
    duration: "6h 15m",
    price: "67,000",
    stops: 0,
    date: "2025-03-16",
  },
  // March 17, 2025
  {
    id: "emirates-dhaka-jeddah-20250317",
    airline: "Emirates",
    flightNumber: "EK-588",
    departureCity: "Dhaka (DAC)",
    arrivalCity: "Jeddah (JED)",
    departureTime: "08:15",
    arrivalTime: "14:30",
    duration: "8h 15m",
    stops: 1,
    price: "87,000",
    date: "2025-03-17",
  },

  // DAC - MED (Dhaka to Madinah) flights
  // March 10, 2025
  {
    id: "biman-dhaka-madinah-20250310",
    airline: "Biman Bangladesh",
    flightNumber: "BG-337",
    departureCity: "Dhaka (DAC)",
    arrivalCity: "Madinah (MED)",
    departureTime: "11:30",
    arrivalTime: "16:15",
    duration: "6h 45m",
    stops: 0,
    price: "67,000",
    date: "2025-03-10",
  },
  // March 11, 2025
  {
    id: "emirates-dhaka-madinah-20250311",
    airline: "Emirates",
    flightNumber: "EK-587",
    departureCity: "Dhaka (DAC)",
    arrivalCity: "Madinah (MED)",
    departureTime: "10:15",
    arrivalTime: "17:30",
    duration: "9h 15m",
    stops: 1,
    price: "88,000",
    date: "2025-03-11",
  },
  // March 12, 2025
  {
    id: "saudia-dhaka-madinah-20250312",
    airline: "Saudia",
    flightNumber: "SV-805",
    departureCity: "Dhaka (DAC)",
    arrivalCity: "Madinah (MED)",
    departureTime: "12:45",
    arrivalTime: "17:50",
    duration: "7h 05m",
    stops: 0,
    price: "74,000",
    date: "2025-03-12",
  },
  // March 13, 2025
  {
    id: "qatar-dhaka-madinah-20250313",
    airline: "Qatar Airways",
    flightNumber: "QR-645",
    departureCity: "Dhaka (DAC)",
    arrivalCity: "Madinah (MED)",
    departureTime: "09:05",
    arrivalTime: "18:20",
    duration: "11h 15m",
    stops: 1,
    price: "94,000",
    date: "2025-03-13",
  },
  // March 14, 2025
  {
    id: "flynas-dhaka-madinah-20250314",
    airline: "Flynas",
    flightNumber: "XY-547",
    departureCity: "Dhaka (DAC)",
    arrivalCity: "Madinah (MED)",
    departureTime: "15:20",
    arrivalTime: "20:40",
    duration: "7h 20m",
    stops: 0,
    price: "69,500",
    date: "2025-03-14",
  },
  // March 15, 2025
  {
    id: "usbangla-dhaka-madinah-20250315",
    airline: "US-Bangla Airlines",
    flightNumber: "BS-327",
    departureCity: "Dhaka (DAC)",
    arrivalCity: "Madinah (MED)",
    departureTime: "13:30",
    arrivalTime: "19:15",
    duration: "7h 45m",
    stops: 0,
    price: "65,500",
    date: "2025-03-15",
  },
  // March 16, 2025
  {
    id: "biman-dhaka-madinah-20250316",
    airline: "Biman Bangladesh",
    flightNumber: "BG-339",
    departureCity: "Dhaka (DAC)",
    arrivalCity: "Madinah (MED)",
    departureTime: "10:45",
    arrivalTime: "15:30",
    duration: "6h 45m",
    stops: 0,
    price: "68,000",
    date: "2025-03-16",
  },
  // March 17, 2025
  {
    id: "emirates-dhaka-madinah-20250317",
    airline: "Emirates",
    flightNumber: "EK-589",
    departureCity: "Dhaka (DAC)",
    arrivalCity: "Madinah (MED)",
    departureTime: "09:30",
    arrivalTime: "16:45",
    duration: "9h 15m",
    stops: 1,
    price: "89,000",
    date: "2025-03-17",
  },

  // JED - DAC (Jeddah to Dhaka) flights
  // March 10, 2025
  {
    id: "biman-jeddah-dhaka-20250310",
    airline: "Biman Bangladesh",
    flightNumber: "BG-336",
    departureCity: "Jeddah (JED)",
    arrivalCity: "Dhaka (DAC)",
    departureTime: "16:30",
    arrivalTime: "04:45",
    duration: "8h 15m",
    stops: 0,
    price: "68,000",
    date: "2025-03-10",
  },
  // March 11, 2025
  {
    id: "emirates-jeddah-dhaka-20250311",
    airline: "Emirates",
    flightNumber: "EK-586",
    departureCity: "Jeddah (JED)",
    arrivalCity: "Dhaka (DAC)",
    departureTime: "17:15",
    arrivalTime: "07:30",
    duration: "10h 15m",
    stops: 1,
    price: "88,000",
    date: "2025-03-11",
  },
  // March 12, 2025
  {
    id: "saudia-jeddah-dhaka-20250312",
    airline: "Saudia",
    flightNumber: "SV-804",
    departureCity: "Jeddah (JED)",
    arrivalCity: "Dhaka (DAC)",
    departureTime: "18:45",
    arrivalTime: "05:20",
    duration: "8h 35m",
    stops: 0,
    price: "75,000",
    date: "2025-03-12",
  },
  // March 13, 2025
  {
    id: "qatar-jeddah-dhaka-20250313",
    airline: "Qatar Airways",
    flightNumber: "QR-644",
    departureCity: "Jeddah (JED)",
    arrivalCity: "Dhaka (DAC)",
    departureTime: "19:05",
    arrivalTime: "09:50",
    duration: "12h 45m",
    stops: 1,
    price: "95,000",
    date: "2025-03-13",
  },
  // March 14, 2025
  {
    id: "flynas-jeddah-dhaka-20250314",
    airline: "Flynas",
    flightNumber: "XY-546",
    departureCity: "Jeddah (JED)",
    arrivalCity: "Dhaka (DAC)",
    departureTime: "21:20",
    arrivalTime: "06:10",
    duration: "8h 50m",
    stops: 0,
    price: "70,500",
    date: "2025-03-14",
  },
  // March 15, 2025
  {
    id: "usbangla-jeddah-dhaka-20250315",
    airline: "US-Bangla Airlines",
    flightNumber: "BS-326",
    departureCity: "Jeddah (JED)",
    arrivalCity: "Dhaka (DAC)",
    departureTime: "19:30",
    arrivalTime: "05:45",
    duration: "8h 15m",
    stops: 0,
    price: "66,500",
    date: "2025-03-15",
  },
  // March 16, 2025
  {
    id: "biman-jeddah-dhaka-20250316",
    airline: "Biman Bangladesh",
    flightNumber: "BG-339",
    departureCity: "Jeddah (JED)",
    arrivalCity: "Dhaka (DAC)",
    departureTime: "15:30",
    arrivalTime: "03:45",
    duration: "8h 15m",
    stops: 0,
    price: "69,000",
    date: "2025-03-16",
  },
  // March 17, 2025
  {
    id: "emirates-jeddah-dhaka-20250317",
    airline: "Emirates",
    flightNumber: "EK-589",
    departureCity: "Jeddah (JED)",
    arrivalCity: "Dhaka (DAC)",
    departureTime: "16:15",
    arrivalTime: "06:30",
    duration: "10h 15m",
    stops: 1,
    price: "89,000",
    date: "2025-03-17",
  },

  // MED - DAC (Madinah to Dhaka) flights
  // March 10, 2025
  {
    id: "biman-madinah-dhaka-20250310",
    airline: "Biman Bangladesh",
    flightNumber: "BG-338",
    departureCity: "Madinah (MED)",
    arrivalCity: "Dhaka (DAC)",
    departureTime: "18:30",
    arrivalTime: "05:15",
    duration: "8h 45m",
    stops: 0,
    price: "69,000",
    date: "2025-03-10",
  },
  // March 11, 2025
  {
    id: "emirates-madinah-dhaka-20250311",
    airline: "Emirates",
    flightNumber: "EK-588",
    departureCity: "Madinah (MED)",
    arrivalCity: "Dhaka (DAC)",
    departureTime: "19:15",
    arrivalTime: "08:30",
    duration: "11h 15m",
    stops: 1,
    price: "90,000",
    date: "2025-03-11",
  },
  // March 12, 2025
  {
    id: "saudia-madinah-dhaka-20250312",
    airline: "Saudia",
    flightNumber: "SV-806",
    departureCity: "Madinah (MED)",
    arrivalCity: "Dhaka (DAC)",
    departureTime: "20:45",
    arrivalTime: "06:50",
    duration: "9h 05m",
    stops: 0,
    price: "76,000",
    date: "2025-03-12",
  },
  // March 13, 2025
  {
    id: "qatar-madinah-dhaka-20250313",
    airline: "Qatar Airways",
    flightNumber: "QR-646",
    departureCity: "Madinah (MED)",
    arrivalCity: "Dhaka (DAC)",
    departureTime: "21:05",
    arrivalTime: "10:20",
    duration: "13h 15m",
    stops: 1,
    price: "96,000",
    date: "2025-03-13",
  },
  // March 14, 2025
  {
    id: "flynas-madinah-dhaka-20250314",
    airline: "Flynas",
    flightNumber: "XY-548",
    departureCity: "Madinah (MED)",
    arrivalCity: "Dhaka (DAC)",
    departureTime: "22:20",
    arrivalTime: "07:40",
    duration: "9h 20m",
    stops: 0,
    price: "71,500",
    date: "2025-03-14",
  },
  // March 15, 2025
  {
    id: "usbangla-madinah-dhaka-20250315",
    airline: "US-Bangla Airlines",
    flightNumber: "BS-328",
    departureCity: "Madinah (MED)",
    arrivalCity: "Dhaka (DAC)",
    departureTime: "20:30",
    arrivalTime: "06:15",
    duration: "8h 45m",
    stops: 0,
    price: "67,500",
    date: "2025-03-15",
  },
  // March 16, 2025
  {
    id: "biman-madinah-dhaka-20250316",
    airline: "Biman Bangladesh",
    flightNumber: "BG-340",
    departureCity: "Madinah (MED)",
    arrivalCity: "Dhaka (DAC)",
    departureTime: "17:30",
    arrivalTime: "04:15",
    duration: "8h 45m",
    stops: 0,
    price: "70,000",
    date: "2025-03-16",
  },
  // March 17, 2025
  {
    id: "emirates-madinah-dhaka-20250317",
    airline: "Emirates",
    flightNumber: "EK-590",
    departureCity: "Madinah (MED)",
    arrivalCity: "Dhaka (DAC)",
    departureTime: "18:15",
    arrivalTime: "07:30",
    duration: "11h 15m",
    stops: 1,
    price: "91,000",
    date: "2025-03-17",
  },

  // CGP - JED (Chittagong to Jeddah) flights
  // March 10, 2025
  {
    id: "biman-chittagong-jeddah-20250310",
    airline: "Biman Bangladesh",
    flightNumber: "BG-341",
    departureCity: "Chittagong (CGP)",
    arrivalCity: "Jeddah (JED)",
    departureTime: "09:30",
    arrivalTime: "14:45",
    duration: "7h 15m",
    stops: 0,
    price: "67,000",
    date: "2025-03-10",
  },
  // March 11, 2025
  {
    id: "emirates-chittagong-jeddah-20250311",
    airline: "Emirates",
    flightNumber: "EK-591",
    departureCity: "Chittagong (CGP)",
    arrivalCity: "Jeddah (JED)",
    departureTime: "08:15",
    arrivalTime: "15:30",
    duration: "9h 15m",
    stops: 1,
    price: "87,000",
    date: "2025-03-11",
  },
  // March 12, 2025
  {
    id: "saudia-chittagong-jeddah-20250312",
    airline: "Saudia",
    flightNumber: "SV-807",
    departureCity: "Chittagong (CGP)",
    arrivalCity: "Jeddah (JED)",
    departureTime: "10:45",
    arrivalTime: "16:20",
    duration: "7h 35m",
    stops: 0,
    price: "74,000",
    date: "2025-03-12",
  },
  // March 13, 2025
  {
    id: "qatar-chittagong-jeddah-20250313",
    airline: "Qatar Airways",
    flightNumber: "QR-647",
    departureCity: "Chittagong (CGP)",
    arrivalCity: "Jeddah (JED)",
    departureTime: "07:05",
    arrivalTime: "16:50",
    duration: "11h 45m",
    stops: 1,
    price: "94,000",
    date: "2025-03-13",
  },
  // March 14, 2025
  {
    id: "flynas-chittagong-jeddah-20250314",
    airline: "Flynas",
    flightNumber: "XY-549",
    departureCity: "Chittagong (CGP)",
    arrivalCity: "Jeddah (JED)",
    departureTime: "13:20",
    arrivalTime: "19:10",
    duration: "7h 50m",
    stops: 0,
    price: "70,000",
    date: "2025-03-14",
  },
  // March 15, 2025
  {
    id: "usbangla-chittagong-jeddah-20250315",
    airline: "US-Bangla Airlines",
    flightNumber: "BS-329",
    departureCity: "Chittagong (CGP)",
    arrivalCity: "Jeddah (JED)",
    departureTime: "11:30",
    arrivalTime: "17:45",
    duration: "8h 15m",
    stops: 0,
    price: "65,500",
    date: "2025-03-15",
  },
  // March 16, 2025
  {
    id: "biman-chittagong-jeddah-20250316",
    airline: "Biman Bangladesh",
    flightNumber: "BG-342",
    departureCity: "Chittagong (CGP)",
    arrivalCity: "Jeddah (JED)",
    departureTime: "08:30",
    arrivalTime: "13:45",
    duration: "7h 15m",
    stops: 0,
    price: "68,000",
    date: "2025-03-16",
  },
  // March 17, 2025
  {
    id: "emirates-chittagong-jeddah-20250317",
    airline: "Emirates",
    flightNumber: "EK-592",
    departureCity: "Chittagong (CGP)",
    arrivalCity: "Jeddah (JED)",
    departureTime: "07:15",
    arrivalTime: "14:30",
    duration: "9h 15m",
    stops: 1,
    price: "88,000",
    date: "2025-03-17",
  },

  // CGP - MED (Chittagong to Madinah) flights
  // March 10, 2025
  {
    id: "biman-chittagong-madinah-20250310",
    airline: "Biman Bangladesh",
    flightNumber: "BG-343",
    departureCity: "Chittagong (CGP)",
    arrivalCity: "Madinah (MED)",
    departureTime: "10:30",
    arrivalTime: "16:15",
    duration: "7h 45m",
    stops: 0,
    price: "69,000",
    date: "2025-03-10",
  },
  // March 11, 2025
  {
    id: "emirates-chittagong-madinah-20250311",
    airline: "Emirates",
    flightNumber: "EK-593",
    departureCity: "Chittagong (CGP)",
    arrivalCity: "Madinah (MED)",
    departureTime: "09:15",
    arrivalTime: "17:30",
    duration: "10h 15m",
    stops: 1,
    price: "90,000",
    date: "2025-03-11",
  },
  // March 12, 2025
  {
    id: "saudia-chittagong-madinah-20250312",
    airline: "Saudia",
    flightNumber: "SV-808",
    departureCity: "Chittagong (CGP)",
    arrivalCity: "Madinah (MED)",
    departureTime: "11:45",
    arrivalTime: "17:50",
    duration: "8h 05m",
    stops: 0,
    price: "76,000",
    date: "2025-03-12",
  },
  // March 13, 2025
  {
    id: "qatar-chittagong-madinah-20250313",
    airline: "Qatar Airways",
    flightNumber: "QR-648",
    departureCity: "Chittagong (CGP)",
    arrivalCity: "Madinah (MED)",
    departureTime: "08:05",
    arrivalTime: "18:20",
    duration: "12h 15m",
    stops: 1,
    price: "96,000",
    date: "2025-03-13",
  },
  // March 14, 2025
  {
    id: "flynas-chittagong-madinah-20250314",
    airline: "Flynas",
    flightNumber: "XY-550",
    departureCity: "Chittagong (CGP)",
    arrivalCity: "Madinah (MED)",
    departureTime: "14:20",
    arrivalTime: "20:40",
    duration: "8h 20m",
    stops: 0,
    price: "71,500",
    date: "2025-03-14",
  },
  // March 15, 2025
  {
    id: "usbangla-chittagong-madinah-20250315",
    airline: "US-Bangla Airlines",
    flightNumber: "BS-330",
    departureCity: "Chittagong (CGP)",
    arrivalCity: "Madinah (MED)",
    departureTime: "12:30",
    arrivalTime: "19:15",
    duration: "8h 45m",
    stops: 0,
    price: "67,500",
    date: "2025-03-15",
  },
  // March 16, 2025
  {
    id: "biman-chittagong-madinah-20250316",
    airline: "Biman Bangladesh",
    flightNumber: "BG-344",
    departureCity: "Chittagong (CGP)",
    arrivalCity: "Madinah (MED)",
    departureTime: "09:45",
    arrivalTime: "15:30",
    duration: "7h 45m",
    stops: 0,
    price: "70,000",
    date: "2025-03-16",
  },
  // March 17, 2025
  {
    id: "emirates-chittagong-madinah-20250317",
    airline: "Emirates",
    flightNumber: "EK-594",
    departureCity: "Chittagong (CGP)",
    arrivalCity: "Madinah (MED)",
    departureTime: "08:30",
    arrivalTime: "16:45",
    duration: "10h 15m",
    stops: 1,
    price: "91,000",
    date: "2025-03-17",
  },

  // JED - CGP (Jeddah to Chittagong) flights
  // March 10, 2025
  {
    id: "biman-jeddah-chittagong-20250310",
    airline: "Biman Bangladesh",
    flightNumber: "BG-345",
    departureCity: "Jeddah (JED)",
    arrivalCity: "Chittagong (CGP)",
    departureTime: "16:30",
    arrivalTime: "05:45",
    duration: "9h 15m",
    stops: 0,
    price: "70,000",
    date: "2025-03-10",
  },
  // March 11, 2025
  {
    id: "emirates-jeddah-chittagong-20250311",
    airline: "Emirates",
    flightNumber: "EK-595",
    departureCity: "Jeddah (JED)",
    arrivalCity: "Chittagong (CGP)",
    departureTime: "17:15",
    arrivalTime: "08:30",
    duration: "11h 15m",
    stops: 1,
    price: "91,000",
    date: "2025-03-11",
  },
  // March 12, 2025
  {
    id: "saudia-jeddah-chittagong-20250312",
    airline: "Saudia",
    flightNumber: "SV-809",
    departureCity: "Jeddah (JED)",
    arrivalCity: "Chittagong (CGP)",
    departureTime: "18:45",
    arrivalTime: "06:20",
    duration: "9h 35m",
    stops: 0,
    price: "77,000",
    date: "2025-03-12",
  },
  // March 13, 2025
  {
    id: "qatar-jeddah-chittagong-20250313",
    airline: "Qatar Airways",
    flightNumber: "QR-649",
    departureCity: "Jeddah (JED)",
    arrivalCity: "Chittagong (CGP)",
    departureTime: "19:05",
    arrivalTime: "10:50",
    duration: "13h 45m",
    stops: 1,
    price: "97,000",
    date: "2025-03-13",
  },
  // March 14, 2025
  {
    id: "flynas-jeddah-chittagong-20250314",
    airline: "Flynas",
    flightNumber: "XY-551",
    departureCity: "Jeddah (JED)",
    arrivalCity: "Chittagong (CGP)",
    departureTime: "21:20",
    arrivalTime: "07:10",
    duration: "9h 50m",
    stops: 0,
    price: "72,500",
    date: "2025-03-14",
  },
  // March 15, 2025
  {
    id: "usbangla-jeddah-chittagong-20250315",
    airline: "US-Bangla Airlines",
    flightNumber: "BS-331",
    departureCity: "Jeddah (JED)",
    arrivalCity: "Chittagong (CGP)",
    departureTime: "19:30",
    arrivalTime: "06:45",
    duration: "9h 15m",
    stops: 0,
    price: "68,500",
    date: "2025-03-15",
  },
  // March 16, 2025
  {
    id: "biman-jeddah-chittagong-20250316",
    airline: "Biman Bangladesh",
    flightNumber: "BG-346",
    departureCity: "Jeddah (JED)",
    arrivalCity: "Chittagong (CGP)",
    departureTime: "15:30",
    arrivalTime: "04:45",
    duration: "9h 15m",
    stops: 0,
    price: "71,000",
    date: "2025-03-16",
  },
  // March 17, 2025
  {
    id: "emirates-jeddah-chittagong-20250317",
    airline: "Emirates",
    flightNumber: "EK-596",
    departureCity: "Jeddah (JED)",
    arrivalCity: "Chittagong (CGP)",
    departureTime: "16:15",
    arrivalTime: "07:30",
    duration: "11h 15m",
    stops: 1,
    price: "92,000",
    date: "2025-03-17",
  },

  // MED - CGP (Madinah to Chittagong) flights
  // March 10, 2025
  {
    id: "biman-madinah-chittagong-20250310",
    airline: "Biman Bangladesh",
    flightNumber: "BG-347",
    departureCity: "Madinah (MED)",
    arrivalCity: "Chittagong (CGP)",
    departureTime: "18:30",
    arrivalTime: "06:15",
    duration: "9h 45m",
    stops: 0,
    price: "71,000",
    date: "2025-03-10",
  },
  // March 11, 2025
  {
    id: "emirates-madinah-chittagong-20250311",
    airline: "Emirates",
    flightNumber: "EK-597",
    departureCity: "Madinah (MED)",
    arrivalCity: "Chittagong (CGP)",
    departureTime: "19:15",
    arrivalTime: "09:30",
    duration: "12h 15m",
    stops: 1,
    price: "93,000",
    date: "2025-03-11",
  },
  // March 12, 2025
  {
    id: "saudia-madinah-chittagong-20250312",
    airline: "Saudia",
    flightNumber: "SV-810",
    departureCity: "Madinah (MED)",
    arrivalCity: "Chittagong (CGP)",
    departureTime: "20:45",
    arrivalTime: "07:50",
    duration: "10h 05m",
    stops: 0,
    price: "78,000",
    date: "2025-03-12",
  },
  // March 13, 2025
  {
    id: "qatar-madinah-chittagong-20250313",
    airline: "Qatar Airways",
    flightNumber: "QR-650",
    departureCity: "Madinah (MED)",
    arrivalCity: "Chittagong (CGP)",
    departureTime: "21:05",
    arrivalTime: "11:20",
    duration: "14h 15m",
    stops: 1,
    price: "98,000",
    date: "2025-03-13",
  },
  // March 14, 2025
  {
    id: "flynas-madinah-chittagong-20250314",
    airline: "Flynas",
    flightNumber: "XY-552",
    departureCity: "Madinah (MED)",
    arrivalCity: "Chittagong (CGP)",
    departureTime: "22:20",
    arrivalTime: "08:40",
    duration: "10h 20m",
    stops: 0,
    price: "73,500",
    date: "2025-03-14",
  },
  // March 15, 2025
  {
    id: "usbangla-madinah-chittagong-20250315",
    airline: "US-Bangla Airlines",
    flightNumber: "BS-332",
    departureCity: "Madinah (MED)",
    arrivalCity: "Chittagong (CGP)",
    departureTime: "20:30",
    arrivalTime: "07:15",
    duration: "9h 45m",
    stops: 0,
    price: "69,500",
    date: "2025-03-15",
  },
  // March 16, 2025
  {
    id: "biman-madinah-chittagong-20250316",
    airline: "Biman Bangladesh",
    flightNumber: "BG-348",
    departureCity: "Madinah (MED)",
    arrivalCity: "Chittagong (CGP)",
    departureTime: "17:30",
    arrivalTime: "05:15",
    duration: "9h 45m",
    stops: 0,
    price: "72,000",
    date: "2025-03-16",
  },
  // March 17, 2025
  {
    id: "emirates-madinah-chittagong-20250317",
    airline: "Emirates",
    flightNumber: "EK-598",
    departureCity: "Madinah (MED)",
    arrivalCity: "Chittagong (CGP)",
    departureTime: "18:15",
    arrivalTime: "08:30",
    duration: "12h 15m",
    stops: 1,
    price: "94,000",
    date: "2025-03-17",
  },
]

// Function to generate estimated flights for dates not in our database
const generateEstimatedFlights = (date: string, from: string, to: string): Flight[] => {
  // Get airlines and base flights to use as templates
  const airlines = ["Biman Bangladesh", "Emirates", "Saudia", "Qatar Airways", "Flynas", "US-Bangla Airlines"]
  const baseFlights = flightsData
    .filter((flight) => flight.departureCity.includes(from) && flight.arrivalCity.includes(to))
    .slice(0, 3)

  if (baseFlights.length === 0) return []

  // Generate 3-5 flights for the requested date
  const numFlights = Math.floor(Math.random() * 3) + 3 // 3-5 flights
  const estimatedFlights: Flight[] = []

  for (let i = 0; i < numFlights; i++) {
    // Use a base flight as template or create from scratch if no matching base flights
    const baseFlight = baseFlights[i % baseFlights.length] || {
      airline: airlines[i % airlines.length],
      departureCity: from.includes("(") ? from : `${from} (DAC)`,
      arrivalCity: to.includes("(") ? to : `${to} (JED)`,
      departureTime: "10:00",
      arrivalTime: "16:00",
      duration: "6h 00m",
      stops: 0,
      price: "70,000",
    }

    // Randomize some details to make it look different
    const hourOffset = Math.floor(Math.random() * 6) - 3 // -3 to +3 hours
    const depHour = (Number.parseInt(baseFlight.departureTime.split(":")[0]) + hourOffset + 24) % 24
    const depMinute = Math.floor(Math.random() * 4) * 15 // 0, 15, 30, or 45
    const departureTime = `${depHour.toString().padStart(2, "0")}:${depMinute.toString().padStart(2, "0")}`

    // Calculate arrival time based on duration
    const durationHours = Number.parseInt(baseFlight.duration.split("h")[0])
    const durationMinutes = Number.parseInt(baseFlight.duration.split(" ")[1].replace("m", ""))
    const totalMinutes = depHour * 60 + depMinute + durationHours * 60 + durationMinutes
    const arrHour = Math.floor(totalMinutes / 60) % 24
    const arrMinute = totalMinutes % 60
    const arrivalTime = `${arrHour.toString().padStart(2, "0")}:${arrMinute.toString().padStart(2, "0")}`

    // Randomize price slightly
    const basePrice = Number.parseInt(baseFlight.price.replace(/,/g, ""))
    const priceVariation = Math.floor(Math.random() * 5000) - 2500 // -2500 to +2500
    const newPrice = basePrice + priceVariation

    // Create flight number
    const airline = airlines[Math.floor(Math.random() * airlines.length)]
    const airlineCode =
      airline === "Biman Bangladesh"
        ? "BG"
        : airline === "Emirates"
          ? "EK"
          : airline === "Saudia"
            ? "SV"
            : airline === "Qatar Airways"
              ? "QR"
              : airline === "Flynas"
                ? "XY"
                : "BS"
    const flightNumber = `${airlineCode}-${Math.floor(Math.random() * 900) + 100}`

    // Create unique ID
    const datePart = date.replace(/-/g, "")
    const id = `${airline.toLowerCase().replace(/\s+/g, "-")}-${from.toLowerCase().split(" ")[0]}-${to.toLowerCase().split(" ")[0]}-${datePart}-${i}`

    estimatedFlights.push({
      id,
      airline,
      flightNumber,
      departureCity: baseFlight.departureCity,
      arrivalCity: baseFlight.arrivalCity,
      departureTime,
      arrivalTime,
      duration: baseFlight.duration,
      price: newPrice.toLocaleString(),
      stops: Math.random() > 0.7 ? 1 : 0, // 30% chance of having a stop
      date,
    })
  }

  return estimatedFlights
}

// Get airline logo URL
const getAirlineLogo = (airline: string): string => {
  const logos: Record<string, string> = {
    "Biman Bangladesh": "https://mj-ahmad.github.io/mja2025/img/biman-logo.png",
    Emirates: "https://mj-ahmad.github.io/mja2025/img/emirates-logo.png",
    Flynas: "https://mj-ahmad.github.io/mja2025/img/flynas-logo.png",
    "Qatar Airways": "https://mj-ahmad.github.io/mja2025/img/qatar-logo.png",
    Saudia: "https://mj-ahmad.github.io/mja2025/img/saudia-logo.png",
    "US-Bangla Airlines": "https://mj-ahmad.github.io/mja2025/img/usbangla-logo.png",
  }
  return logos[airline] || "/placeholder.svg?height=40&width=120"
}

export default function FlightsPage() {
  const [searchParams, setSearchParams] = useState({
    from: "Dhaka (DAC)",
    to: "Jeddah (JED)",
    departDate: "2025-03-10", // Current date
    returnDate: "",
    passengers: "1",
    tripType: "one-way",
  })

  const [filters, setFilters] = useState({
    airlines: [] as string[],
    maxPrice: "",
    stops: [] as number[],
  })

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target
    setSearchParams((prev) => ({ ...prev, [name]: value }))
  }

  const handleFilterChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, checked, type } = e.target

    if (type === "checkbox") {
      if (name === "airline") {
        setFilters((prev) => ({
          ...prev,
          airlines: checked ? [...prev.airlines, value] : prev.airlines.filter((airline) => airline !== value),
        }))
      } else if (name === "stops") {
        const stopValue = Number.parseInt(value)
        setFilters((prev) => ({
          ...prev,
          stops: checked ? [...prev.stops, stopValue] : prev.stops.filter((stop) => stop !== stopValue),
        }))
      }
    } else {
      setFilters((prev) => ({ ...prev, [name]: value }))
    }
  }

  // Filter flights based on search parameters and filters
  const getFilteredFlights = () => {
    // Check if the selected date is before today (2025-03-10)
    const isPastDate = searchParams.departDate < "2025-03-10"
    if (isPastDate) {
      return []
    }

    // Find flights that match the search criteria
    const matchingFlights = flightsData.filter((flight) => {
      // Match search parameters
      const matchesSearch =
        (searchParams.from === "" || flight.departureCity === searchParams.from) &&
        (searchParams.to === "" || flight.arrivalCity === searchParams.to) &&
        (searchParams.departDate === "" || flight.date === searchParams.departDate)

      // Match filters
      const matchesAirlines = filters.airlines.length === 0 || filters.airlines.includes(flight.airline)
      const matchesStops = filters.stops.length === 0 || filters.stops.includes(flight.stops)
      const matchesPrice =
        filters.maxPrice === "" || Number.parseInt(flight.price.replace(/,/g, "")) <= Number.parseInt(filters.maxPrice)

      return matchesSearch && matchesAirlines && matchesStops && matchesPrice
    })

    // If we have matching flights, return them
    if (matchingFlights.length > 0) {
      return matchingFlights
    }

    // If no matching flights and it's a future date, generate estimated flights
    if (!isPastDate && searchParams.departDate !== "") {
      const estimatedFlights = generateEstimatedFlights(searchParams.departDate, searchParams.from, searchParams.to)

      // Apply filters to estimated flights
      return estimatedFlights.filter((flight) => {
        const matchesAirlines = filters.airlines.length === 0 || filters.airlines.includes(flight.airline)
        const matchesStops = filters.stops.length === 0 || filters.stops.includes(flight.stops)
        const matchesPrice =
          filters.maxPrice === "" ||
          Number.parseInt(flight.price.replace(/,/g, "")) <= Number.parseInt(filters.maxPrice)

        return matchesAirlines && matchesStops && matchesPrice
      })
    }

    // Otherwise return empty array
    return []
  }

  // Get filtered flights
  const filteredFlights = getFilteredFlights()

  // Check if we're showing estimated results
  const isShowingEstimatedResults = searchParams.departDate > "2025-03-17" && filteredFlights.length > 0

  // Get unique airlines from flight data
  const airlines = Array.from(new Set(flightsData.map((flight) => flight.airline)))

  return (
    <div className="min-h-screen flex flex-col">
      <header className="bg-green-600 text-white py-4">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center gap-2">
              <Image
                src="https://mj-ahmad.github.io/mja2025/img/logo.png"
                alt="TRUSTED-ALLY Logo"
                width={40}
                height={40}
                className="h-10 w-auto"
              />
              <span className="font-bold text-xl">T-Ally Umrah Sr.</span>
            </Link>
            <nav className="hidden md:flex space-x-6">
              <Link href="/" className="hover:text-green-200 transition-colors">
                Home
              </Link>
              <Link href="/packages" className="hover:text-green-200 transition-colors">
                Packages
              </Link>
              <Link href="/services" className="hover:text-green-200 transition-colors">
                Services
              </Link>
              <Link href="/about" className="hover:text-green-200 transition-colors">
                About
              </Link>
              <Link href="/contact" className="hover:text-green-200 transition-colors">
                Contact
              </Link>
            </nav>
          </div>
        </div>
      </header>

      <main className="flex-grow">
        <section className="relative h-[40vh]">
          <Image
            src="https://mj-ahmad.github.io/mja2025/img/tr000.png"
            alt="Flight Services"
            fill
            className="object-cover"
          />
          <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
            <div className="text-center px-4">
              <h1 className="text-3xl md:text-5xl font-bold text-white mb-4">Flight Booking</h1>
              <p className="text-xl text-white/90 max-w-3xl mx-auto">
                Book your flights to Saudi Arabia for Umrah and Hajj
              </p>
            </div>
          </div>
        </section>

        <section className="py-8 bg-white">
          <div className="container mx-auto px-4">
            <div className="bg-white rounded-lg shadow-md p-6 -mt-16 relative z-10 mb-8">
              <div className="flex flex-wrap gap-4 mb-4">
                <div className="flex items-center">
                  <input
                    type="radio"
                    id="one-way"
                    name="tripType"
                    value="one-way"
                    checked={searchParams.tripType === "one-way"}
                    onChange={handleSearchChange}
                    className="h-4 w-4 text-green-600 focus:ring-green-500 border-gray-300"
                  />
                  <label htmlFor="one-way" className="ml-2 block text-sm text-gray-700">
                    One Way
                  </label>
                </div>
                <div className="flex items-center">
                  <input
                    type="radio"
                    id="round-trip"
                    name="tripType"
                    value="round-trip"
                    checked={searchParams.tripType === "round-trip"}
                    onChange={handleSearchChange}
                    className="h-4 w-4 text-green-600 focus:ring-green-500 border-gray-300"
                  />
                  <label htmlFor="round-trip" className="ml-2 block text-sm text-gray-700">
                    Round Trip
                  </label>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
                <div>
                  <label htmlFor="from" className="block text-sm font-medium text-gray-700 mb-1">
                    From
                  </label>
                  <select
                    id="from"
                    name="from"
                    value={searchParams.from}
                    onChange={handleSearchChange}
                    className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  >
                    <option value="Dhaka (DAC)">Dhaka (DAC)</option>
                    <option value="Chittagong (CGP)">Chittagong (CGP)</option>
                    <option value="Jeddah (JED)">Jeddah (JED)</option>
                    <option value="Madinah (MED)">Madinah (MED)</option>
                  </select>
                </div>
                <div>
                  <label htmlFor="to" className="block text-sm font-medium text-gray-700 mb-1">
                    To
                  </label>
                  <select
                    id="to"
                    name="to"
                    value={searchParams.to}
                    onChange={handleSearchChange}
                    className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  >
                    <option value="Jeddah (JED)">Jeddah (JED)</option>
                    <option value="Madinah (MED)">Madinah (MED)</option>
                    <option value="Dhaka (DAC)">Dhaka (DAC)</option>
                    <option value="Chittagong (CGP)">Chittagong (CGP)</option>
                  </select>
                </div>
                <div>
                  <label htmlFor="departDate" className="block text-sm font-medium text-gray-700 mb-1">
                    Depart Date
                  </label>
                  <input
                    type="date"
                    id="departDate"
                    name="departDate"
                    value={searchParams.departDate}
                    onChange={handleSearchChange}
                    className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  />
                </div>
                {searchParams.tripType === "round-trip" && (
                  <div>
                    <label htmlFor="returnDate" className="block text-sm font-medium text-gray-700 mb-1">
                      Return Date
                    </label>
                    <input
                      type="date"
                      id="returnDate"
                      name="returnDate"
                      value={searchParams.returnDate}
                      onChange={handleSearchChange}
                      className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    />
                  </div>
                )}
                <div>
                  <label htmlFor="passengers" className="block text-sm font-medium text-gray-700 mb-1">
                    Passengers
                  </label>
                  <select
                    id="passengers"
                    name="passengers"
                    value={searchParams.passengers}
                    onChange={handleSearchChange}
                    className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  >
                    {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((num) => (
                      <option key={num} value={num}>
                        {num} {num === 1 ? "Passenger" : "Passengers"}
                      </option>
                    ))}
                  </select>
                </div>
                <div className={searchParams.tripType === "round-trip" ? "lg:col-span-5" : "lg:col-span-1"}>
                  <button
                    type="button"
                    className="w-full bg-green-600 text-white py-2 px-4 rounded-md hover:bg-green-700 transition-colors mt-6"
                  >
                    Search Flights
                  </button>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
              <div className="lg:col-span-1">
                <div className="bg-white rounded-lg shadow-md p-6 sticky top-6">
                  <h2 className="text-xl font-bold mb-4">Filters</h2>
                  <div className="space-y-6">
                    <div>
                      <h3 className="font-semibold mb-2">Airlines</h3>
                      <div className="space-y-2">
                        {airlines.map((airline) => (
                          <div key={airline} className="flex items-center">
                            <input
                              type="checkbox"
                              id={`airline-${airline}`}
                              name="airline"
                              value={airline}
                              checked={filters.airlines.includes(airline)}
                              onChange={handleFilterChange}
                              className="h-4 w-4 text-green-600 focus:ring-green-500 border-gray-300 rounded"
                            />
                            <label htmlFor={`airline-${airline}`} className="ml-2 block text-sm text-gray-700">
                              {airline}
                            </label>
                          </div>
                        ))}
                      </div>
                    </div>
                    <div>
                      <h3 className="font-semibold mb-2">Stops</h3>
                      <div className="space-y-2">
                        <div className="flex items-center">
                          <input
                            type="checkbox"
                            id="stops-0"
                            name="stops"
                            value="0"
                            checked={filters.stops.includes(0)}
                            onChange={handleFilterChange}
                            className="h-4 w-4 text-green-600 focus:ring-green-500 border-gray-300 rounded"
                          />
                          <label htmlFor="stops-0" className="ml-2 block text-sm text-gray-700">
                            Direct
                          </label>
                        </div>
                        <div className="flex items-center">
                          <input
                            type="checkbox"
                            id="stops-1"
                            name="stops"
                            value="1"
                            checked={filters.stops.includes(1)}
                            onChange={handleFilterChange}
                            className="h-4 w-4 text-green-600 focus:ring-green-500 border-gray-300 rounded"
                          />
                          <label htmlFor="stops-1" className="ml-2 block text-sm text-gray-700">
                            1 Stop
                          </label>
                        </div>
                      </div>
                    </div>
                    <div>
                      <h3 className="font-semibold mb-2">Price Range</h3>
                      <div className="space-y-2">
                        <input
                          type="range"
                          id="maxPrice"
                          name="maxPrice"
                          min="50000"
                          max="100000"
                          step="5000"
                          value={filters.maxPrice || "100000"}
                          onChange={handleFilterChange}
                          className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
                        />
                        <div className="flex justify-between text-sm text-gray-600">
                          <span>৳50,000</span>
                          <span>
                            Max: ৳{filters.maxPrice ? Number.parseInt(filters.maxPrice).toLocaleString() : "100,000"}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="lg:col-span-3">
                <h2 className="text-2xl font-bold mb-4">Available Flights</h2>

                {isShowingEstimatedResults && (
                  <div className="bg-blue-50 border border-blue-200 text-blue-800 px-4 py-3 rounded mb-4">
                    <p className="font-medium">Showing estimated flight options for {searchParams.departDate}</p>
                    <p className="text-sm">
                      These are projected flights based on typical schedules. Actual availability may vary.
                    </p>
                  </div>
                )}

                {filteredFlights.length === 0 ? (
                  <div className="bg-white rounded-lg shadow-md p-6 text-center">
                    <p className="text-lg text-gray-600">No flights found matching your criteria.</p>
                    <p className="text-gray-500 mt-2">
                      {searchParams.departDate < "2025-03-10"
                        ? "You've selected a date in the past. Please select a current or future date."
                        : "Try adjusting your search parameters or filters."}
                    </p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {filteredFlights.map((flight) => (
                      <div key={flight.id} className="bg-white rounded-lg shadow-md p-6">
                        <div className="flex flex-col md:flex-row items-start md:items-center justify-between">
                          <div className="flex items-center mb-4 md:mb-0">
                            <div className="w-16 h-16 relative mr-4 flex-shrink-0">
                              <Image
                                src={getAirlineLogo(flight.airline) || "/placeholder.svg"}
                                alt={flight.airline}
                                fill
                                className="object-contain"
                              />
                            </div>
                            <div>
                              <p className="font-semibold text-lg">{flight.airline}</p>
                              <p className="text-gray-600">Flight {flight.flightNumber}</p>
                              <p className="text-gray-600">{flight.date}</p>
                            </div>
                          </div>
                          <div className="flex flex-col items-end">
                            <div className="flex items-center gap-4 mb-2">
                              <div className="text-right">
                                <p className="font-bold">{flight.departureTime}</p>
                                <p className="text-sm text-gray-600">{flight.departureCity}</p>
                              </div>
                              <div className="flex flex-col items-center">
                                <div className="text-xs text-gray-500">{flight.duration}</div>
                                <div className="w-20 h-px bg-gray-300 my-1 relative">
                                  <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-2 h-2 bg-gray-500 rounded-full"></div>
                                </div>
                                <div className="text-xs text-gray-500">
                                  {flight.stops === 0 ? "Direct" : `${flight.stops} Stop`}
                                </div>
                              </div>
                              <div>
                                <p className="font-bold">{flight.arrivalTime}</p>
                                <p className="text-sm text-gray-600">{flight.arrivalCity}</p>
                              </div>
                            </div>
                            <div className="flex items-center gap-4">
                              <p className="font-bold text-green-600">৳ {flight.price}</p>
                              <Link
                                href={`/book-flight/${flight.id}`}
                                className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700 transition-colors"
                              >
                                Book Now
                              </Link>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        </section>

        <section className="py-16 bg-gray-50">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto">
              <h2 className="text-3xl font-bold mb-6 text-center">Why Book Flights with Us?</h2>
              <div className="grid md:grid-cols-3 gap-8 mb-12">
                <div className="bg-white p-6 rounded-lg shadow-md text-center">
                  <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-4">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      className="h-8 w-8 text-white"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                      />
                    </svg>
                  </div>
                  <h3 className="text-xl font-bold mb-2">Best Prices</h3>
                  <p className="text-gray-600">
                    We offer competitive prices for flights to Saudi Arabia, with special discounts for Umrah and Hajj
                    pilgrims.
                  </p>
                </div>

                <div className="bg-white p-6 rounded-lg shadow-md text-center">
                  <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-4">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      className="h-8 w-8 text-white"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"
                      />
                    </svg>
                  </div>
                  <h3 className="text-xl font-bold mb-2">Secure Booking</h3>
                  <p className="text-gray-600">
                    Our secure booking system ensures that your personal and payment information is protected at all
                    times.
                  </p>
                </div>

                <div className="bg-white p-6 rounded-lg shadow-md text-center">
                  <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-4">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      className="h-8 w-8 text-white"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M18.364 5.636l-3.536 3.536m0 5.656l3.536 3.536M9.172 9.172L5.636 5.636m3.536 9.192l-3.536 3.536M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                      />
                    </svg>
                  </div>
                  <h3 className="text-xl font-bold mb-2">24/7 Support</h3>
                  <p className="text-gray-600">
                    Our dedicated customer support team is available 24/7 to assist you with any questions or issues.
                  </p>
                </div>
              </div>

              <div className="text-center">
                <p className="text-lg text-gray-700 mb-6">
                  We partner with major airlines to provide you with the best flight options for your Umrah and Hajj
                  journey. Our team of travel experts will help you find the most convenient and affordable flights to
                  Saudi Arabia.
                </p>
                <Link
                  href="/contact"
                  className="inline-block bg-green-600 text-white px-8 py-3 rounded-md font-medium hover:bg-green-700 transition-colors"
                >
                  Contact Us for More Information
                </Link>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}

