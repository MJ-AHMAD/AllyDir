"use client"

import Link from "next/link"
import Image from "next/image"

export default function PrivacyPolicyPage() {
  return (
    <div className="bg-white min-h-screen">
      <div className="max-w-4xl mx-auto p-8 bg-white shadow-lg my-8">
        {/* Header */}
        <div className="text-center mb-8 border-b-2 border-green-700 pb-4">
          <div className="flex justify-center mb-4">
            <div className="w-24 h-24 relative">
              <Image src="https://mj-ahmad.github.io/mja2025/img/logo.png" alt="T-ALLY Logo" width={96} height={96} />
            </div>
          </div>
          <h1 className="text-2xl font-bold text-green-800 mb-2">T-ALLY Hajj & Umrah Agency</h1>
          <p className="text-gray-600">Quraner Fariwala, 27 Purana Paltan, Dhaka-1000, BD</p>
          <h2 className="text-3xl font-bold mt-6 text-green-900">Privacy Policy</h2>
        </div>

        {/* Back button */}
        <div className="flex justify-end mb-6">
          <Link href="/" className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700">
            Return to Home Page
          </Link>
        </div>

        {/* Content */}
        <div className="space-y-6 text-gray-800">
          <div className="mb-6">
            <p className="text-sm text-gray-500 mb-4">Last Updated: {new Date().toLocaleDateString()}</p>
            <p className="mb-4">
              T-ALLY Hajj & Umrah Agency respects your privacy and is committed to protecting your personal information.
              This Privacy Policy explains how we collect, use, and disclose your information when you use our website
              and services.
            </p>
            <p>
              By using our website, you agree to the data collection and usage practices described in this Privacy
              Policy.
            </p>
          </div>

          <section className="mb-8">
            <h3 className="text-xl font-semibold mb-4 text-green-800">1. Information Collection</h3>
            <p className="mb-4">We may collect the following types of information:</p>
            <ul className="list-disc pl-6 space-y-2">
              <li>
                <strong>Personal Information:</strong> Your name, address, email, phone number, date of birth, passport
                details (required for Hajj and Umrah visas), and payment information.
              </li>
              <li>
                <strong>Log Data:</strong> IP address, browser type, pages visited, time and date of visit, and other
                statistics.
              </li>
              <li>
                <strong>Cookies:</strong> We use cookies to enhance your experience.
              </li>
              <li>
                <strong>Investment Information:</strong> For investors, we may collect financial information and
                investment preferences.
              </li>
            </ul>
          </section>

          <section className="mb-8">
            <h3 className="text-xl font-semibold mb-4 text-green-800">2. Information Usage</h3>
            <p className="mb-4">We may use the collected information for the following purposes:</p>
            <ul className="list-disc pl-6 space-y-2">
              <li>To provide you with Hajj, Umrah, and other services</li>
              <li>To process your orders and bookings</li>
              <li>To create and manage your account</li>
              <li>To respond to your questions and requests</li>
              <li>To inform you about new offers, updates, and promotions (if you consent)</li>
              <li>To improve our website and services</li>
              <li>To prevent fraud and unauthorized access</li>
              <li>For investors, to manage their investments</li>
            </ul>
          </section>

          <section className="mb-8">
            <h3 className="text-xl font-semibold mb-4 text-green-800">3. Information Disclosure</h3>
            <p className="mb-4">We may share your personal information in the following circumstances:</p>
            <ul className="list-disc pl-6 space-y-2">
              <li>
                <strong>Service Providers:</strong> With Saudi authorities, airlines, hotels, and other necessary
                parties for providing Hajj and Umrah services.
              </li>
              <li>
                <strong>Legal Requirements:</strong> When disclosure is required by law, court order, or government
                request.
              </li>
              <li>
                <strong>Business Transfer:</strong> In case of merger, acquisition, or sale of our assets, your
                information may be transferred.
              </li>
              <li>
                <strong>Your Consent:</strong> When you consent to the disclosure of information.
              </li>
            </ul>
            <p className="mt-4">
              We will never sell or rent your personal information to third parties for commercial purposes without your
              permission.
            </p>
          </section>

          <section className="mb-8">
            <h3 className="text-xl font-semibold mb-4 text-green-800">4. Data Protection</h3>
            <p className="mb-4">
              We implement reasonable security measures to protect your personal information. However, no data
              transmission over the Internet or electronic storage is 100% secure. We use commercially acceptable
              methods to protect your information, but cannot guarantee its absolute security.
            </p>
          </section>

          <section className="mb-8">
            <h3 className="text-xl font-semibold mb-4 text-green-800">5. Your Rights</h3>
            <p className="mb-4">You have the following rights regarding your personal information:</p>
            <ul className="list-disc pl-6 space-y-2">
              <li>The right to access and receive a copy of your personal information</li>
              <li>The right to rectify your personal information</li>
              <li>The right to request deletion of your personal information</li>
              <li>The right to opt-out of marketing communications</li>
              <li>The right to request restrictions on the processing of your information</li>
            </ul>
            <p className="mt-4">To exercise these rights, please contact us.</p>
          </section>

          <section className="mb-8">
            <h3 className="text-xl font-semibold mb-4 text-green-800">6. Cookie Policy</h3>
            <p className="mb-4">
              We use cookies on our website. Cookies are small text files that are temporarily stored on your device.
              Cookies help remember your details and improve your website experience.
            </p>
          </section>
        </div>
      </div>
    </div>
  )
}

