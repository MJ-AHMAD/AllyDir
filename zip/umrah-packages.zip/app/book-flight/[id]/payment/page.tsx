"use client"

import type React from "react"

import { useState, useEffect } from "react"
import Image from "next/image"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { Footer } from "@/components/footer"

// Flight data structure
interface FlightInfo {
  id: string
  airline: string
  flightNumber: string
  departureCity: string
  arrivalCity: string
  departureTime: string
  arrivalTime: string
  duration: string
  price: string
  stops: number
  date: string
}

// Sample flight data
const flightsData: Record<string, FlightInfo> = {
  // DAC - JED (Dhaka to Jeddah) flights
  "biman-dhaka-jeddah-20250310": {
    id: "biman-dhaka-jeddah-20250310",
    airline: "Biman Bangladesh",
    flightNumber: "BG-335",
    departureCity: "Dhaka (DAC)",
    arrivalCity: "Jeddah (JED)",
    departureTime: "10:30",
    arrivalTime: "14:45",
    duration: "6h 15m",
    price: "65,000",
    stops: 0,
    date: "2025-03-10",
  },
  "emirates-dhaka-jeddah-20250310": {
    id: "emirates-dhaka-jeddah-20250310",
    airline: "Emirates",
    flightNumber: "EK-585",
    departureCity: "Dhaka (DAC)",
    arrivalCity: "Jeddah (JED)",
    departureTime: "09:15",
    arrivalTime: "15:30",
    duration: "8h 15m",
    stops: 1,
    price: "85,000",
    date: "2025-03-10",
  },
  // Add more flights as needed
}

// Get airline logo URL
const getAirlineLogo = (airline: string): string => {
  const logos: Record<string, string> = {
    "Biman Bangladesh": "https://mj-ahmad.github.io/mja2025/img/biman-logo.png",
    Emirates: "https://mj-ahmad.github.io/mja2025/img/emirates-logo.png",
    Flynas: "https://mj-ahmad.github.io/mja2025/img/flynas-logo.png",
    "Qatar Airways": "https://mj-ahmad.github.io/mja2025/img/qatar-logo.png",
    Saudia: "https://mj-ahmad.github.io/mja2025/img/saudia-logo.png",
    "US-Bangla Airlines": "https://mj-ahmad.github.io/mja2025/img/usbangla-logo.png",
  }
  return logos[airline] || "/placeholder.svg?height=40&width=120"
}

export default function PaymentPage({ params }: { params: { id: string } }) {
  const router = useRouter()
  const flight = flightsData[params.id]

  const [formData, setFormData] = useState({
    cardNumber: "",
    cardholderName: "",
    expiryDate: "",
    cvv: "",
    saveCard: false,
  })

  const [isSubmitting, setIsSubmitting] = useState(false)
  const [errors, setErrors] = useState<Record<string, string>>({})

  // Retrieve passenger data from localStorage
  const [passengerData, setPassengerData] = useState<any>(null)

  useEffect(() => {
    // Get passenger data from localStorage
    const storedData = localStorage.getItem(`passenger_${params.id}`)
    if (storedData) {
      setPassengerData(JSON.parse(storedData))
    }
  }, [params.id])

  if (!flight) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center">
        <h1 className="text-2xl font-bold mb-4">Flight Not Found</h1>
        <p className="mb-6">Sorry, the flight you are looking for does not exist.</p>
        <Link
          href="/services/flights"
          className="bg-green-600 text-white px-6 py-2 rounded-md hover:bg-green-700 transition-colors"
        >
          Back to Flights
        </Link>
      </div>
    )
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type, checked } = e.target
    setFormData((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value,
    }))

    // Clear error when field is edited
    if (errors[name]) {
      setErrors((prev) => {
        const newErrors = { ...prev }
        delete newErrors[name]
        return newErrors
      })
    }
  }

  const validateForm = () => {
    const newErrors: Record<string, string> = {}

    if (!formData.cardNumber.trim()) {
      newErrors.cardNumber = "Card number is required"
    } else if (!/^\d{16}$/.test(formData.cardNumber.replace(/\s/g, ""))) {
      newErrors.cardNumber = "Card number must be 16 digits"
    }

    if (!formData.cardholderName.trim()) {
      newErrors.cardholderName = "Cardholder name is required"
    }

    if (!formData.expiryDate.trim()) {
      newErrors.expiryDate = "Expiry date is required"
    } else if (!/^\d{2}\/\d{2}$/.test(formData.expiryDate)) {
      newErrors.expiryDate = "Expiry date must be in MM/YY format"
    }

    if (!formData.cvv.trim()) {
      newErrors.cvv = "CVV is required"
    } else if (!/^\d{3,4}$/.test(formData.cvv)) {
      newErrors.cvv = "CVV must be 3 or 4 digits"
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!validateForm()) {
      return
    }

    setIsSubmitting(true)

    try {
      // Simulate payment processing
      await new Promise((resolve) => setTimeout(resolve, 2000))

      // Redirect to success page
      router.push(`/book-flight/${params.id}/success`)
    } catch (error) {
      console.error("Payment error:", error)
      setIsSubmitting(false)
      alert("There was an error processing your payment. Please try again.")
    }
  }

  // Calculate price breakdown
  const basePrice = Number.parseInt(flight.price.replace(/,/g, "")) - 3500
  const taxesAndFees = 3500
  const totalPrice = basePrice + taxesAndFees

  return (
    <div className="min-h-screen flex flex-col">
      <header className="bg-green-600 text-white py-4">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center gap-2">
              <Image
                src="https://mj-ahmad.github.io/mja2025/img/logo.png"
                alt="TRUSTED-ALLY Logo"
                width={40}
                height={40}
                className="h-10 w-auto"
              />
              <span className="font-bold text-xl">T-Ally Umrah Sr.</span>
            </Link>
            <nav className="hidden md:flex space-x-6">
              <Link href="/" className="hover:text-green-200 transition-colors">
                Home
              </Link>
              <Link href="/packages" className="hover:text-green-200 transition-colors">
                Packages
              </Link>
              <Link href="/services" className="hover:text-green-200 transition-colors">
                Services
              </Link>
              <Link href="/about" className="hover:text-green-200 transition-colors">
                About
              </Link>
              <Link href="/contact" className="hover:text-green-200 transition-colors">
                Contact
              </Link>
            </nav>
          </div>
        </div>
      </header>

      <main className="flex-grow py-12">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h1 className="text-3xl font-bold mb-2">Payment</h1>
            <p className="text-gray-600 mb-8">Complete your payment to confirm your flight booking</p>

            <div className="bg-gray-50 p-6 rounded-lg mb-8">
              <h2 className="font-bold text-xl mb-4">Flight Details</h2>
              <div className="flex flex-col md:flex-row items-start md:items-center justify-between">
                <div className="flex items-center mb-4 md:mb-0">
                  <div className="w-16 h-16 relative mr-4 flex-shrink-0">
                    <Image
                      src={getAirlineLogo(flight.airline) || "/placeholder.svg"}
                      alt={flight.airline}
                      fill
                      className="object-contain"
                    />
                  </div>
                  <div>
                    <p className="font-semibold text-lg">{flight.airline}</p>
                    <p className="text-gray-600">Flight {flight.flightNumber}</p>
                    <p className="text-gray-600">{flight.date}</p>
                  </div>
                </div>
                <div className="flex flex-col items-end">
                  <div className="flex items-center gap-4 mb-2">
                    <div className="text-right">
                      <p className="font-bold">{flight.departureTime}</p>
                      <p className="text-sm text-gray-600">{flight.departureCity}</p>
                    </div>
                    <div className="flex flex-col items-center">
                      <div className="text-xs text-gray-500">{flight.duration}</div>
                      <div className="w-20 h-px bg-gray-300 my-1 relative">
                        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-2 h-2 bg-gray-500 rounded-full"></div>
                      </div>
                      <div className="text-xs text-gray-500">
                        {flight.stops === 0 ? "Direct" : `${flight.stops} Stop`}
                      </div>
                    </div>
                    <div>
                      <p className="font-bold">{flight.arrivalTime}</p>
                      <p className="text-sm text-gray-600">{flight.arrivalCity}</p>
                    </div>
                  </div>
                  <p className="font-bold text-green-600">৳ {flight.price}</p>
                </div>
              </div>
            </div>

            {passengerData && (
              <div className="bg-white p-6 rounded-lg shadow-md mb-8">
                <h3 className="text-xl font-semibold mb-4">Passenger Information</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-gray-500">Name</p>
                    <p className="font-medium">
                      {passengerData.title} {passengerData.firstName} {passengerData.lastName}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Email</p>
                    <p className="font-medium">{passengerData.email}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Phone</p>
                    <p className="font-medium">{passengerData.phone}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Passport</p>
                    <p className="font-medium">{passengerData.passportNumber}</p>
                  </div>
                </div>
              </div>
            )}

            <div className="bg-white p-6 rounded-lg shadow-md mb-8">
              <h3 className="text-xl font-semibold mb-4">Price Summary</h3>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span>Base Fare</span>
                  <span>৳ {basePrice.toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span>Taxes & Fees</span>
                  <span>৳ {taxesAndFees.toLocaleString()}</span>
                </div>
                <div className="border-t pt-2 mt-2 flex justify-between font-bold">
                  <span>Total</span>
                  <span>৳ {totalPrice.toLocaleString()}</span>
                </div>
              </div>
            </div>

            <form onSubmit={handleSubmit} className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-semibold mb-4">Payment Details</h3>
              <div className="space-y-4">
                <div>
                  <label htmlFor="cardNumber" className="block text-sm font-medium text-gray-700 mb-1">
                    Card Number
                  </label>
                  <input
                    type="text"
                    id="cardNumber"
                    name="cardNumber"
                    placeholder="1234 5678 9012 3456"
                    value={formData.cardNumber}
                    onChange={handleChange}
                    className={`w-full px-4 py-2 border ${
                      errors.cardNumber ? "border-red-500" : "border-gray-300"
                    } rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent`}
                  />
                  {errors.cardNumber && <p className="mt-1 text-sm text-red-600">{errors.cardNumber}</p>}
                </div>

                <div>
                  <label htmlFor="cardholderName" className="block text-sm font-medium text-gray-700 mb-1">
                    Cardholder Name
                  </label>
                  <input
                    type="text"
                    id="cardholderName"
                    name="cardholderName"
                    placeholder="John Doe"
                    value={formData.cardholderName}
                    onChange={handleChange}
                    className={`w-full px-4 py-2 border ${
                      errors.cardholderName ? "border-red-500" : "border-gray-300"
                    } rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent`}
                  />
                  {errors.cardholderName && <p className="mt-1 text-sm text-red-600">{errors.cardholderName}</p>}
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="expiryDate" className="block text-sm font-medium text-gray-700 mb-1">
                      Expiry Date
                    </label>
                    <input
                      type="text"
                      id="expiryDate"
                      name="expiryDate"
                      placeholder="MM/YY"
                      value={formData.expiryDate}
                      onChange={handleChange}
                      className={`w-full px-4 py-2 border ${
                        errors.expiryDate ? "border-red-500" : "border-gray-300"
                      } rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent`}
                    />
                    {errors.expiryDate && <p className="mt-1 text-sm text-red-600">{errors.expiryDate}</p>}
                  </div>

                  <div>
                    <label htmlFor="cvv" className="block text-sm font-medium text-gray-700 mb-1">
                      CVV
                    </label>
                    <input
                      type="text"
                      id="cvv"
                      name="cvv"
                      placeholder="123"
                      value={formData.cvv}
                      onChange={handleChange}
                      className={`w-full px-4 py-2 border ${
                        errors.cvv ? "border-red-500" : "border-gray-300"
                      } rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent`}
                    />
                    {errors.cvv && <p className="mt-1 text-sm text-red-600">{errors.cvv}</p>}
                  </div>
                </div>

                <div className="flex items-center">
                  <input
                    type="checkbox"
                    id="saveCard"
                    name="saveCard"
                    checked={formData.saveCard}
                    onChange={handleChange}
                    className="h-4 w-4 text-green-600 focus:ring-green-500 border-gray-300 rounded"
                  />
                  <label htmlFor="saveCard" className="ml-2 block text-sm text-gray-700">
                    Save this card for future payments
                  </label>
                </div>

                <div className="flex items-center">
                  <input
                    type="checkbox"
                    id="terms"
                    required
                    className="h-4 w-4 text-green-600 focus:ring-green-500 border-gray-300 rounded"
                  />
                  <label htmlFor="terms" className="ml-2 block text-sm text-gray-700">
                    I agree to the{" "}
                    <Link href="/terms" className="text-green-600 hover:underline">
                      Terms and Conditions
                    </Link>{" "}
                    and{" "}
                    <Link href="/privacy" className="text-green-600 hover:underline">
                      Privacy Policy
                    </Link>
                  </label>
                </div>

                <div>
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className={`w-full bg-green-600 text-white py-3 rounded-md font-medium transition-colors ${
                      isSubmitting ? "opacity-70 cursor-not-allowed" : "hover:bg-green-700"
                    }`}
                  >
                    {isSubmitting ? "Processing Payment..." : "Pay ৳ " + totalPrice.toLocaleString()}
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}

