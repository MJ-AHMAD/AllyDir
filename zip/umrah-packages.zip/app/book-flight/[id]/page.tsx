"use client"

import type React from "react"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { Footer } from "@/components/footer"

// Flight data structure
interface FlightInfo {
  id: string
  airline: string
  flightNumber: string
  departureCity: string
  arrivalCity: string
  departureTime: string
  arrivalTime: string
  duration: string
  price: string
  stops: number
  date: string
}

// Sample flight data
const flightsData: Record<string, FlightInfo> = {
  // DAC - JED (Dhaka to Jeddah) flights
  "biman-dhaka-jeddah-20250310": {
    id: "biman-dhaka-jeddah-20250310",
    airline: "Biman Bangladesh",
    flightNumber: "BG-335",
    departureCity: "Dhaka (DAC)",
    arrivalCity: "Jeddah (JED)",
    departureTime: "10:30",
    arrivalTime: "14:45",
    duration: "6h 15m",
    price: "65,000",
    stops: 0,
    date: "2025-03-10",
  },
  "emirates-dhaka-jeddah-20250310": {
    id: "emirates-dhaka-jeddah-20250310",
    airline: "Emirates",
    flightNumber: "EK-585",
    departureCity: "Dhaka (DAC)",
    arrivalCity: "Jeddah (JED)",
    departureTime: "09:15",
    arrivalTime: "15:30",
    duration: "8h 15m",
    stops: 1,
    price: "85,000",
    date: "2025-03-10",
  },
  "saudia-dhaka-jeddah-20250310": {
    id: "saudia-dhaka-jeddah-20250310",
    airline: "Saudia",
    flightNumber: "SV-803",
    departureCity: "Dhaka (DAC)",
    arrivalCity: "Jeddah (JED)",
    departureTime: "11:45",
    arrivalTime: "16:20",
    duration: "6h 35m",
    stops: 0,
    price: "72,000",
    date: "2025-03-10",
  },
  "biman-dhaka-jeddah-20250311": {
    id: "biman-dhaka-jeddah-20250311",
    airline: "Biman Bangladesh",
    flightNumber: "BG-336",
    departureCity: "Dhaka (DAC)",
    arrivalCity: "Jeddah (JED)",
    departureTime: "11:30",
    arrivalTime: "15:45",
    duration: "6h 15m",
    price: "66,000",
    stops: 0,
    date: "2025-03-11",
  },
  "qatar-dhaka-jeddah-20250312": {
    id: "qatar-dhaka-jeddah-20250312",
    airline: "Qatar Airways",
    flightNumber: "QR-643",
    departureCity: "Dhaka (DAC)",
    arrivalCity: "Jeddah (JED)",
    departureTime: "08:05",
    arrivalTime: "16:50",
    duration: "10h 45m",
    stops: 1,
    price: "92,000",
    date: "2025-03-12",
  },

  // DAC - MED (Dhaka to Madinah) flights
  "biman-dhaka-madinah-20250310": {
    id: "biman-dhaka-madinah-20250310",
    airline: "Biman Bangladesh",
    flightNumber: "BG-337",
    departureCity: "Dhaka (DAC)",
    arrivalCity: "Madinah (MED)",
    departureTime: "11:30",
    arrivalTime: "16:15",
    duration: "6h 45m",
    stops: 0,
    price: "67,000",
    date: "2025-03-10",
  },
  "emirates-dhaka-madinah-20250311": {
    id: "emirates-dhaka-madinah-20250311",
    airline: "Emirates",
    flightNumber: "EK-587",
    departureCity: "Dhaka (DAC)",
    arrivalCity: "Madinah (MED)",
    departureTime: "10:15",
    arrivalTime: "17:30",
    duration: "9h 15m",
    stops: 1,
    price: "88,000",
    date: "2025-03-11",
  },

  // JED - DAC (Jeddah to Dhaka) flights
  "biman-jeddah-dhaka-20250310": {
    id: "biman-jeddah-dhaka-20250310",
    airline: "Biman Bangladesh",
    flightNumber: "BG-336",
    departureCity: "Jeddah (JED)",
    arrivalCity: "Dhaka (DAC)",
    departureTime: "16:30",
    arrivalTime: "04:45",
    duration: "8h 15m",
    stops: 0,
    price: "68,000",
    date: "2025-03-10",
  },
  "emirates-jeddah-dhaka-20250311": {
    id: "emirates-jeddah-dhaka-20250311",
    airline: "Emirates",
    flightNumber: "EK-586",
    departureCity: "Jeddah (JED)",
    arrivalCity: "Dhaka (DAC)",
    departureTime: "17:15",
    arrivalTime: "07:30",
    duration: "10h 15m",
    stops: 1,
    price: "88,000",
    date: "2025-03-11",
  },

  // MED - DAC (Madinah to Dhaka) flights
  "biman-madinah-dhaka-20250310": {
    id: "biman-madinah-dhaka-20250310",
    airline: "Biman Bangladesh",
    flightNumber: "BG-338",
    departureCity: "Madinah (MED)",
    arrivalCity: "Dhaka (DAC)",
    departureTime: "18:30",
    arrivalTime: "05:15",
    duration: "8h 45m",
    stops: 0,
    price: "69,000",
    date: "2025-03-10",
  },
  "emirates-madinah-dhaka-20250311": {
    id: "emirates-madinah-dhaka-20250311",
    airline: "Emirates",
    flightNumber: "EK-588",
    departureCity: "Madinah (MED)",
    arrivalCity: "Dhaka (DAC)",
    departureTime: "19:15",
    arrivalTime: "08:30",
    duration: "11h 15m",
    stops: 1,
    price: "90,000",
    date: "2025-03-11",
  },

  // CGP - JED (Chittagong to Jeddah) flights
  "biman-chittagong-jeddah-20250310": {
    id: "biman-chittagong-jeddah-20250310",
    airline: "Biman Bangladesh",
    flightNumber: "BG-341",
    departureCity: "Chittagong (CGP)",
    arrivalCity: "Jeddah (JED)",
    departureTime: "09:30",
    arrivalTime: "14:45",
    duration: "7h 15m",
    stops: 0,
    price: "67,000",
    date: "2025-03-10",
  },
  "emirates-chittagong-jeddah-20250311": {
    id: "emirates-chittagong-jeddah-20250311",
    airline: "Emirates",
    flightNumber: "EK-591",
    departureCity: "Chittagong (CGP)",
    arrivalCity: "Jeddah (JED)",
    departureTime: "08:15",
    arrivalTime: "15:30",
    duration: "9h 15m",
    stops: 1,
    price: "87,000",
    date: "2025-03-11",
  },

  // CGP - MED (Chittagong to Madinah) flights
  "biman-chittagong-madinah-20250310": {
    id: "biman-chittagong-madinah-20250310",
    airline: "Biman Bangladesh",
    flightNumber: "BG-343",
    departureCity: "Chittagong (CGP)",
    arrivalCity: "Madinah (MED)",
    departureTime: "10:30",
    arrivalTime: "16:15",
    duration: "7h 45m",
    stops: 0,
    price: "69,000",
    date: "2025-03-10",
  },
  "emirates-chittagong-madinah-20250311": {
    id: "emirates-chittagong-madinah-20250311",
    airline: "Emirates",
    flightNumber: "EK-593",
    departureCity: "Chittagong (CGP)",
    arrivalCity: "Madinah (MED)",
    departureTime: "09:15",
    arrivalTime: "17:30",
    duration: "10h 15m",
    stops: 1,
    price: "90,000",
    date: "2025-03-11",
  },

  // JED - CGP (Jeddah to Chittagong) flights
  "biman-jeddah-chittagong-20250310": {
    id: "biman-jeddah-chittagong-20250310",
    airline: "Biman Bangladesh",
    flightNumber: "BG-345",
    departureCity: "Jeddah (JED)",
    arrivalCity: "Chittagong (CGP)",
    departureTime: "16:30",
    arrivalTime: "05:45",
    duration: "9h 15m",
    stops: 0,
    price: "70,000",
    date: "2025-03-10",
  },
  "emirates-jeddah-chittagong-20250311": {
    id: "emirates-jeddah-chittagong-20250311",
    airline: "Emirates",
    flightNumber: "EK-595",
    departureCity: "Jeddah (JED)",
    arrivalCity: "Chittagong (CGP)",
    departureTime: "17:15",
    arrivalTime: "08:30",
    duration: "11h 15m",
    stops: 1,
    price: "91,000",
    date: "2025-03-11",
  },

  // MED - CGP (Madinah to Chittagong) flights
  "biman-madinah-chittagong-20250310": {
    id: "biman-madinah-chittagong-20250310",
    airline: "Biman Bangladesh",
    flightNumber: "BG-347",
    departureCity: "Madinah (MED)",
    arrivalCity: "Chittagong (CGP)",
    departureTime: "18:30",
    arrivalTime: "06:15",
    duration: "9h 45m",
    stops: 0,
    price: "71,000",
    date: "2025-03-10",
  },
  "emirates-madinah-chittagong-20250311": {
    id: "emirates-madinah-chittagong-20250311",
    airline: "Emirates",
    flightNumber: "EK-597",
    departureCity: "Madinah (MED)",
    arrivalCity: "Chittagong (CGP)",
    departureTime: "19:15",
    arrivalTime: "09:30",
    duration: "12h 15m",
    stops: 1,
    price: "93,000",
    date: "2025-03-11",
  },
}

// Get airline logo URL
const getAirlineLogo = (airline: string): string => {
  const logos: Record<string, string> = {
    "Biman Bangladesh": "https://mj-ahmad.github.io/mja2025/img/biman-logo.png",
    Emirates: "https://mj-ahmad.github.io/mja2025/img/emirates-logo.png",
    Flynas: "https://mj-ahmad.github.io/mja2025/img/flynas-logo.png",
    "Qatar Airways": "https://mj-ahmad.github.io/mja2025/img/qatar-logo.png",
    Saudia: "https://mj-ahmad.github.io/mja2025/img/saudia-logo.png",
    "US-Bangla Airlines": "https://mj-ahmad.github.io/mja2025/img/usbangla-logo.png",
  }
  return logos[airline] || "/placeholder.svg?height=40&width=120"
}

export default function BookFlightPage({ params }: { params: { id: string } }) {
  const router = useRouter()
  const flight = flightsData[params.id]

  const [formData, setFormData] = useState({
    passengerType: "adult",
    title: "Mr",
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    passportNumber: "",
    nationality: "",
    dateOfBirth: "",
    passportExpiry: "",
    specialRequests: "",
  })

  const [isSubmitting, setIsSubmitting] = useState(false)

  if (!flight) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center">
        <h1 className="text-2xl font-bold mb-4">Flight Not Found</h1>
        <p className="mb-6">Sorry, the flight you are looking for does not exist.</p>
        <Link
          href="/services/flights"
          className="bg-green-600 text-white px-6 py-2 rounded-md hover:bg-green-700 transition-colors"
        >
          Back to Flights
        </Link>
      </div>
    )
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // Redirect to payment page
      router.push(`/book-flight/${params.id}/payment`)
    } catch (error) {
      console.error("Booking error:", error)
      setIsSubmitting(false)
      alert("There was an error processing your booking. Please try again.")
    }
  }

  return (
    <div className="min-h-screen flex flex-col">
      <header className="bg-green-600 text-white py-4">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center gap-2">
              <Image
                src="https://mj-ahmad.github.io/mja2025/img/logo.png"
                alt="TRUSTED-ALLY Logo"
                width={40}
                height={40}
                className="h-10 w-auto"
              />
              <span className="font-bold text-xl">T-Ally Umrah Sr.</span>
            </Link>
            <nav className="hidden md:flex space-x-6">
              <Link href="/" className="hover:text-green-200 transition-colors">
                Home
              </Link>
              <Link href="/packages" className="hover:text-green-200 transition-colors">
                Packages
              </Link>
              <Link href="/services" className="hover:text-green-200 transition-colors">
                Services
              </Link>
              <Link href="/about" className="hover:text-green-200 transition-colors">
                About
              </Link>
              <Link href="/contact" className="hover:text-green-200 transition-colors">
                Contact
              </Link>
            </nav>
          </div>
        </div>
      </header>

      <main className="flex-grow py-12">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h1 className="text-3xl font-bold mb-2">Book Your Flight</h1>
            <p className="text-gray-600 mb-8">Fill out the form below to book your flight</p>

            <div className="bg-gray-50 p-6 rounded-lg mb-8">
              <h2 className="font-bold text-xl mb-4">Flight Details</h2>
              <div className="flex flex-col md:flex-row items-start md:items-center justify-between">
                <div className="flex items-center mb-4 md:mb-0">
                  <div className="w-16 h-16 relative mr-4 flex-shrink-0">
                    <Image
                      src={getAirlineLogo(flight.airline) || "/placeholder.svg"}
                      alt={flight.airline}
                      fill
                      className="object-contain"
                    />
                  </div>
                  <div>
                    <p className="font-semibold text-lg">{flight.airline}</p>
                    <p className="text-gray-600">Flight {flight.flightNumber}</p>
                    <p className="text-gray-600">{flight.date}</p>
                  </div>
                </div>
                <div className="flex flex-col items-end">
                  <div className="flex items-center gap-4 mb-2">
                    <div className="text-right">
                      <p className="font-bold">{flight.departureTime}</p>
                      <p className="text-sm text-gray-600">{flight.departureCity}</p>
                    </div>
                    <div className="flex flex-col items-center">
                      <div className="text-xs text-gray-500">{flight.duration}</div>
                      <div className="w-20 h-px bg-gray-300 my-1 relative">
                        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-2 h-2 bg-gray-500 rounded-full"></div>
                      </div>
                      <div className="text-xs text-gray-500">
                        {flight.stops === 0 ? "Direct" : `${flight.stops} Stop`}
                      </div>
                    </div>
                    <div>
                      <p className="font-bold">{flight.arrivalTime}</p>
                      <p className="text-sm text-gray-600">{flight.arrivalCity}</p>
                    </div>
                  </div>
                  <p className="font-bold text-green-600">৳ {flight.price}</p>
                </div>
              </div>
            </div>

            <form onSubmit={handleSubmit} className="space-y-8">
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-semibold mb-4">Passenger Information</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label htmlFor="passengerType" className="block text-sm font-medium text-gray-700 mb-1">
                      Passenger Type
                    </label>
                    <select
                      id="passengerType"
                      name="passengerType"
                      value={formData.passengerType}
                      onChange={handleChange}
                      className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    >
                      <option value="adult">Adult (12+ years)</option>
                      <option value="child">Child (2-11 years)</option>
                      <option value="infant">Infant (0-23 months)</option>
                    </select>
                  </div>

                  <div>
                    <label htmlFor="title" className="block text-sm font-medium text-gray-700 mb-1">
                      Title
                    </label>
                    <select
                      id="title"
                      name="title"
                      value={formData.title}
                      onChange={handleChange}
                      className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    >
                      <option value="Mr">Mr</option>
                      <option value="Mrs">Mrs</option>
                      <option value="Ms">Ms</option>
                      <option value="Dr">Dr</option>
                    </select>
                  </div>

                  <div>
                    <label htmlFor="firstName" className="block text-sm font-medium text-gray-700 mb-1">
                      First Name (as in Passport)
                    </label>
                    <input
                      type="text"
                      id="firstName"
                      name="firstName"
                      value={formData.firstName}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    />
                  </div>

                  <div>
                    <label htmlFor="lastName" className="block text-sm font-medium text-gray-700 mb-1">
                      Last Name (as in Passport)
                    </label>
                    <input
                      type="text"
                      id="lastName"
                      name="lastName"
                      value={formData.lastName}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    />
                  </div>

                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                      Email Address
                    </label>
                    <input
                      type="email"
                      id="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    />
                  </div>

                  <div>
                    <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-1">
                      Phone Number
                    </label>
                    <input
                      type="tel"
                      id="phone"
                      name="phone"
                      value={formData.phone}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    />
                  </div>

                  <div>
                    <label htmlFor="nationality" className="block text-sm font-medium text-gray-700 mb-1">
                      Nationality
                    </label>
                    <input
                      type="text"
                      id="nationality"
                      name="nationality"
                      value={formData.nationality}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    />
                  </div>

                  <div>
                    <label htmlFor="dateOfBirth" className="block text-sm font-medium text-gray-700 mb-1">
                      Date of Birth
                    </label>
                    <input
                      type="date"
                      id="dateOfBirth"
                      name="dateOfBirth"
                      value={formData.dateOfBirth}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    />
                  </div>

                  <div>
                    <label htmlFor="passportNumber" className="block text-sm font-medium text-gray-700 mb-1">
                      Passport Number
                    </label>
                    <input
                      type="text"
                      id="passportNumber"
                      name="passportNumber"
                      value={formData.passportNumber}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    />
                  </div>

                  <div>
                    <label htmlFor="passportExpiry" className="block text-sm font-medium text-gray-700 mb-1">
                      Passport Expiry Date
                    </label>
                    <input
                      type="date"
                      id="passportExpiry"
                      name="passportExpiry"
                      value={formData.passportExpiry}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    />
                  </div>
                </div>
              </div>

              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-semibold mb-4">Additional Information</h3>
                <div>
                  <label htmlFor="specialRequests" className="block text-sm font-medium text-gray-700 mb-1">
                    Special Requests (Optional)
                  </label>
                  <textarea
                    id="specialRequests"
                    name="specialRequests"
                    value={formData.specialRequests}
                    onChange={handleChange}
                    rows={4}
                    placeholder="Meal preferences, wheelchair assistance, etc."
                    className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  ></textarea>
                </div>
              </div>

              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-semibold mb-4">Price Summary</h3>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span>Base Fare</span>
                    <span>৳ {Number.parseInt(flight.price.replace(/,/g, "")) - 3500}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Taxes & Fees</span>
                    <span>৳ 3,500</span>
                  </div>
                  <div className="border-t pt-2 mt-2 flex justify-between font-bold">
                    <span>Total</span>
                    <span>৳ {flight.price}</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center">
                <input
                  type="checkbox"
                  id="terms"
                  required
                  className="h-4 w-4 text-green-600 focus:ring-green-500 border-gray-300 rounded"
                />
                <label htmlFor="terms" className="ml-2 block text-sm text-gray-700">
                  I agree to the{" "}
                  <Link href="/terms" className="text-green-600 hover:underline">
                    Terms and Conditions
                  </Link>{" "}
                  and{" "}
                  <Link href="/privacy" className="text-green-600 hover:underline">
                    Privacy Policy
                  </Link>
                </label>
              </div>

              <div>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className={`w-full bg-green-600 text-white py-3 rounded-md font-medium transition-colors ${
                    isSubmitting ? "opacity-70 cursor-not-allowed" : "hover:bg-green-700"
                  }`}
                >
                  {isSubmitting ? "Processing..." : "Proceed to Payment"}
                </button>
              </div>
            </form>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}

