"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import Link from "next/link"
import { Footer } from "@/components/footer"

// Flight data structure
interface FlightInfo {
  id: string
  airline: string
  flightNumber: string
  departureCity: string
  arrivalCity: string
  departureTime: string
  arrivalTime: string
  duration: string
  price: string
  stops: number
  date: string
}

// Sample flight data
const flightsData: Record<string, FlightInfo> = {
  // DAC - JED (Dhaka to Jeddah) flights
  "biman-dhaka-jeddah-20250310": {
    id: "biman-dhaka-jeddah-20250310",
    airline: "Biman Bangladesh",
    flightNumber: "BG-335",
    departureCity: "Dhaka (DAC)",
    arrivalCity: "Jeddah (JED)",
    departureTime: "10:30",
    arrivalTime: "14:45",
    duration: "6h 15m",
    price: "65,000",
    stops: 0,
    date: "2025-03-10",
  },
  "emirates-dhaka-jeddah-20250310": {
    id: "emirates-dhaka-jeddah-20250310",
    airline: "Emirates",
    flightNumber: "EK-585",
    departureCity: "Dhaka (DAC)",
    arrivalCity: "Jeddah (JED)",
    departureTime: "09:15",
    arrivalTime: "15:30",
    duration: "8h 15m",
    stops: 1,
    price: "85,000",
    date: "2025-03-10",
  },
  // Add more flights as needed
}

// Get airline logo URL
const getAirlineLogo = (airline: string): string => {
  const logos: Record<string, string> = {
    "Biman Bangladesh": "https://mj-ahmad.github.io/mja2025/img/biman-logo.png",
    Emirates: "https://mj-ahmad.github.io/mja2025/img/emirates-logo.png",
    Flynas: "https://mj-ahmad.github.io/mja2025/img/flynas-logo.png",
    "Qatar Airways": "https://mj-ahmad.github.io/mja2025/img/qatar-logo.png",
    Saudia: "https://mj-ahmad.github.io/mja2025/img/saudia-logo.png",
    "US-Bangla Airlines": "https://mj-ahmad.github.io/mja2025/img/usbangla-logo.png",
  }
  return logos[airline] || "/placeholder.svg?height=40&width=120"
}

export default function SuccessPage({ params }: { params: { id: string } }) {
  const flight = flightsData[params.id]
  const [bookingNumber, setBookingNumber] = useState("")
  const [passengerData, setPassengerData] = useState<any>(null)

  useEffect(() => {
    // Generate a random booking number
    const randomBookingNumber =
      "TB" +
      Math.floor(Math.random() * 1000000)
        .toString()
        .padStart(6, "0")
    setBookingNumber(randomBookingNumber)

    // Get passenger data from localStorage
    const storedData = localStorage.getItem(`passenger_${params.id}`)
    if (storedData) {
      setPassengerData(JSON.parse(storedData))
    }
  }, [params.id])

  if (!flight) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center">
        <h1 className="text-2xl font-bold mb-4">Flight Not Found</h1>
        <p className="mb-6">Sorry, the flight you are looking for does not exist.</p>
        <Link
          href="/services/flights"
          className="bg-green-600 text-white px-6 py-2 rounded-md hover:bg-green-700 transition-colors"
        >
          Back to Flights
        </Link>
      </div>
    )
  }

  return (
    <div className="min-h-screen flex flex-col">
      <header className="bg-green-600 text-white py-4">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center gap-2">
              <Image
                src="https://mj-ahmad.github.io/mja2025/img/logo.png"
                alt="TRUSTED-ALLY Logo"
                width={40}
                height={40}
                className="h-10 w-auto"
              />
              <span className="font-bold text-xl">T-Ally Umrah Sr.</span>
            </Link>
            <nav className="hidden md:flex space-x-6">
              <Link href="/" className="hover:text-green-200 transition-colors">
                Home
              </Link>
              <Link href="/packages" className="hover:text-green-200 transition-colors">
                Packages
              </Link>
              <Link href="/services" className="hover:text-green-200 transition-colors">
                Services
              </Link>
              <Link href="/about" className="hover:text-green-200 transition-colors">
                About
              </Link>
              <Link href="/contact" className="hover:text-green-200 transition-colors">
                Contact
              </Link>
            </nav>
          </div>
        </div>
      </header>

      <main className="flex-grow py-12">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="bg-white p-8 rounded-lg shadow-md text-center mb-8">
              <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-10 w-10 text-green-600"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
              </div>
              <h1 className="text-3xl font-bold text-gray-800 mb-4">Booking Confirmed!</h1>
              <p className="text-lg text-gray-600 mb-6">
                Your flight has been successfully booked. Your booking reference number is:
              </p>
              <div className="bg-gray-100 py-3 px-6 rounded-md inline-block mb-6">
                <span className="text-2xl font-bold text-gray-800">{bookingNumber}</span>
              </div>
              <p className="text-gray-600">
                A confirmation email has been sent to {passengerData?.email || "your email address"}. Please check your
                inbox for details.
              </p>
            </div>

            <div className="bg-gray-50 p-6 rounded-lg mb-8">
              <h2 className="font-bold text-xl mb-4">Flight Details</h2>
              <div className="flex flex-col md:flex-row items-start md:items-center justify-between">
                <div className="flex items-center mb-4 md:mb-0">
                  <div className="w-16 h-16 relative mr-4 flex-shrink-0">
                    <Image
                      src={getAirlineLogo(flight.airline) || "/placeholder.svg"}
                      alt={flight.airline}
                      fill
                      className="object-contain"
                    />
                  </div>
                  <div>
                    <p className="font-semibold text-lg">{flight.airline}</p>
                    <p className="text-gray-600">Flight {flight.flightNumber}</p>
                    <p className="text-gray-600">{flight.date}</p>
                  </div>
                </div>
                <div className="flex flex-col items-end">
                  <div className="flex items-center gap-4 mb-2">
                    <div className="text-right">
                      <p className="font-bold">{flight.departureTime}</p>
                      <p className="text-sm text-gray-600">{flight.departureCity}</p>
                    </div>
                    <div className="flex flex-col items-center">
                      <div className="text-xs text-gray-500">{flight.duration}</div>
                      <div className="w-20 h-px bg-gray-300 my-1 relative">
                        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-2 h-2 bg-gray-500 rounded-full"></div>
                      </div>
                      <div className="text-xs text-gray-500">
                        {flight.stops === 0 ? "Direct" : `${flight.stops} Stop`}
                      </div>
                    </div>
                    <div>
                      <p className="font-bold">{flight.arrivalTime}</p>
                      <p className="text-sm text-gray-600">{flight.arrivalCity}</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {passengerData && (
              <div className="bg-white p-6 rounded-lg shadow-md mb-8">
                <h3 className="text-xl font-semibold mb-4">Passenger Information</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-gray-500">Name</p>
                    <p className="font-medium">
                      {passengerData.title} {passengerData.firstName} {passengerData.lastName}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Email</p>
                    <p className="font-medium">{passengerData.email}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Phone</p>
                    <p className="font-medium">{passengerData.phone}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Passport</p>
                    <p className="font-medium">{passengerData.passportNumber}</p>
                  </div>
                </div>
              </div>
            )}

            <div className="bg-white p-6 rounded-lg shadow-md mb-8">
              <h3 className="text-xl font-semibold mb-4">Important Information</h3>
              <div className="space-y-4">
                <div>
                  <h4 className="font-medium text-gray-800">Check-in</h4>
                  <p className="text-gray-600">
                    Please arrive at the airport at least 3 hours before your scheduled departure time for international
                    flights. Online check-in opens 24 hours before departure.
                  </p>
                </div>
                <div>
                  <h4 className="font-medium text-gray-800">Baggage Allowance</h4>
                  <p className="text-gray-600">
                    Economy Class: 1 piece of checked baggage (up to 23kg) and 1 piece of cabin baggage (up to 7kg).
                    Business Class: 2 pieces of checked baggage (up to 32kg each) and 1 piece of cabin baggage (up to
                    10kg).
                  </p>
                </div>
                <div>
                  <h4 className="font-medium text-gray-800">Travel Documents</h4>
                  <p className="text-gray-600">
                    Please ensure you have all necessary travel documents, including a valid passport, visa, and any
                    required health certificates or test results.
                  </p>
                </div>
              </div>
            </div>

            <div className="flex flex-col md:flex-row gap-4 justify-center">
              <Link
                href="/services/flights"
                className="bg-green-600 text-white px-6 py-3 rounded-md font-medium hover:bg-green-700 transition-colors text-center"
              >
                Book Another Flight
              </Link>
              <button
                onClick={() => window.print()}
                className="bg-gray-200 text-gray-800 px-6 py-3 rounded-md font-medium hover:bg-gray-300 transition-colors"
              >
                Print Booking Details
              </button>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}

