"use client"

import Link from "next/link"
import Image from "next/image"

export default function TermsPage() {
  return (
    <div className="bg-white min-h-screen">
      <div className="max-w-4xl mx-auto p-8 bg-white shadow-lg my-8">
        {/* Header */}
        <div className="text-center mb-8 border-b-2 border-green-700 pb-4">
          <div className="flex justify-center mb-4">
            <div className="w-24 h-24 relative">
              <Image src="https://mj-ahmad.github.io/mja2025/img/logo.png" alt="T-ALLY Logo" width={96} height={96} />
            </div>
          </div>
          <h1 className="text-2xl font-bold text-green-800 mb-2">T-ALLY Hajj & Umrah Agency</h1>
          <p className="text-gray-600">Quraner Fariwala, 27 Purana Paltan, Dhaka-1000, BD</p>
          <h2 className="text-3xl font-bold mt-6 text-green-900">Terms and Conditions</h2>
        </div>

        {/* Back button */}
        <div className="flex justify-end mb-6">
          <Link href="/" className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700">
            Return to Home Page
          </Link>
        </div>

        {/* Content */}
        <div className="space-y-6 text-gray-800">
          <div className="mb-6">
            <p className="text-sm text-gray-500 mb-4">Last Updated: {new Date().toLocaleDateString()}</p>
          </div>

          <section className="mb-8">
            <h3 className="text-xl font-semibold mb-4 text-green-800">1. General Terms</h3>
            <p className="mb-4">
              By using the T-ALLY Hajj & Umrah Agency website, you agree to these terms and conditions. If you do not
              agree with these terms, please do not use our website. These terms apply to all users of our website.
            </p>
            <p>
              We reserve the right to change these terms at any time. You can regularly check this page to learn about
              changes. Your continued use after changes indicates your acceptance.
            </p>
          </section>

          <section className="mb-8">
            <h3 className="text-xl font-semibold mb-4 text-green-800">2. Service Usage</h3>
            <p className="mb-4">
              Our website may only be used for legitimate purposes. You may not use our website for any illegal or
              unauthorized purpose. You may not breach the security of our website.
            </p>
            <p className="mb-4">
              All information provided on our website is for general information purposes. We do not guarantee the
              accuracy of this information. Please gather information from other sources before making your decision.
            </p>
          </section>

          <section className="mb-8">
            <h3 className="text-xl font-semibold mb-4 text-green-800">3. Packages and Services</h3>
            <p className="mb-4">
              All our Hajj and Umrah packages are conducted according to the regulations of the Saudi Arabian
              government. We reserve the right to change package details, prices, and availability at any time.
            </p>
            <p className="mb-4">
              Partial or full advance payment is required to confirm package bookings. Cancellations and refunds will be
              processed according to our booking policy.
            </p>
          </section>

          <section className="mb-8">
            <h3 className="text-xl font-semibold mb-4 text-green-800">4. Investment Terms</h3>
            <p className="mb-4">
              There are specific terms and conditions for investors participating in our investment projects. All
              investment risks will be borne by the investors. We do not guarantee any specific results or returns.
            </p>
            <p className="mb-4">
              Consider your financial situation and goals before investing. Consult with a professional financial
              advisor if necessary.
            </p>
            <p className="mb-4">
              Detailed investment terms and agreements will be provided at the time of signing the contract.
            </p>
          </section>

          <section className="mb-8">
            <h3 className="text-xl font-semibold mb-4 text-green-800">5. Payment and Refunds</h3>
            <p className="mb-4">We accept various payment methods. All payments are accepted in Bangladeshi Taka.</p>
            <p className="mb-4">Refund Policy:</p>
            <ul className="list-disc pl-6 space-y-2">
              <li>Hajj Packages: 50% refund if canceled before visa issuance, no refund after visa issuance</li>
              <li>
                Umrah Packages: 75% refund if canceled 30 days in advance, 50% if 15-30 days, no refund if less than 15
                days
              </li>
              <li>Investments: Refund process will be determined according to the investment agreement</li>
            </ul>
          </section>

          <section className="mb-8">
            <h3 className="text-xl font-semibold mb-4 text-green-800">6. Limitation of Liability</h3>
            <p className="mb-4">
              We will not be liable for failure to provide services due to natural disasters, war, terrorist attacks,
              political instability, pandemics, or other circumstances beyond our control.
            </p>
            <p>
              We will not be liable for any direct, indirect, incidental, special, or consequential damages resulting
              from the use of our website or services.
            </p>
          </section>

          <section className="mb-8">
            <h3 className="text-xl font-semibold mb-4 text-green-800">7. Contact</h3>
            <p className="mb-4">
              If you have any questions or concerns about our terms and conditions, please contact us:
            </p>
            <div className="pl-4 border-l-4 border-green-600 mb-4">
              <p className="font-semibold">T-ALLY Hajj & Umrah Agency</p>
              <p>Quraner Fariwala, 27 Purana Paltan, Dhaka-1000, BD</p>
              <p>Contact: MJ AHMAD</p>
              <p>Mobile: +880 1892051303</p>
              <p>Email: t-ally@outlook.com</p>
              <p>
                Website:{" "}
                <Link href="https://v0-trusted-ally-website-ten.vercel.app/" className="text-green-600 hover:underline">
                  https://v0-trusted-ally-website-ten.vercel.app/
                </Link>
              </p>
            </div>
          </section>
        </div>
      </div>
    </div>
  )
}

