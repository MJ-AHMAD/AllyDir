import Image from "next/image"
import Link from "next/link"
import { Footer } from "@/components/footer"

export default function InvestmentProposalPage() {
  return (
    <div className="min-h-screen flex flex-col">
      <header className="bg-green-600 text-white py-4">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center gap-2">
              <Image
                src="https://mj-ahmad.github.io/mja2025/img/logo.png"
                alt="TRUSTED-ALLY Logo"
                width={40}
                height={40}
                className="h-10 w-auto"
              />
              <span className="font-bold text-xl">T-Ally Umrah Sr.</span>
            </Link>
            <nav className="hidden md:flex space-x-6">
              <Link href="/" className="hover:text-green-200 transition-colors">
                Home
              </Link>
              <Link href="/packages" className="hover:text-green-200 transition-colors">
                Packages
              </Link>
              <Link href="/services" className="hover:text-green-200 transition-colors">
                Services
              </Link>
              <Link href="/investment" className="hover:text-green-200 transition-colors">
                Investment
              </Link>
              <Link href="/contact" className="hover:text-green-200 transition-colors">
                Contact
              </Link>
            </nav>
          </div>
        </div>
      </header>

      <main className="flex-grow">
        {/* Hero Section */}
        <section className="relative h-[60vh]">
          <Image
            src="https://mj-ahmad.github.io/mja2025/img/tr000.png"
            alt="Investment Proposal"
            fill
            className="object-cover"
          />
          <div className="absolute inset-0 bg-black/70 flex items-center justify-center">
            <div className="text-center px-4 max-w-4xl">
              <h1 className="text-4xl md:text-6xl font-bold text-white mb-4">Investment Proposal</h1>
              <p className="text-xl text-white/90 mb-8">
                Join T-Ally Umrah Sr. in revolutionizing the Hajj and Umrah service industry with exceptional returns
              </p>
              <div className="flex flex-col sm:flex-row justify-center gap-4">
                <Link
                  href="#executive-summary"
                  className="bg-green-600 text-white px-8 py-3 rounded-md font-medium hover:bg-green-700 transition-colors"
                >
                  Learn More
                </Link>
                <Link
                  href="/investment/apply"
                  className="bg-white text-green-600 px-8 py-3 rounded-md font-medium hover:bg-gray-100 transition-colors"
                >
                  Invest Now
                </Link>
              </div>
            </div>
          </div>
        </section>

        {/* Document Header */}
        <section className="py-10 bg-white border-b">
          <div className="container mx-auto px-4">
            <div className="max-w-5xl mx-auto">
              <div className="flex flex-col md:flex-row justify-between items-center">
                <div>
                  <h2 className="text-3xl font-bold text-gray-800">Investment Proposal</h2>
                  <p className="text-gray-600 mt-2">Confidential Document - 2025/2026</p>
                </div>
                <div className="mt-4 md:mt-0 flex items-center gap-4">
                  <Link
                    href="/investment/proposal/download"
                    className="flex items-center gap-2 text-green-600 hover:text-green-700"
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      className="h-5 w-5"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"
                      />
                    </svg>
                    <span>Download PDF</span>
                  </Link>
                  <Link href="/contact" className="flex items-center gap-2 text-green-600 hover:text-green-700">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      className="h-5 w-5"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"
                      />
                    </svg>
                    <span>Contact Us</span>
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Table of Contents */}
        <section className="py-10 bg-gray-50">
          <div className="container mx-auto px-4">
            <div className="max-w-5xl mx-auto">
              <h2 className="text-2xl font-bold text-gray-800 mb-6">Table of Contents</h2>
              <div className="bg-white p-6 rounded-lg shadow-md">
                <ol className="space-y-4">
                  <li className="flex items-center">
                    <span className="w-8 h-8 rounded-full bg-green-600 text-white flex items-center justify-center mr-3">
                      1
                    </span>
                    <a href="#executive-summary" className="text-green-600 hover:underline">
                      Executive Summary
                    </a>
                  </li>
                  <li className="flex items-center">
                    <span className="w-8 h-8 rounded-full bg-green-600 text-white flex items-center justify-center mr-3">
                      2
                    </span>
                    <a href="#company-overview" className="text-green-600 hover:underline">
                      Company Overview
                    </a>
                  </li>
                  <li className="flex items-center">
                    <span className="w-8 h-8 rounded-full bg-green-600 text-white flex items-center justify-center mr-3">
                      3
                    </span>
                    <a href="#market-analysis" className="text-green-600 hover:underline">
                      Market Analysis
                    </a>
                  </li>
                  <li className="flex items-center">
                    <span className="w-8 h-8 rounded-full bg-green-600 text-white flex items-center justify-center mr-3">
                      4
                    </span>
                    <a href="#investment-opportunity" className="text-green-600 hover:underline">
                      Investment Opportunity
                    </a>
                  </li>
                  <li className="flex items-center">
                    <span className="w-8 h-8 rounded-full bg-green-600 text-white flex items-center justify-center mr-3">
                      5
                    </span>
                    <a href="#financial-projections" className="text-green-600 hover:underline">
                      Financial Projections
                    </a>
                  </li>
                  <li className="flex items-center">
                    <span className="w-8 h-8 rounded-full bg-green-600 text-white flex items-center justify-center mr-3">
                      6
                    </span>
                    <a href="#risk-factors" className="text-green-600 hover:underline">
                      Risk Factors & Mitigation
                    </a>
                  </li>
                  <li className="flex items-center">
                    <span className="w-8 h-8 rounded-full bg-green-600 text-white flex items-center justify-center mr-3">
                      7
                    </span>
                    <a href="#investment-terms" className="text-green-600 hover:underline">
                      Investment Terms
                    </a>
                  </li>
                  <li className="flex items-center">
                    <span className="w-8 h-8 rounded-full bg-green-600 text-white flex items-center justify-center mr-3">
                      8
                    </span>
                    <a href="#next-steps" className="text-green-600 hover:underline">
                      Next Steps
                    </a>
                  </li>
                </ol>
              </div>
            </div>
          </div>
        </section>

        {/* Executive Summary */}
        <section id="executive-summary" className="py-16 bg-white">
          <div className="container mx-auto px-4">
            <div className="max-w-5xl mx-auto">
              <div className="flex items-center mb-8">
                <div className="w-12 h-12 rounded-full bg-green-600 text-white flex items-center justify-center mr-4">
                  <span className="text-xl font-bold">1</span>
                </div>
                <h2 className="text-3xl font-bold text-gray-800">Executive Summary</h2>
              </div>

              <div className="prose prose-lg max-w-none">
                <p>
                  T-Ally Umrah Sr. is seeking investment partners to expand our established Hajj and Umrah services
                  business. With over 10 years of operational experience and a strong market position, we offer a unique
                  opportunity to invest in a growing religious tourism sector with exceptional returns.
                </p>

                <div className="bg-green-50 p-6 rounded-lg my-8">
                  <h3 className="text-xl font-bold text-gray-800 mb-4">Investment Highlights</h3>
                  <ul className="space-y-2">
                    <li className="flex items-start">
                      <svg
                        className="h-6 w-6 text-green-600 mr-2 mt-0.5"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                      </svg>
                      <span>
                        <strong>Attractive Returns:</strong> Annual returns of 12-20% based on investment package
                      </span>
                    </li>
                    <li className="flex items-start">
                      <svg
                        className="h-6 w-6 text-green-600 mr-2 mt-0.5"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                      </svg>
                      <span>
                        <strong>Growing Market:</strong> The Hajj and Umrah service sector is growing at 10-15% annually
                      </span>
                    </li>
                    <li className="flex items-start">
                      <svg
                        className="h-6 w-6 text-green-600 mr-2 mt-0.5"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                      </svg>
                      <span>
                        <strong>Established Business:</strong> 10+ years of successful operations with 50,000+ satisfied
                        customers
                      </span>
                    </li>
                    <li className="flex items-start">
                      <svg
                        className="h-6 w-6 text-green-600 mr-2 mt-0.5"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                      </svg>
                      <span>
                        <strong>Secure Investment:</strong> Government-approved Hajj and Umrah agency with strong
                        financial stability
                      </span>
                    </li>
                    <li className="flex items-start">
                      <svg
                        className="h-6 w-6 text-green-600 mr-2 mt-0.5"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                      </svg>
                      <span>
                        <strong>Flexible Terms:</strong> Multiple investment packages with terms ranging from 1-5 years
                      </span>
                    </li>
                  </ul>
                </div>

                <p>
                  This proposal outlines our business model, market opportunity, financial projections, and investment
                  terms. We invite you to join us in this profitable venture that not only provides excellent financial
                  returns but also contributes to facilitating religious pilgrimages for thousands of Muslims.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Company Overview */}
        <section id="company-overview" className="py-16 bg-gray-50">
          <div className="container mx-auto px-4">
            <div className="max-w-5xl mx-auto">
              <div className="flex items-center mb-8">
                <div className="w-12 h-12 rounded-full bg-green-600 text-white flex items-center justify-center mr-4">
                  <span className="text-xl font-bold">2</span>
                </div>
                <h2 className="text-3xl font-bold text-gray-800">Company Overview</h2>
              </div>

              <div className="prose prose-lg max-w-none">
                <p>
                  T-Ally Umrah Sr. is a premier Hajj and Umrah service provider based in Bangladesh, offering
                  comprehensive pilgrimage packages to Muslims traveling to the holy cities of Makkah and Madinah. Since
                  our establishment in 2013, we have grown to become one of the leading Hajj and Umrah agencies in the
                  country.
                </p>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8 my-8">
                  <div>
                    <h3 className="text-xl font-bold text-gray-800 mb-4">Our Mission</h3>
                    <p>
                      To provide exceptional Hajj and Umrah services that make the sacred journey comfortable,
                      meaningful, and accessible for all Muslims, while maintaining the highest standards of customer
                      service and operational excellence.
                    </p>
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-gray-800 mb-4">Our Vision</h3>
                    <p>
                      To become the most trusted and preferred Hajj and Umrah service provider in South Asia, known for
                      our integrity, quality of service, and innovation in religious tourism.
                    </p>
                  </div>
                </div>

                <h3 className="text-xl font-bold text-gray-800 mb-4">Key Achievements</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                  <div className="bg-white p-6 rounded-lg shadow-md text-center">
                    <div className="text-4xl font-bold text-green-600 mb-2">50,000+</div>
                    <p className="text-gray-700">Pilgrims Served</p>
                  </div>
                  <div className="bg-white p-6 rounded-lg shadow-md text-center">
                    <div className="text-4xl font-bold text-green-600 mb-2">15%</div>
                    <p className="text-gray-700">Market Share</p>
                  </div>
                  <div className="bg-white p-6 rounded-lg shadow-md text-center">
                    <div className="text-4xl font-bold text-green-600 mb-2">20%</div>
                    <p className="text-gray-700">Annual Growth</p>
                  </div>
                </div>

                <h3 className="text-xl font-bold text-gray-800 mb-4">Our Services</h3>
                <ul>
                  <li>Premium Hajj and Umrah packages</li>
                  <li>Accommodation arrangements in Makkah and Madinah</li>
                  <li>Transportation services including Haramain Train bookings</li>
                  <li>Visa processing and documentation assistance</li>
                  <li>Religious guidance and educational support</li>
                  <li>Guided tours of historical and religious sites</li>
                  <li>Special services for families, elderly, and first-time pilgrims</li>
                </ul>

                <h3 className="text-xl font-bold text-gray-800 mb-4 mt-8">Management Team</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div className="flex">
                    <div className="w-20 h-20 rounded-full bg-gray-300 mr-4 flex-shrink-0"></div>
                    <div>
                      <h4 className="font-bold text-lg">Mohammad Abdullah</h4>
                      <p className="text-gray-600 text-sm mb-2">Founder & CEO</p>
                      <p className="text-sm">
                        20+ years of experience in the travel and tourism industry with specialized expertise in Hajj
                        and Umrah services.
                      </p>
                    </div>
                  </div>
                  <div className="flex">
                    <div className="w-20 h-20 rounded-full bg-gray-300 mr-4 flex-shrink-0"></div>
                    <div>
                      <h4 className="font-bold text-lg">Fatima Rahman</h4>
                      <p className="text-gray-600 text-sm mb-2">Chief Financial Officer</p>
                      <p className="text-sm">
                        15+ years of financial management experience with a background in investment banking and
                        corporate finance.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Market Analysis */}
        <section id="market-analysis" className="py-16 bg-white">
          <div className="container mx-auto px-4">
            <div className="max-w-5xl mx-auto">
              <div className="flex items-center mb-8">
                <div className="w-12 h-12 rounded-full bg-green-600 text-white flex items-center justify-center mr-4">
                  <span className="text-xl font-bold">3</span>
                </div>
                <h2 className="text-3xl font-bold text-gray-800">Market Analysis</h2>
              </div>

              <div className="prose prose-lg max-w-none">
                <p>
                  The Hajj and Umrah service industry represents a significant and growing market opportunity, driven by
                  increasing Muslim population, rising disposable incomes, and enhanced accessibility to the holy
                  cities.
                </p>

                <h3 className="text-xl font-bold text-gray-800 mb-4 mt-8">Market Size & Growth</h3>
                <div className="bg-green-50 p-6 rounded-lg mb-8">
                  <ul className="space-y-4">
                    <li className="flex items-start">
                      <svg
                        className="h-6 w-6 text-green-600 mr-2 mt-0.5"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth="2"
                          d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"
                        />
                      </svg>
                      <div>
                        <strong>Global Market:</strong> The global Hajj and Umrah services market is valued at
                        approximately $7.5 billion annually and is projected to reach $9.8 billion by 2028.
                      </div>
                    </li>
                    <li className="flex items-start">
                      <svg
                        className="h-6 w-6 text-green-600 mr-2 mt-0.5"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth="2"
                          d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"
                        />
                      </svg>
                      <div>
                        <strong>Bangladesh Market:</strong> Bangladesh sends approximately 125,000 pilgrims for Hajj and
                        300,000+ for Umrah annually, with a market size of approximately $500 million.
                      </div>
                    </li>
                    <li className="flex items-start">
                      <svg
                        className="h-6 w-6 text-green-600 mr-2 mt-0.5"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth="2"
                          d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"
                        />
                      </svg>
                      <div>
                        <strong>Growth Rate:</strong> The Hajj and Umrah service sector in Bangladesh is growing at
                        10-15% annually, outpacing the global average of 6-8%.
                      </div>
                    </li>
                  </ul>
                </div>

                <h3 className="text-xl font-bold text-gray-800 mb-4">Market Trends</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                  <div className="bg-white p-6 rounded-lg shadow-md">
                    <h4 className="font-bold text-lg mb-2">Increasing Demand for Premium Services</h4>
                    <p>
                      Growing middle and upper-middle class in Bangladesh is driving demand for premium Hajj and Umrah
                      packages with better accommodations, transportation, and personalized services.
                    </p>
                  </div>
                  <div className="bg-white p-6 rounded-lg shadow-md">
                    <h4 className="font-bold text-lg mb-2">Digital Transformation</h4>
                    <p>
                      Online booking platforms, mobile apps, and digital payment systems are transforming how pilgrims
                      research, book, and pay for Hajj and Umrah services.
                    </p>
                  </div>
                  <div className="bg-white p-6 rounded-lg shadow-md">
                    <h4 className="font-bold text-lg mb-2">Year-Round Umrah</h4>
                    <p>
                      Recent policy changes by Saudi authorities have made Umrah accessible throughout the year,
                      increasing the overall market size and reducing seasonality.
                    </p>
                  </div>
                  <div className="bg-white p-6 rounded-lg shadow-md">
                    <h4 className="font-bold text-lg mb-2">Focus on Experience</h4>
                    <p>
                      Pilgrims are increasingly seeking educational, spiritual, and cultural experiences beyond the
                      basic religious rituals, creating opportunities for value-added services.
                    </p>
                  </div>
                </div>

                <h3 className="text-xl font-bold text-gray-800 mb-4">Competitive Landscape</h3>
                <p>
                  The Hajj and Umrah service market in Bangladesh is fragmented with over 200 licensed operators.
                  However, the premium segment is dominated by a handful of established players, including T-Ally Umrah
                  Sr., which holds a 15% market share in this segment.
                </p>

                <div className="mt-6">
                  <h4 className="font-bold text-lg mb-2">Our Competitive Advantages</h4>
                  <ul>
                    <li>Direct contracts with premium hotels in Makkah and Madinah</li>
                    <li>Proprietary transportation network in Saudi Arabia</li>
                    <li>Experienced religious scholars as guides</li>
                    <li>Strong relationships with Saudi authorities</li>
                    <li>Innovative technology platform for booking and customer service</li>
                    <li>Comprehensive service offerings covering all aspects of pilgrimage</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Investment Opportunity */}
        <section id="investment-opportunity" className="py-16 bg-gray-50">
          <div className="container mx-auto px-4">
            <div className="max-w-5xl mx-auto">
              <div className="flex items-center mb-8">
                <div className="w-12 h-12 rounded-full bg-green-600 text-white flex items-center justify-center mr-4">
                  <span className="text-xl font-bold">4</span>
                </div>
                <h2 className="text-3xl font-bold text-gray-800">Investment Opportunity</h2>
              </div>

              <div className="prose prose-lg max-w-none">
                <p>
                  T-Ally Umrah Sr. is seeking investment capital to fund our expansion plans and capitalize on the
                  growing demand for premium Hajj and Umrah services. We offer a range of investment packages designed
                  to provide attractive returns while supporting our growth strategy.
                </p>

                <h3 className="text-xl font-bold text-gray-800 mb-4 mt-8">Capital Requirement</h3>
                <p>
                  We are raising a total of BDT 50 crore (approximately USD 4.5 million) through various investment
                  packages. This capital will be deployed according to our strategic expansion plan.
                </p>

                <h3 className="text-xl font-bold text-gray-800 mb-4 mt-8">Use of Funds</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8 my-8">
                  <div>
                    <div className="relative pt-1">
                      <div className="flex mb-2 items-center justify-between">
                        <div>
                          <span className="text-xs font-semibold inline-block py-1 px-2 uppercase rounded-full text-green-600 bg-green-200">
                            Property Acquisition
                          </span>
                        </div>
                        <div className="text-right">
                          <span className="text-xs font-semibold inline-block text-green-600">40%</span>
                        </div>
                      </div>
                      <div className="overflow-hidden h-2 mb-4 text-xs flex rounded bg-green-200">
                        <div
                          style={{ width: "40%" }}
                          className="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-green-600"
                        ></div>
                      </div>
                      <p className="text-sm text-gray-600">
                        Acquisition of hotel properties in Makkah and Madinah to reduce accommodation costs and increase
                        profit margins.
                      </p>
                    </div>
                    <div className="relative pt-1 mt-6">
                      <div className="flex mb-2 items-center justify-between">
                        <div>
                          <span className="text-xs font-semibold inline-block py-1 px-2 uppercase rounded-full text-green-600 bg-green-200">
                            Transportation Fleet
                          </span>
                        </div>
                        <div className="text-right">
                          <span className="text-xs font-semibold inline-block text-green-600">25%</span>
                        </div>
                      </div>
                      <div className="overflow-hidden h-2 mb-4 text-xs flex rounded bg-green-200">
                        <div
                          style={{ width: "25%" }}
                          className="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-green-600"
                        ></div>
                      </div>
                      <p className="text-sm text-gray-600">
                        Expansion of our transportation fleet in Saudi Arabia to provide seamless travel experiences for
                        our pilgrims.
                      </p>
                    </div>
                  </div>
                  <div>
                    <div className="relative pt-1">
                      <div className="flex mb-2 items-center justify-between">
                        <div>
                          <span className="text-xs font-semibold inline-block py-1 px-2 uppercase rounded-full text-green-600 bg-green-200">
                            Technology Platform
                          </span>
                        </div>
                        <div className="text-right">
                          <span className="text-xs font-semibold inline-block text-green-600">20%</span>
                        </div>
                      </div>
                      <div className="overflow-hidden h-2 mb-4 text-xs flex rounded bg-green-200">
                        <div
                          style={{ width: "20%" }}
                          className="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-green-600"
                        ></div>
                      </div>
                      <p className="text-sm text-gray-600">
                        Development of advanced booking and customer management systems to enhance service delivery and
                        operational efficiency.
                      </p>
                    </div>
                    <div className="relative pt-1 mt-6">
                      <div className="flex mb-2 items-center justify-between">
                        <div>
                          <span className="text-xs font-semibold inline-block py-1 px-2 uppercase rounded-full text-green-600 bg-green-200">
                            Working Capital
                          </span>
                        </div>
                        <div className="text-right">
                          <span className="text-xs font-semibold inline-block text-green-600">15%</span>
                        </div>
                      </div>
                      <div className="overflow-hidden h-2 mb-4 text-xs flex rounded bg-green-200">
                        <div
                          style={{ width: "15%" }}
                          className="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-green-600"
                        ></div>
                      </div>
                      <p className="text-sm text-gray-600">
                        Working capital to support operations, marketing initiatives, and business development
                        activities.
                      </p>
                    </div>
                  </div>
                </div>

                <h3 className="text-xl font-bold text-gray-800 mb-4">Investment Packages</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8 my-8">
                  <div className="bg-white rounded-lg shadow-lg overflow-hidden">
                    <div className="bg-green-600 text-white p-4 text-center">
                      <h3 className="text-xl font-bold">Starter Package</h3>
                    </div>
                    <div className="p-6">
                      <div className="text-center mb-6">
                        <span className="text-4xl font-bold">৳5,00,000</span>
                        <span className="text-gray-600 block mt-1">Minimum Investment</span>
                      </div>
                      <ul className="space-y-3 mb-6">
                        <li className="flex items-center">
                          <svg
                            className="h-5 w-5 text-green-500 mr-2"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor"
                          >
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                          </svg>
                          <span>12% Annual Dividend</span>
                        </li>
                        <li className="flex items-center">
                          <svg
                            className="h-5 w-5 text-green-500 mr-2"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor"
                          >
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                          </svg>
                          <span>Quarterly Dividend Payments</span>
                        </li>
                        <li className="flex items-center">
                          <svg
                            className="h-5 w-5 text-green-500 mr-2"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor"
                          >
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                          </svg>
                          <span>1 Year Term</span>
                        </li>
                        <li className="flex items-center">
                          <svg
                            className="h-5 w-5 text-green-500 mr-2"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor"
                          >
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                          </svg>
                          <span>5% Discount on Umrah Packages</span>
                        </li>
                      </ul>
                      <Link
                        href="/investment/starter"
                        className="block w-full bg-green-600 text-white text-center py-2 rounded hover:bg-green-700 transition-colors"
                      >
                        Learn More
                      </Link>
                    </div>
                  </div>

                  <div className="bg-white rounded-lg shadow-lg overflow-hidden transform scale-105 z-10 border-2 border-green-500">
                    <div className="bg-green-700 text-white p-4 text-center relative">
                      <div className="absolute top-0 right-0 bg-yellow-500 text-xs font-bold px-2 py-1 transform translate-x-2 -translate-y-1 rotate-12">
                        Best Value
                      </div>
                      <h3 className="text-xl font-bold">Premium Package</h3>
                    </div>
                    <div className="p-6">
                      <div className="text-center mb-6">
                        <span className="text-4xl font-bold">৳25,00,000</span>
                        <span className="text-gray-600 block mt-1">Minimum Investment</span>
                      </div>
                      <ul className="space-y-3 mb-6">
                        <li className="flex items-center">
                          <svg
                            className="h-5 w-5 text-green-500 mr-2"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor"
                          >
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                          </svg>
                          <span>18% Annual Dividend</span>
                        </li>
                        <li className="flex items-center">
                          <svg
                            className="h-5 w-5 text-green-500 mr-2"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor"
                          >
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                          </svg>
                          <span>Monthly Dividend Payments</span>
                        </li>
                        <li className="flex items-center">
                          <svg
                            className="h-5 w-5 text-green-500 mr-2"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor"
                          >
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                          </svg>
                          <span>3 Year Term</span>
                        </li>
                        <li className="flex items-center">
                          <svg
                            className="h-5 w-5 text-green-500 mr-2"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor"
                          >
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                          </svg>
                          <span>10% Discount on Hajj & Umrah Packages</span>
                        </li>
                        <li className="flex items-center">
                          <svg
                            className="h-5 w-5 text-green-500 mr-2"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor"
                          >
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                          </svg>
                          <span>Annual Investor Conference Participation</span>
                        </li>
                      </ul>
                      <Link
                        href="/investment/premium"
                        className="block w-full bg-green-700 text-white text-center py-2 rounded hover:bg-green-800 transition-colors"
                      >
                        Learn More
                      </Link>
                    </div>
                  </div>

                  <div className="bg-white rounded-lg shadow-lg overflow-hidden">
                    <div className="bg-green-600 text-white p-4 text-center">
                      <h3 className="text-xl font-bold">Enterprise Package</h3>
                    </div>
                    <div className="p-6">
                      <div className="text-center mb-6">
                        <span className="text-4xl font-bold">৳1,00,00,000</span>
                        <span className="text-gray-600 block mt-1">Minimum Investment</span>
                      </div>
                      <ul className="space-y-3 mb-6">
                        <li className="flex items-center">
                          <svg
                            className="h-5 w-5 text-green-500 mr-2"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor"
                          >
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                          </svg>
                          <span>20% Annual Dividend</span>
                        </li>
                        <li className="flex items-center">
                          <svg
                            className="h-5 w-5 text-green-500 mr-2"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor"
                          >
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                          </svg>
                          <span>Monthly Dividend Payments</span>
                        </li>
                        <li className="flex items-center">
                          <svg
                            className="h-5 w-5 text-green-500 mr-2"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor"
                          >
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                          </svg>
                          <span>5 Year Term</span>
                        </li>
                        <li className="flex items-center">
                          <svg
                            className="h-5 w-5 text-green-500 mr-2"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor"
                          >
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                          </svg>
                          <span>15% Discount on Hajj & Umrah Packages</span>
                        </li>
                        <li className="flex items-center">
                          <svg
                            className="h-5 w-5 text-green-500 mr-2"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor"
                          >
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                          </svg>
                          <span>Board Meeting Participation Opportunity</span>
                        </li>
                      </ul>
                      <Link
                        href="/investment/enterprise"
                        className="block w-full bg-green-600 text-white text-center py-2 rounded hover:bg-green-700 transition-colors"
                      >
                        Learn More
                      </Link>
                    </div>
                  </div>
                </div>

                <h3 className="text-xl font-bold text-gray-800 mb-4">Return on Investment</h3>
                <p>
                  Our investment packages offer attractive returns compared to traditional investment options in
                  Bangladesh. The table below provides a comparison of expected returns:
                </p>

                <div className="overflow-x-auto my-6">
                  <table className="min-w-full bg-white border border-gray-200">
                    <thead>
                      <tr>
                        <th className="py-3 px-4 bg-gray-50 text-left border-b">Investment Option</th>
                        <th className="py-3 px-4 bg-gray-50 text-left border-b">Annual Return</th>
                        <th className="py-3 px-4 bg-gray-50 text-left border-b">Risk Level</th>
                        <th className="py-3 px-4 bg-gray-50 text-left border-b">Liquidity</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td className="py-3 px-4 border-b">T-Ally Starter Package</td>
                        <td className="py-3 px-4 border-b text-green-600 font-bold">12%</td>
                        <td className="py-3 px-4 border-b">Low-Medium</td>
                        <td className="py-3 px-4 border-b">Medium</td>
                      </tr>
                      <tr>
                        <td className="py-3 px-4 border-b">T-Ally Premium Package</td>
                        <td className="py-3 px-4 border-b text-green-600 font-bold">18%</td>
                        <td className="py-3 px-4 border-b">Medium</td>
                        <td className="py-3 px-4 border-b">Medium</td>
                      </tr>
                      <tr>
                        <td className="py-3 px-4 border-b">T-Ally Enterprise Package</td>
                        <td className="py-3 px-4 border-b text-green-600 font-bold">20%</td>
                        <td className="py-3 px-4 border-b">Medium</td>
                        <td className="py-3 px-4 border-b">Low</td>
                      </tr>
                      <tr>
                        <td className="py-3 px-4 border-b">Bank Fixed Deposit</td>
                        <td className="py-3 px-4 border-b">5-7%</td>
                        <td className="py-3 px-4 border-b">Low</td>
                        <td className="py-3 px-4 border-b">Medium</td>
                      </tr>
                      <tr>
                        <td className="py-3 px-4 border-b">Government Savings Certificates</td>
                        <td className="py-3 px-4 border-b">8-9%</td>
                        <td className="py-3 px-4 border-b">Low</td>
                        <td className="py-3 px-4 border-b">Medium</td>
                      </tr>
                      <tr>
                        <td className="py-3 px-4 border-b">Stock Market (Average)</td>
                        <td className="py-3 px-4 border-b">10-12%</td>
                        <td className="py-3 px-4 border-b">High</td>
                        <td className="py-3 px-4 border-b">High</td>
                      </tr>
                      <tr>
                        <td className="py-3 px-4 border-b">Real Estate</td>
                        <td className="py-3 px-4 border-b">8-10%</td>
                        <td className="py-3 px-4 border-b">Medium</td>
                        <td className="py-3 px-4 border-b">Low</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Financial Projections */}
        <section id="financial-projections" className="py-16 bg-white">
          <div className="container mx-auto px-4">
            <div className="max-w-5xl mx-auto">
              <div className="flex items-center mb-8">
                <div className="w-12 h-12 rounded-full bg-green-600 text-white flex items-center justify-center mr-4">
                  <span className="text-xl font-bold">5</span>
                </div>
                <h2 className="text-3xl font-bold text-gray-800">Financial Projections</h2>
              </div>

              <div className="prose prose-lg max-w-none">
                <p>
                  Based on our historical performance and market analysis, we project strong financial growth over the
                  next five years. The following projections demonstrate our ability to generate consistent returns for
                  our investors.
                </p>

                <h3 className="text-xl font-bold text-gray-800 mb-4 mt-8">Revenue Projections (in BDT Crore)</h3>
                <div className="bg-gray-50 p-6 rounded-lg mb-8">
                  <div className="h-64 relative">
                    {/* This would be a chart in a real implementation */}
                    <div className="absolute inset-0 flex items-center justify-center">
                      <p className="text-gray-500 italic">Revenue projection chart would appear here</p>
                    </div>
                  </div>
                  <div className="grid grid-cols-6 gap-2 mt-4">
                    <div className="text-center">
                      <div className="font-bold">Base Year</div>
                      <div>50</div>
                    </div>
                    <div className="text-center">
                      <div className="font-bold">Year 1</div>
                      <div>65</div>
                    </div>
                    <div className="text-center">
                      <div className="font-bold">Year 2</div>
                      <div>85</div>
                    </div>
                    <div className="text-center">
                      <div className="font-bold">Year 3</div>
                      <div>110</div>
                    </div>
                    <div className="text-center">
                      <div className="font-bold">Year 4</div>
                      <div>140</div>
                    </div>
                    <div className="text-center">
                      <div className="font-bold">Year 5</div>
                      <div>180</div>
                    </div>
                  </div>
                </div>

                <h3 className="text-xl font-bold text-gray-800 mb-4">Key Financial Metrics</h3>
                <div className="overflow-x-auto my-6">
                  <table className="min-w-full bg-white border border-gray-200">
                    <thead>
                      <tr>
                        <th className="py-3 px-4 bg-gray-50 text-left border-b">Metric</th>
                        <th className="py-3 px-4 bg-gray-50 text-left border-b">Year 1</th>
                        <th className="py-3 px-4 bg-gray-50 text-left border-b">Year 2</th>
                        <th className="py-3 px-4 bg-gray-50 text-left border-b">Year 3</th>
                        <th className="py-3 px-4 bg-gray-50 text-left border-b">Year 4</th>
                        <th className="py-3 px-4 bg-gray-50 text-left border-b">Year 5</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td className="py-3 px-4 border-b font-medium">Revenue (BDT Crore)</td>
                        <td className="py-3 px-4 border-b">65</td>
                        <td className="py-3 px-4 border-b">85</td>
                        <td className="py-3 px-4 border-b">110</td>
                        <td className="py-3 px-4 border-b">140</td>
                        <td className="py-3 px-4 border-b">180</td>
                      </tr>
                      <tr>
                        <td className="py-3 px-4 border-b font-medium">EBITDA (BDT Crore)</td>
                        <td className="py-3 px-4 border-b">13</td>
                        <td className="py-3 px-4 border-b">18</td>
                        <td className="py-3 px-4 border-b">24</td>
                        <td className="py-3 px-4 border-b">32</td>
                        <td className="py-3 px-4 border-b">42</td>
                      </tr>
                      <tr>
                        <td className="py-3 px-4 border-b font-medium">Net Profit (BDT Crore)</td>
                        <td className="py-3 px-4 border-b">9</td>
                        <td className="py-3 px-4 border-b">13</td>
                        <td className="py-3 px-4 border-b">18</td>
                        <td className="py-3 px-4 border-b">25</td>
                        <td className="py-3 px-4 border-b">33</td>
                      </tr>
                      <tr>
                        <td className="py-3 px-4 border-b font-medium">Profit Margin</td>
                        <td className="py-3 px-4 border-b">14%</td>
                        <td className="py-3 px-4 border-b">15%</td>
                        <td className="py-3 px-4 border-b">16%</td>
                        <td className="py-3 px-4 border-b">18%</td>
                        <td className="py-3 px-4 border-b">18%</td>
                      </tr>
                      <tr>
                        <td className="py-3 px-4 border-b font-medium">ROI</td>
                        <td className="py-3 px-4 border-b">18%</td>
                        <td className="py-3 px-4 border-b">20%</td>
                        <td className="py-3 px-4 border-b">22%</td>
                        <td className="py-3 px-4 border-b">24%</td>
                        <td className="py-3 px-4 border-b">25%</td>
                      </tr>
                      <tr>
                        <td className="py-3 px-4 border-b font-medium">Pilgrims Served</td>
                        <td className="py-3 px-4 border-b">12,000</td>
                        <td className="py-3 px-4 border-b">15,000</td>
                        <td className="py-3 px-4 border-b">19,000</td>
                        <td className="py-3 px-4 border-b">24,000</td>
                        <td className="py-3 px-4 border-b">30,000</td>
                      </tr>
                    </tbody>
                  </table>
                </div>

                <h3 className="text-xl font-bold text-gray-800 mb-4">Revenue Streams</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                  <div>
                    <div className="relative pt-1">
                      <div className="flex mb-2 items-center justify-between">
                        <div>
                          <span className="text-xs font-semibold inline-block py-1 px-2 uppercase rounded-full text-green-600 bg-green-200">
                            Hajj & Umrah Packages
                          </span>
                        </div>
                        <div className="text-right">
                          <span className="text-xs font-semibold inline-block text-green-600">60%</span>
                        </div>
                      </div>
                      <div className="overflow-hidden h-2 mb-4 text-xs flex rounded bg-green-200">
                        <div
                          style={{ width: "60%" }}
                          className="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-green-600"
                        ></div>
                      </div>
                    </div>
                    <div className="relative pt-1 mt-4">
                      <div className="flex mb-2 items-center justify-between">
                        <div>
                          <span className="text-xs font-semibold inline-block py-1 px-2 uppercase rounded-full text-green-600 bg-green-200">
                            Accommodation Services
                          </span>
                        </div>
                        <div className="text-right">
                          <span className="text-xs font-semibold inline-block text-green-600">15%</span>
                        </div>
                      </div>
                      <div className="overflow-hidden h-2 mb-4 text-xs flex rounded bg-green-200">
                        <div
                          style={{ width: "15%" }}
                          className="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-green-600"
                        ></div>
                      </div>
                    </div>
                  </div>
                  <div>
                    <div className="relative pt-1">
                      <div className="flex mb-2 items-center justify-between">
                        <div>
                          <span className="text-xs font-semibold inline-block py-1 px-2 uppercase rounded-full text-green-600 bg-green-200">
                            Transportation Services
                          </span>
                        </div>
                        <div className="text-right">
                          <span className="text-xs font-semibold inline-block text-green-600">10%</span>
                        </div>
                      </div>
                      <div className="overflow-hidden h-2 mb-4 text-xs flex rounded bg-green-200">
                        <div
                          style={{ width: "10%" }}
                          className="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-green-600"
                        ></div>
                      </div>
                    </div>
                    <div className="relative pt-1 mt-4">
                      <div className="flex mb-2 items-center justify-between">
                        <div>
                          <span className="text-xs font-semibold inline-block py-1 px-2 uppercase rounded-full text-green-600 bg-green-200">
                            Visa & Other Services
                          </span>
                        </div>
                        <div className="text-right">
                          <span className="text-xs font-semibold inline-block text-green-600">15%</span>
                        </div>
                      </div>
                      <div className="overflow-hidden h-2 mb-4 text-xs flex rounded bg-green-200">
                        <div
                          style={{ width: "15%" }}
                          className="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-green-600"
                        ></div>
                      </div>
                    </div>
                  </div>
                </div>

                <p>
                  These projections are based on conservative estimates and our proven business model. Our diversified
                  revenue streams provide stability and resilience against market fluctuations, ensuring consistent
                  returns for our investors.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Risk Factors */}
        <section id="risk-factors" className="py-16 bg-gray-50">
          <div className="container mx-auto px-4">
            <div className="max-w-5xl mx-auto">
              <div className="flex items-center mb-8">
                <div className="w-12 h-12 rounded-full bg-green-600 text-white flex items-center justify-center mr-4">
                  <span className="text-xl font-bold">6</span>
                </div>
                <h2 className="text-3xl font-bold text-gray-800">Risk Factors & Mitigation</h2>
              </div>

              <div className="prose prose-lg max-w-none">
                <p>
                  While we are confident in our business model and growth projections, we acknowledge that all
                  investments carry some level of risk. We believe in transparent communication with our investors about
                  potential risks and our strategies to mitigate them.
                </p>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8 my-8">
                  <div className="bg-white p-6 rounded-lg shadow-md">
                    <h3 className="text-xl font-bold text-gray-800 mb-4">Market Risks</h3>
                    <div className="space-y-4">
                      <div>
                        <h4 className="font-bold text-gray-700">Policy Changes by Saudi Authorities</h4>
                        <p className="text-gray-600 text-sm mt-1">
                          Changes in visa policies, Hajj quotas, or fees by Saudi authorities could impact our
                          operations.
                        </p>
                        <div className="mt-2">
                          <span className="text-xs font-semibold text-green-600">Mitigation:</span>
                          <p className="text-gray-600 text-sm mt-1">
                            We maintain strong relationships with Saudi authorities and diversify our service offerings
                            to adapt to policy changes. Our experienced team stays updated on regulatory developments.
                          </p>
                        </div>
                      </div>
                      <div>
                        <h4 className="font-bold text-gray-700">Economic Downturns</h4>
                        <p className="text-gray-600 text-sm mt-1">
                          Economic recessions could reduce disposable income and affect demand for premium pilgrimage
                          packages.
                        </p>
                        <div className="mt-2">
                          <span className="text-xs font-semibold text-green-600">Mitigation:</span>
                          <p className="text-gray-600 text-sm mt-1">
                            We offer packages at various price points and maintain financial reserves to weather
                            economic downturns. Religious travel tends to be more resilient than leisure travel during
                            economic challenges.
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="bg-white p-6 rounded-lg shadow-md">
                    <h3 className="text-xl font-bold text-gray-800 mb-4">Operational Risks</h3>
                    <div className="space-y-4">
                      <div>
                        <h4 className="font-bold text-gray-700">Service Quality Issues</h4>
                        <p className="text-gray-600 text-sm mt-1">
                          Maintaining consistent service quality across all packages and pilgrim groups is challenging.
                        </p>
                        <div className="mt-2">
                          <span className="text-xs font-semibold text-green-600">Mitigation:</span>
                          <p className="text-gray-600 text-sm mt-1">
                            We implement rigorous quality control processes, regular staff training, and customer
                            feedback systems. Our experienced operations team ensures high service standards.
                          </p>
                        </div>
                      </div>
                      <div>
                        <h4 className="font-bold text-gray-700">Logistical Challenges</h4>
                        <p className="text-gray-600 text-sm mt-1">
                          Managing transportation, accommodation, and other logistics for large groups of pilgrims
                          presents challenges.
                        </p>
                        <div className="mt-2">
                          <span className="text-xs font-semibold text-green-600">Mitigation:</span>
                          <p className="text-gray-600 text-sm mt-1">
                            We use advanced logistics management systems and maintain strong relationships with reliable
                            service providers in Saudi Arabia. Our team has extensive experience in handling complex
                            logistics.
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="bg-white p-6 rounded-lg shadow-md">
                    <h3 className="text-xl font-bold text-gray-800 mb-4">Financial Risks</h3>
                    <div className="space-y-4">
                      <div>
                        <h4 className="font-bold text-gray-700">Currency Fluctuations</h4>
                        <p className="text-gray-600 text-sm mt-1">
                          Fluctuations in exchange rates between BDT, USD, and SAR could affect our profit margins.
                        </p>
                        <div className="mt-2">
                          <span className="text-xs font-semibold text-green-600">Mitigation:</span>
                          <p className="text-gray-600 text-sm mt-1">
                            We implement hedging strategies and maintain reserves in multiple currencies to minimize the
                            impact of exchange rate fluctuations.
                          </p>
                        </div>
                      </div>
                      <div>
                        <h4 className="font-bold text-gray-700">Cash Flow Management</h4>
                        <p className="text-gray-600 text-sm mt-1">
                          Managing cash flow with seasonal business cycles and advance payments to suppliers can be
                          challenging.
                        </p>
                        <div className="mt-2">
                          <span className="text-xs font-semibold text-green-600">Mitigation:</span>
                          <p className="text-gray-600 text-sm mt-1">
                            We maintain adequate working capital, implement robust financial planning, and diversify our
                            revenue streams to ensure stable cash flow throughout the year.
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="bg-white p-6 rounded-lg shadow-md">
                    <h3 className="text-xl font-bold text-gray-800 mb-4">External Risks</h3>
                    <div className="space-y-4">
                      <div>
                        <h4 className="font-bold text-gray-700">Global Health Crises</h4>
                        <p className="text-gray-600 text-sm mt-1">
                          Pandemics or health emergencies can disrupt travel and pilgrimage activities, as seen during
                          COVID-19.
                        </p>
                        <div className="mt-2">
                          <span className="text-xs font-semibold text-green-600">Mitigation:</span>
                          <p className="text-gray-600 text-sm mt-1">
                            We have developed contingency plans, flexible booking policies, and digital service
                            offerings to adapt to health-related disruptions. We maintain financial reserves to
                            withstand temporary downturns.
                          </p>
                        </div>
                      </div>
                      <div>
                        <h4 className="font-bold text-gray-700">Political Instability</h4>
                        <p className="text-gray-600 text-sm mt-1">
                          Political tensions or instability in the region could affect travel and operations.
                        </p>
                        <div className="mt-2">
                          <span className="text-xs font-semibold text-green-600">Mitigation:</span>
                          <p className="text-gray-600 text-sm mt-1">
                            We monitor geopolitical developments closely, maintain comprehensive insurance coverage, and
                            have established crisis management protocols to ensure pilgrim safety and business
                            continuity.
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-green-50 p-6 rounded-lg">
                  <h3 className="text-xl font-bold text-gray-800 mb-4">Our Risk Management Approach</h3>
                  <p className="mb-4">
                    T-Ally Umrah Sr. employs a comprehensive risk management framework that includes:
                  </p>
                  <ul className="space-y-2">
                    <li className="flex items-start">
                      <svg
                        className="h-5 w-5 text-green-600 mr-2 mt-0.5"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                      </svg>
                      <span>Regular risk assessment and monitoring by our management team</span>
                    </li>
                    <li className="flex items-start">
                      <svg
                        className="h-5 w-5 text-green-600 mr-2 mt-0.5"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                      </svg>
                      <span>Diversification of revenue streams and service offerings</span>
                    </li>
                    <li className="flex items-start">
                      <svg
                        className="h-5 w-5 text-green-600 mr-2 mt-0.5"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                      </svg>
                      <span>Maintenance of adequate financial reserves</span>
                    </li>
                    <li className="flex items-start">
                      <svg
                        className="h-5 w-5 text-green-600 mr-2 mt-0.5"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                      </svg>
                      <span>Comprehensive insurance coverage</span>
                    </li>
                    <li className="flex items-start">
                      <svg
                        className="h-5 w-5 text-green-600 mr-2 mt-0.5"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                      </svg>
                      <span>Regular investor updates and transparent communication</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Investment Terms */}
        <section id="investment-terms" className="py-16 bg-white">
          <div className="container mx-auto px-4">
            <div className="max-w-5xl mx-auto">
              <div className="flex items-center mb-8">
                <div className="w-12 h-12 rounded-full bg-green-600 text-white flex items-center justify-center mr-4">
                  <span className="text-xl font-bold">7</span>
                </div>
                <h2 className="text-3xl font-bold text-gray-800">Investment Terms</h2>
              </div>

              <div className="prose prose-lg max-w-none">
                <p>
                  Our investment terms are designed to provide clarity, transparency, and security for our investors.
                  Below are the key terms and conditions for investing in T-Ally Umrah Sr.
                </p>

                <h3 className="text-xl font-bold text-gray-800 mb-4 mt-8">Investment Duration</h3>
                <div className="overflow-x-auto my-6">
                  <table className="min-w-full bg-white border border-gray-200">
                    <thead>
                      <tr>
                        <th className="py-3 px-4 bg-gray-50 text-left border-b">Package</th>
                        <th className="py-3 px-4 bg-gray-50 text-left border-b">Minimum Term</th>
                        <th className="py-3 px-4 bg-gray-50 text-left border-b">Early Withdrawal</th>
                        <th className="py-3 px-4 bg-gray-50 text-left border-b">Renewal Option</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td className="py-3 px-4 border-b">Starter Package</td>
                        <td className="py-3 px-4 border-b">1 Year</td>
                        <td className="py-3 px-4 border-b">Available with 5% fee</td>
                        <td className="py-3 px-4 border-b">Yes, at prevailing rates</td>
                      </tr>
                      <tr>
                        <td className="py-3 px-4 border-b">Premium Package</td>
                        <td className="py-3 px-4 border-b">3 Years</td>
                        <td className="py-3 px-4 border-b">Available with 3% fee</td>
                        <td className="py-3 px-4 border-b">Yes, at prevailing rates</td>
                      </tr>
                      <tr>
                        <td className="py-3 px-4 border-b">Enterprise Package</td>
                        <td className="py-3 px-4 border-b">5 Years</td>
                        <td className="py-3 px-4 border-b">Available with 2% fee</td>
                        <td className="py-3 px-4 border-b">Yes, at prevailing rates</td>
                      </tr>
                    </tbody>
                  </table>
                </div>

                <h3 className="text-xl font-bold text-gray-800 mb-4">Dividend Distribution</h3>
                <div className="bg-gray-50 p-6 rounded-lg mb-8">
                  <ul className="space-y-4">
                    <li className="flex items-start">
                      <svg
                        className="h-6 w-6 text-green-600 mr-2 mt-0.5"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                      </svg>
                      <div>
                        <strong>Starter Package:</strong> Quarterly dividend payments (every 3 months)
                      </div>
                    </li>
                    <li className="flex items-start">
                      <svg
                        className="h-6 w-6 text-green-600 mr-2 mt-0.5"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                      </svg>
                      <div>
                        <strong>Premium & Enterprise Packages:</strong> Monthly dividend payments
                      </div>
                    </li>
                    <li className="flex items-start">
                      <svg
                        className="h-6 w-6 text-green-600 mr-2 mt-0.5"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                      </svg>
                      <div>
                        <strong>Payment Method:</strong> Direct bank transfer to investor's designated account
                      </div>
                    </li>
                    <li className="flex items-start">
                      <svg
                        className="h-6 w-6 text-green-600 mr-2 mt-0.5"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                      </svg>
                      <div>
                        <strong>Taxation:</strong> 10% withholding tax applied as per Bangladesh tax regulations
                      </div>
                    </li>
                  </ul>
                </div>

                <h3 className="text-xl font-bold text-gray-800 mb-4">Legal Structure</h3>
                <p>
                  Investments are structured as profit-sharing agreements in compliance with Bangladesh's financial
                  regulations. Each investor will receive:
                </p>
                <ul>
                  <li>A legally binding investment agreement</li>
                  <li>Investment certificate</li>
                  <li>Regular financial statements and performance reports</li>
                  <li>Access to our investor portal for real-time updates</li>
                </ul>

                <h3 className="text-xl font-bold text-gray-800 mb-4 mt-8">Additional Benefits</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                  <div className="bg-white p-6 rounded-lg shadow-md">
                    <h4 className="font-bold text-lg mb-2">Discounted Services</h4>
                    <p className="text-gray-600">
                      Investors receive significant discounts on our Hajj and Umrah packages, ranging from 5-15%
                      depending on the investment package.
                    </p>
                  </div>
                  <div className="bg-white p-6 rounded-lg shadow-md">
                    <h4 className="font-bold text-lg mb-2">Priority Booking</h4>
                    <p className="text-gray-600">
                      Investors receive priority booking for Hajj and Umrah packages, including access to limited
                      availability premium accommodations.
                    </p>
                  </div>
                  <div className="bg-white p-6 rounded-lg shadow-md">
                    <h4 className="font-bold text-lg mb-2">Investor Events</h4>
                    <p className="text-gray-600">
                      Premium and Enterprise investors are invited to annual investor conferences and networking events
                      with our management team.
                    </p>
                  </div>
                </div>

                <h3 className="text-xl font-bold text-gray-800 mb-4">Exit Strategy</h3>
                <p>At the end of the investment term, investors have the following options:</p>
                <ul>
                  <li>Withdraw the full principal amount</li>
                  <li>Renew the investment for another term at the prevailing rates</li>
                  <li>Upgrade to a higher investment package</li>
                </ul>
                <p>
                  For Enterprise package investors, we also offer the possibility of equity conversion subject to mutual
                  agreement and valuation at the time.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Next Steps */}
        <section id="next-steps" className="py-16 bg-gray-50">
          <div className="container mx-auto px-4">
            <div className="max-w-5xl mx-auto">
              <div className="flex items-center mb-8">
                <div className="w-12 h-12 rounded-full bg-green-600 text-white flex items-center justify-center mr-4">
                  <span className="text-xl font-bold">8</span>
                </div>
                <h2 className="text-3xl font-bold text-gray-800">Next Steps</h2>
              </div>

              <div className="prose prose-lg max-w-none">
                <p>
                  We invite you to join us in this profitable venture that combines financial returns with the
                  opportunity to contribute to facilitating religious pilgrimages for thousands of Muslims. Here's how
                  to proceed:
                </p>

                <div className="grid grid-cols-1 md:grid-cols-4 gap-6 my-8">
                  <div className="bg-white p-6 rounded-lg shadow-md text-center">
                    <div className="w-12 h-12 rounded-full bg-green-600 text-white flex items-center justify-center mx-auto mb-4">
                      <span className="font-bold">1</span>
                    </div>
                    <h3 className="font-bold text-lg mb-2">Initial Consultation</h3>
                    <p className="text-gray-600 text-sm">
                      Schedule a meeting with our investment team to discuss your investment goals and preferences.
                    </p>
                  </div>
                  <div className="bg-white p-6 rounded-lg shadow-md text-center">
                    <div className="w-12 h-12 rounded-full bg-green-600 text-white flex items-center justify-center mx-auto mb-4">
                      <span className="font-bold">2</span>
                    </div>
                    <h3 className="font-bold text-lg mb-2">Due Diligence</h3>
                    <p className="text-gray-600 text-sm">
                      Review our detailed financial statements, legal documentation, and ask any questions you may have.
                    </p>
                  </div>
                  <div className="bg-white p-6 rounded-lg shadow-md text-center">
                    <div className="w-12 h-12 rounded-full bg-green-600 text-white flex items-center justify-center mx-auto mb-4">
                      <span className="font-bold">3</span>
                    </div>
                    <h3 className="font-bold text-lg mb-2">Investment Agreement</h3>
                    <p className="text-gray-600 text-sm">
                      Sign the investment agreement and complete the necessary documentation and KYC requirements.
                    </p>
                  </div>
                  <div className="bg-white p-6 rounded-lg shadow-md text-center">
                    <div className="w-12 h-12 rounded-full bg-green-600 text-white flex items-center justify-center mx-auto mb-4">
                      <span className="font-bold">4</span>
                    </div>
                    <h3 className="font-bold text-lg mb-2">Fund Transfer</h3>
                    <p className="text-gray-600 text-sm">
                      Transfer your investment amount to our designated bank account and receive your investment
                      certificate.
                    </p>
                  </div>
                </div>

                <div className="bg-green-50 p-6 rounded-lg mb-8">
                  <h3 className="text-xl font-bold text-gray-800 mb-4">Required Documentation</h3>
                  <ul className="space-y-2">
                    <li className="flex items-start">
                      <svg
                        className="h-5 w-5 text-green-600 mr-2 mt-0.5"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                      </svg>
                      <span>Valid National ID Card or Passport</span>
                    </li>
                    <li className="flex items-start">
                      <svg
                        className="h-5 w-5 text-green-600 mr-2 mt-0.5"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                      </svg>
                      <span>Proof of Address (utility bill or bank statement)</span>
                    </li>
                    <li className="flex items-start">
                      <svg
                        className="h-5 w-5 text-green-600 mr-2 mt-0.5"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                      </svg>
                      <span>Bank Account Details</span>
                    </li>
                    <li className="flex items-start">
                      <svg
                        className="h-5 w-5 text-green-600 mr-2 mt-0.5"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                      </svg>
                      <span>TIN Certificate (for investments over BDT 10,00,000)</span>
                    </li>
                    <li className="flex items-start">
                      <svg
                        className="h-5 w-5 text-green-600 mr-2 mt-0.5"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                      </svg>
                      <span>Completed Investment Application Form</span>
                    </li>
                  </ul>
                </div>

                <h3 className="text-xl font-bold text-gray-800 mb-4">Contact Information</h3>
                <p>For more information or to schedule a consultation, please contact our investment team:</p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 my-6">
                  <div className="flex items-start">
                    <svg
                      className="h-6 w-6 text-green-600 mr-3 mt-0.5"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth="2"
                        d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"
                      />
                    </svg>
                    <div>
                      <h4 className="font-bold">Email</h4>
                      <p className="text-green-600">investment@t-ally-umrah.com</p>
                    </div>
                  </div>
                  <div className="flex items-start">
                    <svg
                      className="h-6 w-6 text-green-600 mr-3 mt-0.5"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth="2"
                        d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"
                      />
                    </svg>
                    <div>
                      <h4 className="font-bold">Phone</h4>
                      <p className="text-green-600">+880 1892051303</p>
                    </div>
                  </div>
                  <div className="flex items-start">
                    <svg
                      className="h-6 w-6 text-green-600 mr-3 mt-0.5"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth="2"
                        d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"
                      />
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth="2"
                        d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"
                      />
                    </svg>
                    <div>
                      <h4 className="font-bold">Office Address</h4>
                      <p className="text-gray-600">121 Islamic Center, Ally Street, UK</p>
                    </div>
                  </div>
                  <div className="flex items-start">
                    <svg
                      className="h-6 w-6 text-green-600 mr-3 mt-0.5"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth="2"
                        d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
                      />
                    </svg>
                    <div>
                      <h4 className="font-bold">Business Hours</h4>
                      <p className="text-gray-600">Sunday to Thursday: 9:00 AM - 6:00 PM</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-16 bg-green-600 text-white">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">Join Us in This Profitable Venture</h2>
            <p className="text-xl mb-8 max-w-3xl mx-auto">
              Invest in T-Ally Umrah Sr. today and become part of our success story. Enjoy attractive returns while
              contributing to a meaningful cause.
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <Link
                href="/investment/apply"
                className="bg-white text-green-600 px-8 py-3 rounded-md font-medium hover:bg-gray-100 transition-colors"
              >
                Apply Now
              </Link>
              <Link
                href="/contact"
                className="bg-transparent border-2 border-white text-white px-8 py-3 rounded-md font-medium hover:bg-white hover:text-green-600 transition-colors"
              >
                Contact Us
              </Link>
            </div>
          </div>
        </section>

        {/* Disclaimer Section */}
        <section className="py-8 bg-gray-100">
          <div className="container mx-auto px-4">
            <div className="max-w-5xl mx-auto">
              <div className="text-sm text-gray-600">
                <h3 className="font-bold mb-2">Disclaimer</h3>
                <p>
                  This investment proposal is for informational purposes only and does not constitute an offer to sell
                  or a solicitation of an offer to buy any securities. Investments involve risk, and past performance is
                  not indicative of future results. Potential investors should conduct their own due diligence and
                  consult with financial advisors before making any investment decisions.
                </p>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}

