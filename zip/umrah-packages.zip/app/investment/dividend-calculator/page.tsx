import Image from "next/image"
import Link from "next/link"
import { Footer } from "@/components/footer"

export default function DividendCalculatorPage() {
  // Quarterly dividend calculation for 500,000 BDT investment
  const investmentAmount = 500000
  const annualRate = 0.12 // 12% annual rate for starter package
  const quarterlyRate = annualRate / 4
  const quarterlyDividend = investmentAmount * quarterlyRate
  const monthlyDividend = investmentAmount * (annualRate / 12)

  return (
    <div className="min-h-screen flex flex-col">
      <header className="bg-green-600 text-white py-4">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center gap-2">
              <Image
                src="https://mj-ahmad.github.io/mja2025/img/logo.png"
                alt="TRUSTED-ALLY Logo"
                width={40}
                height={40}
                className="h-10 w-auto"
              />
              <span className="font-bold text-xl">T-Ally Umrah Sr.</span>
            </Link>
            <nav className="hidden md:flex space-x-6">
              <Link href="/" className="hover:text-green-200 transition-colors">
                Home
              </Link>
              <Link href="/packages" className="hover:text-green-200 transition-colors">
                Packages
              </Link>
              <Link href="/services" className="hover:text-green-200 transition-colors">
                Services
              </Link>
              <Link href="/investment" className="hover:text-green-200 transition-colors">
                Investment
              </Link>
              <Link href="/about" className="hover:text-green-200 transition-colors">
                About
              </Link>
              <Link href="/contact" className="hover:text-green-200 transition-colors">
                Contact
              </Link>
            </nav>
          </div>
        </div>
      </header>

      <main className="flex-grow">
        {/* Hero Section */}
        <section className="bg-green-50 py-12">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto text-center">
              <h1 className="text-3xl md:text-4xl font-bold text-gray-800 mb-4">লভ্যাংশ ক্যালকুলেটর</h1>
              <p className="text-lg text-gray-600 mb-8">
                আপনার বিনিয়োগের উপর প্রত্যাশিত লভ্যাংশ এবং আমাদের লভ্যাংশ বিতরণ প্রক্রিয়া সম্পর্কে জানুন
              </p>
            </div>
          </div>
        </section>

        {/* Dividend Calculator Section */}
        <section className="py-16 bg-white">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto">
              <div className="bg-white rounded-lg shadow-lg overflow-hidden mb-12">
                <div className="bg-green-600 text-white p-6">
                  <h2 className="text-2xl font-bold">৫০০,০০০ টাকা বিনিয়োগে প্রত্যাশিত লভ্যাংশ</h2>
                </div>
                <div className="p-6">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div className="bg-green-50 p-6 rounded-lg text-center">
                      <h3 className="text-lg font-semibold text-gray-700 mb-2">ত্রৈমাসিক লভ্যাংশ</h3>
                      <p className="text-3xl font-bold text-green-600">৳{quarterlyDividend.toLocaleString()}</p>
                      <p className="text-gray-500 mt-2">প্রতি ৩ মাসে</p>
                    </div>
                    <div className="bg-green-50 p-6 rounded-lg text-center">
                      <h3 className="text-lg font-semibold text-gray-700 mb-2">মাসিক লভ্যাংশ</h3>
                      <p className="text-3xl font-bold text-green-600">৳{monthlyDividend.toLocaleString()}</p>
                      <p className="text-gray-500 mt-2">প্রতি মাসে</p>
                    </div>
                    <div className="bg-green-50 p-6 rounded-lg text-center">
                      <h3 className="text-lg font-semibold text-gray-700 mb-2">বার্ষিক লভ্যাংশ</h3>
                      <p className="text-3xl font-bold text-green-600">
                        ৳{(investmentAmount * annualRate).toLocaleString()}
                      </p>
                      <p className="text-gray-500 mt-2">প্রতি বছরে</p>
                    </div>
                  </div>

                  <div className="mt-8 bg-gray-50 p-6 rounded-lg">
                    <h3 className="text-xl font-bold text-gray-800 mb-4">বিনিয়োগ বিবরণ</h3>
                    <div className="space-y-3">
                      <div className="flex justify-between border-b pb-2">
                        <span className="font-medium">মূল বিনিয়োগ</span>
                        <span>৳৫০০,০০০</span>
                      </div>
                      <div className="flex justify-between border-b pb-2">
                        <span className="font-medium">বার্ষিক লভ্যাংশ হার</span>
                        <span>১২%</span>
                      </div>
                      <div className="flex justify-between border-b pb-2">
                        <span className="font-medium">ত্রৈমাসিক লভ্যাংশ হার</span>
                        <span>৩%</span>
                      </div>
                      <div className="flex justify-between border-b pb-2">
                        <span className="font-medium">বিনিয়োগ প্যাকেজ</span>
                        <span>স্টার্টার প্যাকেজ</span>
                      </div>
                      <div className="flex justify-between border-b pb-2">
                        <span className="font-medium">মেয়াদ</span>
                        <span>১ বছর</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="font-medium">মোট প্রত্যাশিত লভ্যাংশ (১ বছরে)</span>
                        <span className="font-bold text-green-600">
                          ৳{(investmentAmount * annualRate).toLocaleString()}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Dividend Distribution Process */}
              <div className="bg-white rounded-lg shadow-lg overflow-hidden">
                <div className="bg-green-600 text-white p-6">
                  <h2 className="text-2xl font-bold">লভ্যাংশ বিতরণ প্রক্রিয়া</h2>
                </div>
                <div className="p-6">
                  <div className="space-y-8">
                    <div>
                      <h3 className="text-xl font-bold text-gray-800 mb-3">লভ্যাংশ কীভাবে গণনা করা হয়?</h3>
                      <p className="text-gray-600 mb-4">
                        আমাদের লভ্যাংশ গণনা প্রক্রিয়া সহজ এবং স্বচ্ছ। আমরা নিম্নলিখিত সূত্র ব্যবহার করি:
                      </p>
                      <div className="bg-gray-50 p-4 rounded-lg">
                        <p className="font-medium text-center">
                          ত্রৈমাসিক লভ্যাংশ = (বিনিয়োগের পরিমাণ × বার্ষিক লভ্যাংশ হার) ÷ ৪
                        </p>
                      </div>
                      <p className="text-gray-600 mt-4">উদাহরণস্বরূপ, ৫০০,০০০ টাকা বিনিয়োগে ১২% বার্ষিক হারে:</p>
                      <div className="bg-gray-50 p-4 rounded-lg mt-2">
                        <p className="font-medium text-center">ত্রৈমাসিক লভ্যাংশ = (৫০০,০০০ × ০.১২) ÷ ৪ = ১৫,০০০ টাকা</p>
                      </div>
                    </div>

                    <div>
                      <h3 className="text-xl font-bold text-gray-800 mb-3">লভ্যাংশ বিতরণের সময়সূচী</h3>
                      <p className="text-gray-600 mb-4">আমরা বিনিয়োগ প্যাকেজ অনুযায়ী নিম্নলিখিত সময়সূচী অনুসরণ করি:</p>
                      <div className="overflow-x-auto">
                        <table className="min-w-full bg-white border border-gray-200">
                          <thead>
                            <tr>
                              <th className="py-3 px-4 bg-gray-50 text-left border-b">প্যাকেজ</th>
                              <th className="py-3 px-4 bg-gray-50 text-left border-b">বিতরণের সময়</th>
                              <th className="py-3 px-4 bg-gray-50 text-left border-b">প্রক্রিয়া</th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr>
                              <td className="py-3 px-4 border-b">স্টার্টার প্যাকেজ</td>
                              <td className="py-3 px-4 border-b">প্রতি ৩ মাস অন্তর</td>
                              <td className="py-3 px-4 border-b">প্রতি ত্রৈমাসিকের শেষ দিনে ব্যাংক ট্রান্সফার</td>
                            </tr>
                            <tr>
                              <td className="py-3 px-4 border-b">প্রিমিয়াম প্যাকেজ</td>
                              <td className="py-3 px-4 border-b">প্রতি মাসে</td>
                              <td className="py-3 px-4 border-b">প্রতি মাসের ৫ তারিখের মধ্যে ব্যাংক ট্রান্সফার</td>
                            </tr>
                            <tr>
                              <td className="py-3 px-4 border-b">এন্টারপ্রাইজ প্যাকেজ</td>
                              <td className="py-3 px-4 border-b">প্রতি মাসে</td>
                              <td className="py-3 px-4 border-b">প্রতি মাসের ৫ তারিখের মধ্যে ব্যাংক ট্রান্সফার</td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>

                    <div>
                      <h3 className="text-xl font-bold text-gray-800 mb-3">লভ্যাংশের উৎস</h3>
                      <p className="text-gray-600 mb-4">আমাদের লভ্যাংশ নিম্নলিখিত উৎস থেকে আসে:</p>
                      <ul className="space-y-2">
                        <li className="flex items-start">
                          <svg
                            className="h-5 w-5 text-green-500 mr-2 mt-0.5"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor"
                          >
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                          </svg>
                          <span className="text-gray-600">
                            <span className="font-medium">হজ্জ ও উমরাহ প্যাকেজ বিক্রয়:</span> আমাদের মোট আয়ের ৬০% আসে হজ্জ ও
                            উমরাহ প্যাকেজ বিক্রয় থেকে।
                          </span>
                        </li>
                        <li className="flex items-start">
                          <svg
                            className="h-5 w-5 text-green-500 mr-2 mt-0.5"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor"
                          >
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                          </svg>
                          <span className="text-gray-600">
                            <span className="font-medium">হোটেল ও পরিবহন সেবা:</span> আমাদের মোট আয়ের ২৫% আসে হোটেল বুকিং
                            এবং পরিবহন সেবা থেকে।
                          </span>
                        </li>
                        <li className="flex items-start">
                          <svg
                            className="h-5 w-5 text-green-500 mr-2 mt-0.5"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor"
                          >
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                          </svg>
                          <span className="text-gray-600">
                            <span className="font-medium">ভিসা প্রসেসিং:</span> আমাদের মোট আয়ের ১০% আসে ভিসা প্রসেসিং ফি
                            থেকে।
                          </span>
                        </li>
                        <li className="flex items-start">
                          <svg
                            className="h-5 w-5 text-green-500 mr-2 mt-0.5"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor"
                          >
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                          </svg>
                          <span className="text-gray-600">
                            <span className="font-medium">অন্যান্য সেবা:</span> আমাদের মোট আয়ের ৫% আসে অন্যান্য সেবা যেমন গাইড
                            সার্ভিস, ফুড সার্ভিস ইত্যাদি থেকে।
                          </span>
                        </li>
                      </ul>
                    </div>

                    <div>
                      <h3 className="text-xl font-bold text-gray-800 mb-3">লভ্যাংশ বিতরণ প্রক্রিয়া</h3>
                      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
                        <div className="bg-gray-50 p-4 rounded-lg text-center">
                          <div className="w-10 h-10 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-3">
                            <span className="text-white font-bold">১</span>
                          </div>
                          <h4 className="font-medium mb-2">লাভ গণনা</h4>
                          <p className="text-sm text-gray-600">প্রতি ত্রৈমাসিকের শেষে আমরা মোট লাভ গণনা করি</p>
                        </div>
                        <div className="bg-gray-50 p-4 rounded-lg text-center">
                          <div className="w-10 h-10 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-3">
                            <span className="text-white font-bold">২</span>
                          </div>
                          <h4 className="font-medium mb-2">লভ্যাংশ নির্ধারণ</h4>
                          <p className="text-sm text-gray-600">বিনিয়োগকারীদের জন্য লভ্যাংশ নির্ধারণ করা হয়</p>
                        </div>
                        <div className="bg-gray-50 p-4 rounded-lg text-center">
                          <div className="w-10 h-10 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-3">
                            <span className="text-white font-bold">৩</span>
                          </div>
                          <h4 className="font-medium mb-2">অনুমোদন</h4>
                          <p className="text-sm text-gray-600">ব্যবস্থাপনা পরিষদ লভ্যাংশ অনুমোদন করে</p>
                        </div>
                        <div className="bg-gray-50 p-4 rounded-lg text-center">
                          <div className="w-10 h-10 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-3">
                            <span className="text-white font-bold">৪</span>
                          </div>
                          <h4 className="font-medium mb-2">বিতরণ</h4>
                          <p className="text-sm text-gray-600">লভ্যাংশ বিনিয়োগকারীদের ব্যাংক অ্যাকাউন্টে পাঠানো হয়</p>
                        </div>
                      </div>
                      <p className="text-gray-600">
                        আমরা প্রতি ত্রৈমাসিকের শেষে (মার্চ, জুন, সেপ্টেম্বর, ডিসেম্বর) লভ্যাংশ বিতরণ করি। লভ্যাংশ সরাসরি আপনার ব্যাংক
                        অ্যাকাউন্টে পাঠানো হয়। আপনি আপনার অনলাইন ড্যাশবোর্ডে লগইন করে আপনার লভ্যাংশের ইতিহাস দেখতে পারেন।
                      </p>
                    </div>

                    <div>
                      <h3 className="text-xl font-bold text-gray-800 mb-3">লভ্যাংশ হারের প্রভাবক</h3>
                      <p className="text-gray-600 mb-4">লভ্যাংশ হার নিম্নলিখিত কারণে পরিবর্তিত হতে পারে:</p>
                      <ul className="space-y-2">
                        <li className="flex items-start">
                          <svg
                            className="h-5 w-5 text-green-500 mr-2 mt-0.5"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor"
                          >
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                          </svg>
                          <span className="text-gray-600">
                            <span className="font-medium">বাজার পরিস্থিতি:</span> হজ্জ ও উমরাহ সিজনে চাহিদা বেশি থাকলে লাভের হার
                            বাড়তে পারে।
                          </span>
                        </li>
                        <li className="flex items-start">
                          <svg
                            className="h-5 w-5 text-green-500 mr-2 mt-0.5"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor"
                          >
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                          </svg>
                          <span className="text-gray-600">
                            <span className="font-medium">অর্থনৈতিক অবস্থা:</span> দেশের সামগ্রিক অর্থনৈতিক অবস্থা লভ্যাংশ হারকে
                            প্রভাবিত করতে পারে।
                          </span>
                        </li>
                        <li className="flex items-start">
                          <svg
                            className="h-5 w-5 text-green-500 mr-2 mt-0.5"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor"
                          >
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                          </svg>
                          <span className="text-gray-600">
                            <span className="font-medium">বিনিয়োগের পরিমাণ:</span> বড় পরিমাণে বিনিয়োগ করলে উচ্চ হারে লভ্যাংশ
                            পাওয়া যেতে পারে।
                          </span>
                        </li>
                        <li className="flex items-start">
                          <svg
                            className="h-5 w-5 text-green-500 mr-2 mt-0.5"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor"
                          >
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                          </svg>
                          <span className="text-gray-600">
                            <span className="font-medium">বিনিয়োগের মেয়াদ:</span> দীর্ঘ মেয়াদে বিনিয়োগ করলে উচ্চ হারে লভ্যাংশ
                            পাওয়া যেতে পারে।
                          </span>
                        </li>
                      </ul>
                    </div>

                    <div className="bg-green-50 p-6 rounded-lg">
                      <h3 className="text-xl font-bold text-gray-800 mb-3">বিনিয়োগকারীদের সুবিধা</h3>
                      <p className="text-gray-600 mb-4">আমাদের সাথে বিনিয়োগ করলে আপনি নিম্নলিখিত সুবিধাগুলি পাবেন:</p>
                      <ul className="space-y-2">
                        <li className="flex items-start">
                          <svg
                            className="h-5 w-5 text-green-500 mr-2 mt-0.5"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor"
                          >
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                          </svg>
                          <span className="text-gray-600">নিয়মিত ও নির্ভরযোগ্য আয়</span>
                        </li>
                        <li className="flex items-start">
                          <svg
                            className="h-5 w-5 text-green-500 mr-2 mt-0.5"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor"
                          >
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                          </svg>
                          <span className="text-gray-600">হজ্জ ও উমরাহ প্যাকেজে বিশেষ ছাড়</span>
                        </li>
                        <li className="flex items-start">
                          <svg
                            className="h-5 w-5 text-green-500 mr-2 mt-0.5"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor"
                          >
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                          </svg>
                          <span className="text-gray-600">বিনিয়োগকারীদের জন্য বিশেষ অনুষ্ঠানে অংশগ্রহণের সুযোগ</span>
                        </li>
                        <li className="flex items-start">
                          <svg
                            className="h-5 w-5 text-green-500 mr-2 mt-0.5"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor"
                          >
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                          </svg>
                          <span className="text-gray-600">পুনঃবিনিয়োগের সুযোগ</span>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* FAQ Section */}
        <section className="py-16 bg-gray-50">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto">
              <h2 className="text-3xl font-bold text-gray-800 mb-8 text-center">সাধারণ জিজ্ঞাসা</h2>
              <div className="space-y-6">
                <div className="bg-white rounded-lg shadow p-6">
                  <h3 className="text-xl font-bold text-gray-800 mb-2">লভ্যাংশ কি নির্দিষ্ট সময়ে পাওয়া যায়?</h3>
                  <p className="text-gray-600">
                    হ্যাঁ, আমরা নির্দিষ্ট সময়সূচী অনুযায়ী লভ্যাংশ বিতরণ করি। স্টার্টার প্যাকেজের জন্য প্রতি ৩ মাস অন্তর, এবং প্রিমিয়াম ও
                    এন্টারপ্রাইজ প্যাকেজের জন্য প্রতি মাসে লভ্যাংশ বিতরণ করা হয়।
                  </p>
                </div>
                <div className="bg-white rounded-lg shadow p-6">
                  <h3 className="text-xl font-bold text-gray-800 mb-2">লভ্যাংশের হার কি পরিবর্তন হতে পারে?</h3>
                  <p className="text-gray-600">
                    আমরা ন্যূনতম লভ্যাংশ হার গ্যারান্টি করি। তবে বাজার পরিস্থিতি অনুযায়ী লভ্যাংশের হার বাড়তে পারে। আমরা সর্বদা আমাদের
                    বিনিয়োগকারীদের সর্বোচ্চ লাভ নিশ্চিত করার চেষ্টা করি।
                  </p>
                </div>
                <div className="bg-white rounded-lg shadow p-6">
                  <h3 className="text-xl font-bold text-gray-800 mb-2">লভ্যাংশ কি ব্যাংক অ্যাকাউন্টে সরাসরি পাঠানো হয়?</h3>
                  <p className="text-gray-600">
                    হ্যাঁ, আমরা লভ্যাংশ সরাসরি আপনার ব্যাংক অ্যাকাউন্টে পাঠাই। আপনি বিনিয়োগ করার সময় আপনার ব্যাংক অ্যাকাউন্ট বিবরণ প্রদান করবেন,
                    এবং সেই অ্যাকাউন্টে লভ্যাংশ পাঠানো হবে।
                  </p>
                </div>
                <div className="bg-white rounded-lg shadow p-6">
                  <h3 className="text-xl font-bold text-gray-800 mb-2">লভ্যাংশের উপর কি কর প্রযোজ্য?</h3>
                  <p className="text-gray-600">
                    হ্যাঁ, বাংলাদেশের আইন অনুযায়ী লভ্যাংশের উপর ১০% উৎসে কর কর্তন করা হয়। আমরা এই কর কেটে নিয়ে বাকি অর্থ আপনার অ্যাকাউন্টে
                    পাঠাই।
                  </p>
                </div>
                <div className="bg-white rounded-lg shadow p-6">
                  <h3 className="text-xl font-bold text-gray-800 mb-2">মেয়াদ শেষে কি মূলধন ফেরত পাওয়া যায়?</h3>
                  <p className="text-gray-600">
                    হ্যাঁ, বিনিয়োগের মেয়াদ শেষে আপনি আপনার সম্পূর্ণ মূলধন ফেরত পাবেন। আপনি চাইলে মূলধন পুনরায় বিনিয়োগ করতে পারেন অথবা
                    উত্তোলন করতে পারেন।
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-16 bg-green-600 text-white">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">আজই বিনিয়োগ শুরু করুন</h2>
            <p className="text-xl mb-8 max-w-3xl mx-auto">
              T-Ally Umrah Sr. এর সাথে বিনিয়োগ করে নিয়মিত লভ্যাংশ পান এবং হজ্জ ও উমরাহ সেবা খাতে অবদান রাখুন।
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <Link
                href="/investment/apply"
                className="bg-white text-green-600 px-8 py-3 rounded-md font-medium hover:bg-gray-100 transition-colors"
              >
                বিনিয়োগ করুন
              </Link>
              <Link
                href="/investment"
                className="bg-transparent border-2 border-white text-white px-8 py-3 rounded-md font-medium hover:bg-white hover:text-green-600 transition-colors"
              >
                আরও জানুন
              </Link>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}

