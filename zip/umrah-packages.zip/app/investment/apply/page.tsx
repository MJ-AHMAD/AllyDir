import Image from "next/image"
import Link from "next/link"
import { Footer } from "@/components/footer"

export default function InvestmentApplyPage() {
  return (
    <div className="min-h-screen flex flex-col">
      <header className="bg-green-600 text-white py-4">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center gap-2">
              <Image
                src="/placeholder.svg?height=40&width=40"
                alt="TRUSTED-ALLY Logo"
                width={40}
                height={40}
                className="h-10 w-auto"
              />
              <span className="font-bold text-xl">T-Ally Umrah Sr.</span>
            </Link>
            <nav className="hidden md:flex space-x-6">
              <Link href="/" className="hover:text-green-200 transition-colors">
                Home
              </Link>
              <Link href="/packages" className="hover:text-green-200 transition-colors">
                Packages
              </Link>
              <Link href="/services" className="hover:text-green-200 transition-colors">
                Services
              </Link>
              <Link href="/investment" className="hover:text-green-200 transition-colors">
                Investment
              </Link>
              <Link href="/contact" className="hover:text-green-200 transition-colors">
                Contact
              </Link>
            </nav>
          </div>
        </div>
      </header>

      <main className="flex-grow">
        <section className="py-12 bg-gray-50">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto bg-white rounded-lg shadow-lg p-8">
              <div className="text-center mb-8">
                <h1 className="text-3xl font-bold text-gray-800 mb-4">বিনিয়োগ আবেদন ফর্ম</h1>
                <p className="text-gray-600">
                  আপনার বিনিয়োগ আবেদন সম্পূর্ণ করতে নিম্নলিখিত ফর্মটি পূরণ করুন। আমাদের টিম আপনার সাথে যোগাযোগ করবে।
                </p>
              </div>

              <form className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label htmlFor="fullName" className="block text-sm font-medium text-gray-700 mb-1">
                      পূর্ণ নাম *
                    </label>
                    <input
                      type="text"
                      id="fullName"
                      name="fullName"
                      required
                      className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    />
                  </div>

                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                      ইমেইল *
                    </label>
                    <input
                      type="email"
                      id="email"
                      name="email"
                      required
                      className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    />
                  </div>

                  <div>
                    <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-1">
                      মোবাইল নম্বর *
                    </label>
                    <input
                      type="tel"
                      id="phone"
                      name="phone"
                      required
                      className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    />
                  </div>

                  <div>
                    <label htmlFor="address" className="block text-sm font-medium text-gray-700 mb-1">
                      ঠিকানা *
                    </label>
                    <input
                      type="text"
                      id="address"
                      name="address"
                      required
                      className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    />
                  </div>

                  <div>
                    <label htmlFor="investmentPackage" className="block text-sm font-medium text-gray-700 mb-1">
                      বিনিয়োগ প্যাকেজ *
                    </label>
                    <select
                      id="investmentPackage"
                      name="investmentPackage"
                      required
                      className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    >
                      <option value="">প্যাকেজ নির্বাচন করুন</option>
                      <option value="starter">স্টার্টার প্যাকেজ (৳৫,০০,০০০)</option>
                      <option value="premium">প্রিমিয়াম প্যাকেজ (৳২৫,০০,০০০)</option>
                      <option value="enterprise">এন্টারপ্রাইজ প্যাকেজ (৳১,০০,০০,০০০)</option>
                      <option value="custom">কাস্টম বিনিয়োগ</option>
                    </select>
                  </div>

                  <div>
                    <label htmlFor="investmentAmount" className="block text-sm font-medium text-gray-700 mb-1">
                      বিনিয়োগের পরিমাণ (টাকা) *
                    </label>
                    <input
                      type="number"
                      id="investmentAmount"
                      name="investmentAmount"
                      required
                      className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    />
                  </div>

                  <div>
                    <label htmlFor="occupation" className="block text-sm font-medium text-gray-700 mb-1">
                      পেশা
                    </label>
                    <input
                      type="text"
                      id="occupation"
                      name="occupation"
                      className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    />
                  </div>

                  <div>
                    <label htmlFor="nidNumber" className="block text-sm font-medium text-gray-700 mb-1">
                      জাতীয় পরিচয়পত্র নম্বর *
                    </label>
                    <input
                      type="text"
                      id="nidNumber"
                      name="nidNumber"
                      required
                      className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    />
                  </div>
                </div>

                <div>
                  <label htmlFor="investmentPurpose" className="block text-sm font-medium text-gray-700 mb-1">
                    বিনিয়োগের উদ্দেশ্য
                  </label>
                  <textarea
                    id="investmentPurpose"
                    name="investmentPurpose"
                    rows={4}
                    className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  ></textarea>
                </div>

                <div>
                  <label htmlFor="additionalInfo" className="block text-sm font-medium text-gray-700 mb-1">
                    অতিরিক্ত তথ্য
                  </label>
                  <textarea
                    id="additionalInfo"
                    name="additionalInfo"
                    rows={4}
                    className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  ></textarea>
                </div>

                <div className="flex items-start">
                  <input type="checkbox" id="termsAgreement" name="termsAgreement" required className="mt-1 mr-2" />
                  <label htmlFor="termsAgreement" className="text-sm text-gray-700">
                    আমি{" "}
                    <Link href="/terms" className="text-green-600 hover:underline">
                      শর্তাবলী
                    </Link>{" "}
                    এবং{" "}
                    <Link href="/privacy" className="text-green-600 hover:underline">
                      গোপনীয়তা নীতি
                    </Link>{" "}
                    পড়েছি এবং সম্মত আছি।
                  </label>
                </div>

                <div className="flex justify-center">
                  <button
                    type="submit"
                    className="bg-green-600 text-white px-8 py-3 rounded-md font-medium hover:bg-green-700 transition-colors"
                  >
                    আবেদন জমা দিন
                  </button>
                </div>
              </form>
            </div>
          </div>
        </section>

        <section className="py-12 bg-white">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto">
              <h2 className="text-2xl font-bold text-gray-800 mb-6 text-center">বিনিয়োগ প্রক্রিয়া</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div className="text-center">
                  <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-4 text-white text-2xl font-bold">
                    1
                  </div>
                  <h3 className="text-xl font-bold mb-2">আবেদন</h3>
                  <p className="text-gray-600">অনলাইনে আবেদন ফর্ম পূরণ করুন এবং আপনার পছন্দের বিনিয়োগ প্যাকেজ নির্বাচন করুন।</p>
                </div>

                <div className="text-center">
                  <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-4 text-white text-2xl font-bold">
                    2
                  </div>
                  <h3 className="text-xl font-bold mb-2">যাচাই-বাছাই</h3>
                  <p className="text-gray-600">আমাদের টিম আপনার আবেদন পর্যালোচনা করবে এবং আপনার সাথে যোগাযোগ করবে।</p>
                </div>

                <div className="text-center">
                  <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-4 text-white text-2xl font-bold">
                    3
                  </div>
                  <h3 className="text-xl font-bold mb-2">চুক্তি ও বিনিয়োগ</h3>
                  <p className="text-gray-600">চুক্তি সম্পাদন এবং বিনিয়োগের অর্থ প্রদানের মাধ্যমে বিনিয়োগ প্রক্রিয়া সম্পন্ন করুন।</p>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}

