import Image from "next/image"
import Link from "next/link"
import { Footer } from "@/components/footer"

export default function InvestmentPage() {
  return (
    <div className="min-h-screen flex flex-col">
      <header className="bg-green-600 text-white py-4">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center gap-2">
              <Image
                src="https://mj-ahmad.github.io/mja2025/img/logo.png"
                alt="TRUSTED-ALLY Logo"
                width={40}
                height={40}
                className="h-10 w-auto"
              />
              <span className="font-bold text-xl">T-Ally Umrah Sr.</span>
            </Link>
            <nav className="hidden md:flex space-x-6">
              <Link href="/" className="hover:text-green-200 transition-colors">
                Home
              </Link>
              <Link href="/packages" className="hover:text-green-200 transition-colors">
                Packages
              </Link>
              <Link href="/services" className="hover:text-green-200 transition-colors">
                Services
              </Link>
              <Link href="/about" className="hover:text-green-200 transition-colors">
                About
              </Link>
              <Link href="/contact" className="hover:text-green-200 transition-colors">
                Contact
              </Link>
            </nav>
          </div>
        </div>
      </header>

      <main className="flex-grow">
        {/* Hero Section */}
        <section className="relative h-[50vh]">
          <Image
            src="https://mj-ahmad.github.io/mja2025/img/tr000.png"
            alt="Investment Opportunities"
            fill
            className="object-cover"
          />
          <div className="absolute inset-0 bg-black/60 flex items-center justify-center">
            <div className="text-center px-4 max-w-4xl">
              <h1 className="text-3xl md:text-5xl font-bold text-white mb-4">বিনিয়োগ সুযোগ</h1>
              <p className="text-xl text-white/90 mb-8">
                T-Ally Umrah Sr. এর সাথে বিনিয়োগ করুন এবং হজ্জ ও উমরাহ সেবা খাতে উল্লেখযোগ্য লাভ অর্জন করুন
              </p>
              <Link
                href="#investment-packages"
                className="inline-block bg-green-600 text-white px-8 py-3 rounded-md font-medium hover:bg-green-700 transition-colors"
              >
                বিনিয়োগ প্যাকেজ দেখুন
              </Link>
            </div>
          </div>
        </section>

        {/* Key Benefits Section */}
        <section className="py-16 bg-white">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-gray-800 mb-4">বিনিয়োগের সুবিধাসমূহ</h2>
              <p className="text-lg text-gray-600 max-w-3xl mx-auto">
                T-Ally Umrah Sr. এ বিনিয়োগ করে আপনি শুধু আর্থিক লাভবান হবেন না, বরং একটি ধর্মীয় সেবামূলক প্রতিষ্ঠানের অংশীদার হিসেবে
                পুণ্যও অর্জন করবেন।
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="bg-white p-6 rounded-lg shadow-lg text-center">
                <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-4">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-8 w-8 text-white"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                    />
                  </svg>
                </div>
                <h3 className="text-xl font-bold mb-2">উচ্চ লাভের সম্ভাবনা</h3>
                <p className="text-gray-600">
                  বার্ষিক ১৫-২০% লাভের সম্ভাবনা সহ আকর্ষণীয় রিটার্ন অন ইনভেস্টমেন্ট (ROI) প্রদান করা হয়।
                </p>
              </div>

              <div className="bg-white p-6 rounded-lg shadow-lg text-center">
                <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-4">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-8 w-8 text-white"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"
                    />
                  </svg>
                </div>
                <h3 className="text-xl font-bold mb-2">নিরাপদ বিনিয়োগ</h3>
                <p className="text-gray-600">
                  আমাদের প্রতিষ্ঠান ১০+ বছর ধরে সফলভাবে পরিচালিত হচ্ছে, যা আপনার বিনিয়োগের নিরাপত্তা নিশ্চিত করে।
                </p>
              </div>

              <div className="bg-white p-6 rounded-lg shadow-lg text-center">
                <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-4">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-8 w-8 text-white"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"
                    />
                  </svg>
                </div>
                <h3 className="text-xl font-bold mb-2">ক্রমবর্ধমান বাজার</h3>
                <p className="text-gray-600">
                  হজ্জ ও উমরাহ সেবা খাত প্রতিবছর ১০-১৫% হারে বৃদ্ধি পাচ্ছে, যা দীর্ঘমেয়াদী লাভের নিশ্চয়তা দেয়।
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Investment Packages Section */}
        <section id="investment-packages" className="py-16 bg-gray-50">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-gray-800 mb-4">বিনিয়োগ প্যাকেজসমূহ</h2>
              <p className="text-lg text-gray-600 max-w-3xl mx-auto">
                আমরা বিভিন্ন ধরনের বিনিয়োগকারীদের জন্য বিভিন্ন প্যাকেজ প্রদান করি। আপনার সামর্থ্য ও প্রয়োজন অনুযায়ী বিনিয়োগ করুন।
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
              <div className="bg-white rounded-lg shadow-lg overflow-hidden">
                <div className="bg-green-600 text-white p-4 text-center">
                  <h3 className="text-xl font-bold">স্টার্টার প্যাকেজ</h3>
                </div>
                <div className="p-6">
                  <div className="text-center mb-6">
                    <span className="text-4xl font-bold">৳৫,০০,০০০</span>
                    <span className="text-gray-600 block mt-1">ন্যূনতম বিনিয়োগ</span>
                  </div>
                  <ul className="space-y-3 mb-6">
                    <li className="flex items-center">
                      <svg
                        className="h-5 w-5 text-green-500 mr-2"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                      </svg>
                      <span>বার্ষিক ১২% লাভাংশ</span>
                    </li>
                    <li className="flex items-center">
                      <svg
                        className="h-5 w-5 text-green-500 mr-2"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                      </svg>
                      <span>ত্রৈমাসিক লাভাংশ প্রদান</span>
                    </li>
                    <li className="flex items-center">
                      <svg
                        className="h-5 w-5 text-green-500 mr-2"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                      </svg>
                      <span>১ বছর মেয়াদ</span>
                    </li>
                    <li className="flex items-center">
                      <svg
                        className="h-5 w-5 text-green-500 mr-2"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                      </svg>
                      <span>উমরাহ প্যাকেজে ৫% ছাড়</span>
                    </li>
                  </ul>
                  <Link
                    href="/investment/starter"
                    className="block w-full bg-green-600 text-white text-center py-2 rounded hover:bg-green-700 transition-colors"
                  >
                    বিনিয়োগ করুন
                  </Link>
                </div>
              </div>

              <div className="bg-white rounded-lg shadow-lg overflow-hidden transform scale-105 z-10 border-2 border-green-500">
                <div className="bg-green-700 text-white p-4 text-center relative">
                  <div className="absolute top-0 right-0 bg-yellow-500 text-xs font-bold px-2 py-1 transform translate-x-2 -translate-y-1 rotate-12">
                    সেরা মূল্য
                  </div>
                  <h3 className="text-xl font-bold">প্রিমিয়াম প্যাকেজ</h3>
                </div>
                <div className="p-6">
                  <div className="text-center mb-6">
                    <span className="text-4xl font-bold">৳২৫,০০,০০০</span>
                    <span className="text-gray-600 block mt-1">ন্যূনতম বিনিয়োগ</span>
                  </div>
                  <ul className="space-y-3 mb-6">
                    <li className="flex items-center">
                      <svg
                        className="h-5 w-5 text-green-500 mr-2"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                      </svg>
                      <span>বার্ষিক ১৮% লাভাংশ</span>
                    </li>
                    <li className="flex items-center">
                      <svg
                        className="h-5 w-5 text-green-500 mr-2"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                      </svg>
                      <span>মাসিক লাভাংশ প্রদান</span>
                    </li>
                    <li className="flex items-center">
                      <svg
                        className="h-5 w-5 text-green-500 mr-2"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                      </svg>
                      <span>৩ বছর মেয়াদ</span>
                    </li>
                    <li className="flex items-center">
                      <svg
                        className="h-5 w-5 text-green-500 mr-2"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                      </svg>
                      <span>হজ্জ ও উমরাহ প্যাকেজে ১০% ছাড়</span>
                    </li>
                    <li className="flex items-center">
                      <svg
                        className="h-5 w-5 text-green-500 mr-2"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                      </svg>
                      <span>বার্ষিক বিনিয়োগকারী সম্মেলনে অংশগ্রহণ</span>
                    </li>
                  </ul>
                  <Link
                    href="/investment/premium"
                    className="block w-full bg-green-700 text-white text-center py-2 rounded hover:bg-green-800 transition-colors"
                  >
                    বিনিয়োগ করুন
                  </Link>
                </div>
              </div>

              <div className="bg-white rounded-lg shadow-lg overflow-hidden">
                <div className="bg-green-600 text-white p-4 text-center">
                  <h3 className="text-xl font-bold">এন্টারপ্রাইজ প্যাকেজ</h3>
                </div>
                <div className="p-6">
                  <div className="text-center mb-6">
                    <span className="text-4xl font-bold">৳১,০০,০০,০০০</span>
                    <span className="text-gray-600 block mt-1">ন্যূনতম বিনিয়োগ</span>
                  </div>
                  <ul className="space-y-3 mb-6">
                    <li className="flex items-center">
                      <svg
                        className="h-5 w-5 text-green-500 mr-2"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                      </svg>
                      <span>বার্ষিক ২০% লাভাংশ</span>
                    </li>
                    <li className="flex items-center">
                      <svg
                        className="h-5 w-5 text-green-500 mr-2"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                      </svg>
                      <span>মাসিক লাভাংশ প্রদান</span>
                    </li>
                    <li className="flex items-center">
                      <svg
                        className="h-5 w-5 text-green-500 mr-2"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                      </svg>
                      <span>৫ বছর মেয়াদ</span>
                    </li>
                    <li className="flex items-center">
                      <svg
                        className="h-5 w-5 text-green-500 mr-2"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                      </svg>
                      <span>হজ্জ ও উমরাহ প্যাকেজে ১৫% ছাড়</span>
                    </li>
                    <li className="flex items-center">
                      <svg
                        className="h-5 w-5 text-green-500 mr-2"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                      </svg>
                      <span>বোর্ড মিটিংয়ে অংশগ্রহণের সুযোগ</span>
                    </li>
                  </ul>
                  <Link
                    href="/investment/enterprise"
                    className="block w-full bg-green-600 text-white text-center py-2 rounded hover:bg-green-700 transition-colors"
                  >
                    বিনিয়োগ করুন
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Company Strengths Section */}
        <section className="py-16 bg-white">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-gray-800 mb-4">আমাদের শক্তি</h2>
              <p className="text-lg text-gray-600 max-w-3xl mx-auto">
                T-Ally Umrah Sr. বাংলাদেশের অন্যতম শীর্ষস্থানীয় হজ্জ ও উমরাহ সেবা প্রদানকারী প্রতিষ্ঠান। আমাদের শক্তিশালী দিকগুলো:
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-12 max-w-5xl mx-auto">
              <div>
                <div className="mb-8">
                  <h3 className="text-xl font-bold mb-3 flex items-center">
                    <svg className="h-6 w-6 text-green-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth="2"
                        d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"
                      />
                    </svg>
                    অভিজ্ঞ ব্যবস্থাপনা টিম
                  </h3>
                  <p className="text-gray-600 ml-8">
                    আমাদের ব্যবস্থাপনা টিম ১০+ বছরের অভিজ্ঞতা সম্পন্ন, যারা হজ্জ ও উমরাহ সেবা খাতে বিশেষজ্ঞ।
                  </p>
                </div>

                <div className="mb-8">
                  <h3 className="text-xl font-bold mb-3 flex items-center">
                    <svg className="h-6 w-6 text-green-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth="2"
                        d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"
                      />
                    </svg>
                    ৫০,০০০+ সন্তুষ্ট গ্রাহক
                  </h3>
                  <p className="text-gray-600 ml-8">আমরা এখন পর্যন্ত ৫০,০০০+ যাত্রীকে সফলভাবে হজ্জ ও উমরাহ পালনে সহায়তা করেছি।</p>
                </div>

                <div className="mb-8">
                  <h3 className="text-xl font-bold mb-3 flex items-center">
                    <svg className="h-6 w-6 text-green-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth="2"
                        d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"
                      />
                    </svg>
                    সরকারি অনুমোদন
                  </h3>
                  <p className="text-gray-600 ml-8">আমরা বাংলাদেশ সরকার ও সৌদি আরব সরকার কর্তৃক অনুমোদিত হজ্জ ও উমরাহ এজেন্সি।</p>
                </div>
              </div>

              <div>
                <div className="mb-8">
                  <h3 className="text-xl font-bold mb-3 flex items-center">
                    <svg className="h-6 w-6 text-green-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth="2"
                        d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"
                      />
                    </svg>
                    ক্রমবর্ধমান বাজার শেয়ার
                  </h3>
                  <p className="text-gray-600 ml-8">
                    বাংলাদেশের হজ্জ ও উমরাহ সেবা বাজারে আমাদের ১৫% বাজার শেয়ার রয়েছে, যা প্রতিবছর বৃদ্ধি পাচ্ছে।
                  </p>
                </div>

                <div className="mb-8">
                  <h3 className="text-xl font-bold mb-3 flex items-center">
                    <svg className="h-6 w-6 text-green-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth="2"
                        d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"
                      />
                    </svg>
                    প্রিমিয়াম অবকাঠামো
                  </h3>
                  <p className="text-gray-600 ml-8">
                    মক্কা ও মদিনায় আমাদের নিজস্ব হোটেল ও পরিবহন ব্যবস্থা রয়েছে, যা আমাদের খরচ কমাতে সাহায্য করে।
                  </p>
                </div>

                <div className="mb-8">
                  <h3 className="text-xl font-bold mb-3 flex items-center">
                    <svg className="h-6 w-6 text-green-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth="2"
                        d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                      />
                    </svg>
                    স্থিতিশীল আর্থিক অবস্থা
                  </h3>
                  <p className="text-gray-600 ml-8">
                    গত ৫ বছরে আমাদের বার্ষিক আয় ২০% হারে বৃদ্ধি পেয়েছে, যা আমাদের আর্থিক স্থিতিশীলতা প্রমাণ করে।
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Investment Policy Section */}
        <section className="py-16 bg-gray-50">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-gray-800 mb-4">বিনিয়োগ নীতিমালা</h2>
              <p className="text-lg text-gray-600 max-w-3xl mx-auto">
                আমাদের বিনিয়োগ নীতিমালা স্বচ্ছতা ও নিরাপত্তা নিশ্চিত করে। নিম্নে আমাদের প্রধান নীতিমালাগুলো দেওয়া হলো:
              </p>
            </div>

            <div className="max-w-4xl mx-auto bg-white rounded-lg shadow-lg p-8">
              <div className="space-y-6">
                <div>
                  <h3 className="text-xl font-bold mb-2">১. বিনিয়োগের মেয়াদ</h3>
                  <p className="text-gray-600">
                    বিনিয়োগের ন্যূনতম মেয়াদ ১ বছর। মেয়াদ শেষে বিনিয়োগকারী তার মূলধন ফেরত নিতে পারবেন অথবা পুনরায় বিনিয়োগ করতে
                    পারবেন।
                  </p>
                </div>

                <div>
                  <h3 className="text-xl font-bold mb-2">২. লাভাংশ প্রদান</h3>
                  <p className="text-gray-600">
                    প্যাকেজ অনুযায়ী লাভাংশ মাসিক, ত্রৈমাসিক বা বার্ষিক ভিত্তিতে প্রদান করা হবে। লাভাংশ সরাসরি বিনিয়োগকারীর ব্যাংক অ্যাকাউন্টে পাঠানো
                    হবে।
                  </p>
                </div>

                <div>
                  <h3 className="text-xl font-bold mb-2">৩. বিনিয়োগ প্রত্যাহার</h3>
                  <p className="text-gray-600">
                    মেয়াদ শেষের আগে বিনিয়োগ প্রত্যাহার করতে চাইলে ৩০ দিন আগে নোটিশ দিতে হবে। এক্ষেত্রে ৫% প্রত্যাহার ফি প্রযোজ্য হবে।
                  </p>
                </div>

                <div>
                  <h3 className="text-xl font-bold mb-2">৪. লাভ-ক্ষতির ঝুঁকি</h3>
                  <p className="text-gray-600">
                    যদিও আমরা সর্বোচ্চ লাভ নিশ্চিত করার চেষ্টা করি, তবে বাজার পরিস্থিতি অনুযায়ী লাভের হার কম-বেশি হতে পারে। আমরা ন্যূনতম
                    লাভের গ্যারান্টি দিয়ে থাকি।
                  </p>
                </div>

                <div>
                  <h3 className="text-xl font-bold mb-2">৫. আইনি বিষয়াবলী</h3>
                  <p className="text-gray-600">
                    সকল বিনিয়োগ বাংলাদেশের আইন অনুযায়ী পরিচালিত হবে। বিনিয়োগকারী ও কোম্পানির মধ্যে একটি আইনি চুক্তি সম্পাদিত হবে।
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Testimonials Section */}
        <section className="py-16 bg-white">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-gray-800 mb-4">বিনিয়োগকারীদের মতামত</h2>
              <p className="text-lg text-gray-600 max-w-3xl mx-auto">
                আমাদের বিনিয়োগকারীরা কী বলেন তা দেখুন। তাদের অভিজ্ঞতা আপনাকে সঠিক সিদ্ধান্ত নিতে সাহায্য করবে।
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
              <div className="bg-gray-50 p-6 rounded-lg shadow">
                <div className="flex items-center mb-4">
                  <div className="h-12 w-12 rounded-full bg-gray-300 mr-4"></div>
                  <div>
                    <h4 className="font-bold">আব্দুল করিম</h4>
                    <p className="text-sm text-gray-600">ঢাকা, বাংলাদেশ</p>
                  </div>
                </div>
                <p className="text-gray-600 italic">
                  "আমি ২ বছর আগে T-Ally Umrah Sr. এ বিনিয়োগ করেছি এবং নিয়মিত লাভাংশ পাচ্ছি। তাদের পেশাদারিত্ব ও স্বচ্ছতা আমাকে মুগ্ধ
                  করেছে।"
                </p>
              </div>

              <div className="bg-gray-50 p-6 rounded-lg shadow">
                <div className="flex items-center mb-4">
                  <div className="h-12 w-12 rounded-full bg-gray-300 mr-4"></div>
                  <div>
                    <h4 className="font-bold">ফারহানা আহমেদ</h4>
                    <p className="text-sm text-gray-600">চট্টগ্রাম, বাংলাদেশ</p>
                  </div>
                </div>
                <p className="text-gray-600 italic">
                  "প্রিমিয়াম প্যাকেজে বিনিয়োগ করে আমি মাসিক ভিত্তিতে লাভাংশ পাচ্ছি। এছাড়া আমার পরিবার উমরাহ প্যাকেজে বিশেষ ছাড় পেয়েছে।"
                </p>
              </div>

              <div className="bg-gray-50 p-6 rounded-lg shadow">
                <div className="flex items-center mb-4">
                  <div className="h-12 w-12 rounded-full bg-gray-300 mr-4"></div>
                  <div>
                    <h4 className="font-bold">মোহাম্মদ রফিক</h4>
                    <p className="text-sm text-gray-600">সিলেট, বাংলাদেশ</p>
                  </div>
                </div>
                <p className="text-gray-600 italic">
                  "৩ বছর ধরে এন্টারপ্রাইজ প্যাকেজে বিনিয়োগ করে আমি ২০% বার্ষিক লাভ পাচ্ছি। এটি আমার অন্যান্য বিনিয়োগের তুলনায় অনেক বেশি
                  লাভজনক।"
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Contact Form Section */}
        <section className="py-16 bg-gray-50">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto bg-white rounded-lg shadow-lg overflow-hidden">
              <div className="md:flex">
                <div className="md:w-1/2 bg-green-600 text-white p-8">
                  <h2 className="text-3xl font-bold mb-4">আজই বিনিয়োগ করুন</h2>
                  <p className="mb-6">
                    আমাদের বিনিয়োগ সম্পর্কে আরও জানতে বা বিনিয়োগ করতে আগ্রহী হলে আমাদের সাথে যোগাযোগ করুন। আমাদের বিশেষজ্ঞ টিম আপনাকে
                    সাহায্য করবে।
                  </p>
                  <div className="space-y-4">
                    <div className="flex items-center">
                      <svg className="h-6 w-6 mr-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth="2"
                          d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"
                        />
                      </svg>
                      <span>+880 1892051303</span>
                    </div>
                    <div className="flex items-center">
                      <svg className="h-6 w-6 mr-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth="2"
                          d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"
                        />
                      </svg>
                      <span>investment@t-ally-umrah.com</span>
                    </div>
                    <div className="flex items-center">
                      <svg className="h-6 w-6 mr-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth="2"
                          d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"
                        />
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth="2"
                          d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"
                        />
                      </svg>
                      <span>121 Islamic Center, Ally Street, UK</span>
                    </div>
                  </div>
                </div>
                <div className="md:w-1/2 p-8">
                  <h3 className="text-2xl font-bold mb-6">আমাদের সাথে যোগাযোগ করুন</h3>
                  <form className="space-y-4">
                    <div>
                      <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                        আপনার নাম
                      </label>
                      <input
                        type="text"
                        id="name"
                        className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent"
                      />
                    </div>
                    <div>
                      <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                        ইমেইল
                      </label>
                      <input
                        type="email"
                        id="email"
                        className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent"
                      />
                    </div>
                    <div>
                      <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-1">
                        ফোন নম্বর
                      </label>
                      <input
                        type="tel"
                        id="phone"
                        className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent"
                      />
                    </div>
                    <div>
                      <label htmlFor="investment" className="block text-sm font-medium text-gray-700 mb-1">
                        বিনিয়োগের পরিমাণ (টাকা)
                      </label>
                      <input
                        type="number"
                        id="investment"
                        className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent"
                      />
                    </div>
                    <div>
                      <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-1">
                        বার্তা
                      </label>
                      <textarea
                        id="message"
                        rows={4}
                        className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent"
                      ></textarea>
                    </div>
                    <button
                      type="submit"
                      className="w-full bg-green-600 text-white py-2 rounded-md hover:bg-green-700 transition-colors"
                    >
                      পাঠান
                    </button>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* FAQ Section */}
        <section className="py-16 bg-white">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-gray-800 mb-4">সাধারণ জিজ্ঞাসা</h2>
              <p className="text-lg text-gray-600 max-w-3xl mx-auto">
                বিনিয়োগ সম্পর্কে আপনার যেকোনো প্রশ্নের উত্তর এখানে পাবেন।
              </p>
            </div>

            <div className="max-w-4xl mx-auto space-y-6">
              <div className="bg-gray-50 rounded-lg p-6 shadow">
                <h3 className="text-xl font-bold mb-2">ন্যূনতম বিনিয়োগের পরিমাণ কত?</h3>
                <p className="text-gray-600">
                  আমাদের স্টার্টার প্যাকেজে ন্যূনতম বিনিয়োগের পরিমাণ ৫ লাখ টাকা। তবে আপনি আপনার সামর্থ্য অনুযায়ী প্রিমিয়াম বা এন্টারপ্রাইজ প্যাকেজেও
                  বিনিয়োগ করতে পারেন।
                </p>
              </div>

              <div className="bg-gray-50 rounded-lg p-6 shadow">
                <h3 className="text-xl font-bold mb-2">লাভাংশ কীভাবে প্রদান করা হয়?</h3>
                <p className="text-gray-600">
                  আপনার বিনিয়োগ প্যাকেজ অনুযায়ী লাভাংশ মাসিক, ত্রৈমাসিক বা বার্ষিক ভিত্তিতে আপনার ব্যাংক অ্যাকাউন্টে সরাসরি পাঠানো হবে।
                </p>
              </div>

              <div className="bg-gray-50 rounded-lg p-6 shadow">
                <h3 className="text-xl font-bold mb-2">বিনিয়োগের মেয়াদ শেষে কী হবে?</h3>
                <p className="text-gray-600">
                  মেয়াদ শেষে আপনি আপনার মূলধন সম্পূর্ণ ফেরত পাবেন। আপনি চাইলে পুনরায় বিনিয়োগ করতে পারেন অথবা আপনার মূলধন উত্তোলন করতে
                  পারেন।
                </p>
              </div>

              <div className="bg-gray-50 rounded-lg p-6 shadow">
                <h3 className="text-xl font-bold mb-2">বিনিয়োগের ঝুঁকি কী?</h3>
                <p className="text-gray-600">
                  যেকোনো বিনিয়োগেই কিছু ঝুঁকি থাকে। তবে আমরা আমাদের বিনিয়োগকারীদের জন্য ন্যূনতম লাভের গ্যারান্টি দিয়ে থাকি। আমাদের দীর্ঘ
                  অভিজ্ঞতা ও শক্তিশালী বাজার অবস্থান আপনার বিনিয়োগকে নিরাপদ রাখে।
                </p>
              </div>

              <div className="bg-gray-50 rounded-lg p-6 shadow">
                <h3 className="text-xl font-bold mb-2">বিনিয়োগ করতে কী কী ডকুমেন্ট প্রয়োজন?</h3>
                <p className="text-gray-600">
                  বিনিয়োগ করতে আপনার জাতীয় পরিচয়পত্র, পাসপোর্ট সাইজের ছবি, ব্যাংক স্টেটমেন্ট এবং TIN সার্টিফিকেট (যদি থাকে) প্রয়োজন
                  হবে।
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-16 bg-green-600 text-white">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">আজই বিনিয়োগ শুরু করুন</h2>
            <p className="text-xl mb-8 max-w-3xl mx-auto">
              T-Ally Umrah Sr. এর সাথে বিনিয়োগ করে উচ্চ লাভ অর্জন করুন এবং হজ্জ ও উমরাহ সেবা খাতে অবদান রাখুন।
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <Link
                href="/investment/apply"
                className="bg-white text-green-600 px-8 py-3 rounded-md font-medium hover:bg-gray-100 transition-colors"
              >
                বিনিয়োগ প্যাকেজ দেখুন
              </Link>
              <Link
                href="/contact"
                className="bg-transparent border-2 border-white text-white px-8 py-3 rounded-md font-medium hover:bg-white hover:text-green-600 transition-colors"
              >
                যোগাযোগ করুন
              </Link>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}

