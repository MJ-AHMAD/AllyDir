import Image from "next/image"
import Link from "next/link"
import { Footer } from "@/components/footer"

export default function PremiumInvestmentPage() {
  return (
    <div className="min-h-screen flex flex-col">
      <header className="bg-green-600 text-white py-4">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center gap-2">
              <Image
                src="/placeholder.svg?height=40&width=40"
                alt="TRUSTED-ALLY Logo"
                width={40}
                height={40}
                className="h-10 w-auto"
              />
              <span className="font-bold text-xl">T-Ally Umrah Sr.</span>
            </Link>
            <nav className="hidden md:flex space-x-6">
              <Link href="/" className="hover:text-green-200 transition-colors">
                Home
              </Link>
              <Link href="/packages" className="hover:text-green-200 transition-colors">
                Packages
              </Link>
              <Link href="/services" className="hover:text-green-200 transition-colors">
                Services
              </Link>
              <Link href="/investment" className="hover:text-green-200 transition-colors">
                Investment
              </Link>
              <Link href="/contact" className="hover:text-green-200 transition-colors">
                Contact
              </Link>
            </nav>
          </div>
        </div>
      </header>

      <main className="flex-grow">
        <section className="py-12 bg-gray-50">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto">
              <div className="bg-white rounded-lg shadow-lg overflow-hidden">
                <div className="bg-green-700 text-white p-6 text-center">
                  <div className="absolute top-4 right-4 bg-yellow-500 text-xs font-bold px-2 py-1 rounded-full">
                    সেরা মূল্য
                  </div>
                  <h1 className="text-3xl font-bold">প্রিমিয়াম বিনিয়োগ প্যাকেজ</h1>
                  <p className="text-xl mt-2">উচ্চ লাভের সুযোগ</p>
                </div>

                <div className="p-8">
                  <div className="text-center mb-8">
                    <span className="text-5xl font-bold text-green-600">৳২৫,০০,০০০</span>
                    <span className="text-gray-600 block mt-2">ন্যূনতম বিনিয়োগ</span>
                  </div>

                  <div className="space-y-6 mb-8">
                    <h2 className="text-2xl font-bold text-gray-800">প্যাকেজের বিবরণ</h2>
                    <p className="text-gray-600">
                      আমাদের প্রিমিয়াম বিনিয়োগ প্যাকেজ মাঝারি আকারের বিনিয়োগকারীদের জন্য একটি আদর্শ সুযোগ। এই প্যাকেজের মাধ্যমে আপনি হজ্জ
                      ও উমরাহ সেবা খাতে বিনিয়োগ করে আকর্ষণীয় লাভ অর্জন করতে পারবেন। এই প্যাকেজে বিনিয়োগ করে আপনি বার্ষিক ১৮% লাভাংশ
                      পাবেন, যা মাসিক ভিত্তিতে প্রদান করা হবে।
                    </p>

                    <h2 className="text-2xl font-bold text-gray-800">সুবিধাসমূহ</h2>
                    <ul className="space-y-3">
                      <li className="flex items-center">
                        <svg
                          className="h-5 w-5 text-green-500 mr-2"
                          fill="none"
                          viewBox="0 0 24 24"
                          stroke="currentColor"
                        >
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                        </svg>
                        <span>বার্ষিক ১৮% লাভাংশ</span>
                      </li>
                      <li className="flex items-center">
                        <svg
                          className="h-5 w-5 text-green-500 mr-2"
                          fill="none"
                          viewBox="0 0 24 24"
                          stroke="currentColor"
                        >
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                        </svg>
                        <span>মাসিক লাভাংশ প্রদান</span>
                      </li>
                      <li className="flex items-center">
                        <svg
                          className="h-5 w-5 text-green-500 mr-2"
                          fill="none"
                          viewBox="0 0 24 24"
                          stroke="currentColor"
                        >
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                        </svg>
                        <span>৩ বছর মেয়াদ</span>
                      </li>
                      <li className="flex items-center">
                        <svg
                          className="h-5 w-5 text-green-500 mr-2"
                          fill="none"
                          viewBox="0 0 24 24"
                          stroke="currentColor"
                        >
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                        </svg>
                        <span>হজ্জ ও উমরাহ প্যাকেজে ১০% ছাড়</span>
                      </li>
                      <li className="flex items-center">
                        <svg
                          className="h-5 w-5 text-green-500 mr-2"
                          fill="none"
                          viewBox="0 0 24 24"
                          stroke="currentColor"
                        >
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                        </svg>
                        <span>বার্ষিক বিনিয়োগকারী সম্মেলনে অংশগ্রহণ</span>
                      </li>
                      <li className="flex items-center">
                        <svg
                          className="h-5 w-5 text-green-500 mr-2"
                          fill="none"
                          viewBox="0 0 24 24"
                          stroke="currentColor"
                        >
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                        </svg>
                        <span>মেয়াদ শেষে মূলধন ফেরত</span>
                      </li>
                      <li className="flex items-center">
                        <svg
                          className="h-5 w-5 text-green-500 mr-2"
                          fill="none"
                          viewBox="0 0 24 24"
                          stroke="currentColor"
                        >
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                        </svg>
                        <span>পুনরায় বিনিয়োগের সুযোগ</span>
                      </li>
                    </ul>
                  </div>

                  <div className="space-y-6 mb-8">
                    <h2 className="text-2xl font-bold text-gray-800">যোগ্যতা</h2>
                    <ul className="space-y-3">
                      <li className="flex items-center">
                        <svg
                          className="h-5 w-5 text-green-500 mr-2"
                          fill="none"
                          viewBox="0 0 24 24"
                          stroke="currentColor"
                        >
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                        </svg>
                        <span>বাংলাদেশী নাগরিক</span>
                      </li>
                      <li className="flex items-center">
                        <svg
                          className="h-5 w-5 text-green-500 mr-2"
                          fill="none"
                          viewBox="0 0 24 24"
                          stroke="currentColor"
                        >
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                        </svg>
                        <span>ন্যূনতম বয়স ১৮ বছর</span>
                      </li>
                      <li className="flex items-center">
                        <svg
                          className="h-5 w-5 text-green-500 mr-2"
                          fill="none"
                          viewBox="0 0 24 24"
                          stroke="currentColor"
                        >
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                        </svg>
                        <span>বৈধ জাতীয় পরিচয়পত্র</span>
                      </li>
                      <li className="flex items-center">
                        <svg
                          className="h-5 w-5 text-green-500 mr-2"
                          fill="none"
                          viewBox="0 0 24 24"
                          stroke="currentColor"
                        >
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                        </svg>
                        <span>TIN সার্টিফিকেট (যদি থাকে)</span>
                      </li>
                    </ul>
                  </div>

                  <div className="text-center">
                    <Link
                      href="/investment/apply"
                      className="inline-block bg-green-700 text-white px-8 py-3 rounded-md font-medium hover:bg-green-800 transition-colors"
                    >
                      আবেদন করুন
                    </Link>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="py-12 bg-white">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto text-center">
              <h2 className="text-2xl font-bold text-gray-800 mb-6">আরও জানতে চান?</h2>
              <p className="text-gray-600 mb-8">
                আমাদের বিনিয়োগ প্যাকেজ সম্পর্কে আরও জানতে বা আপনার প্রশ্নের উত্তর পেতে আমাদের সাথে যোগাযোগ করুন।
              </p>
              <div className="flex flex-col sm:flex-row justify-center gap-4">
                <Link
                  href="/investment"
                  className="bg-gray-200 text-gray-800 px-6 py-3 rounded-md font-medium hover:bg-gray-300 transition-colors"
                >
                  সকল প্যাকেজ দেখুন
                </Link>
                <Link
                  href="/contact"
                  className="bg-green-600 text-white px-6 py-3 rounded-md font-medium hover:bg-green-700 transition-colors"
                >
                  যোগাযোগ করুন
                </Link>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}

