"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { useRouter } from "next/navigation"
import {
  ArrowLeft,
  User,
  Mail,
  Phone,
  MapPin,
  Calendar,
  Briefcase,
  Edit,
  Save,
  X,
  Camera,
  LogOut,
  Settings,
  Bell,
  ChevronDown,
  Shield,
  Key,
  FileText,
} from "lucide-react"

export default function DirectorGeneralProfilePage() {
  const [isEditing, setIsEditing] = useState(false)
  const [isDropdownOpen, setIsDropdownOpen] = useState(false)
  const [notificationsOpen, setNotificationsOpen] = useState(false)
  const router = useRouter()

  // Profile data state
  const [profile, setProfile] = useState({
    name: "মোঃ আনিসুর রহমান",
    email: "anisur.rahman@trusted-ally.com",
    phone: "+880 1712-345678",
    address: "১২৩/এ, গুলশান এভিনিউ, ঢাকা-১২১২",
    dateOfBirth: "১৫ জানুয়ারি, ১৯৭৫",
    position: "মহাপরিচালক",
    department: "প্রশাসন",
    joinDate: "১০ মার্চ, ২০১৫",
    education: "এমবিএ (ফাইন্যান্স), ঢাকা বিশ্ববিদ্যালয়",
    bio: "১০+ বছরের অভিজ্ঞতা সম্পন্ন একজন দক্ষ প্রশাসক। বিভিন্ন আন্তর্জাতিক প্রতিষ্ঠানে কাজ করার অভিজ্ঞতা রয়েছে। ট্রাস্টেড অ্যালাই-এর সকল প্রকল্পের সামগ্রিক তত্ত্বাবধান ও পরিচালনার দায়িত্বে নিয়োজিত।",
  })

  // Handle form submission
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setIsEditing(false)
    // Here you would typically save the data to a backend
  }

  // Handle logout function
  const handleLogout = () => {
    router.push("/admin/login")
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-30">
        <div className="flex items-center justify-between p-4">
          <div className="flex items-center">
            <div className="flex items-center mr-10">
              <Image
                src="https://mj-ahmad.github.io/mja2025/img/icon.png"
                alt="T-ALLY Logo"
                width={40}
                height={40}
                className="mr-3"
              />
              <h1 className="text-xl font-bold text-green-600">TRUSTED-ALLY</h1>
            </div>
          </div>

          <div className="flex items-center space-x-5">
            {/* Notifications */}
            <div className="relative">
              <button
                className="p-1.5 rounded-full bg-gray-100 hover:bg-gray-200 relative"
                onClick={() => setNotificationsOpen(!notificationsOpen)}
              >
                <Bell className="h-5 w-5 text-gray-700" />
                <span className="absolute top-0 right-0 h-2 w-2 rounded-full bg-red-500"></span>
              </button>
            </div>

            {/* Settings button */}
            <button className="p-1.5 rounded-full bg-gray-100 hover:bg-gray-200">
              <Settings className="h-5 w-5 text-gray-700" />
            </button>

            {/* User profile */}
            <div className="relative">
              <button className="flex items-center space-x-3" onClick={() => setIsDropdownOpen(!isDropdownOpen)}>
                <div className="h-9 w-9 rounded-full bg-green-500 flex items-center justify-center text-white text-lg font-medium">
                  ম
                </div>
                <div className="hidden md:block text-right">
                  <div className="font-medium">{profile.name}</div>
                  <div className="text-xs text-gray-500">{profile.position}</div>
                </div>
                <ChevronDown
                  className={`h-4 w-4 text-gray-500 transition-transform duration-200 
                  ${isDropdownOpen ? "transform rotate-180" : ""}`}
                />
              </button>

              {/* Profile dropdown */}
              {isDropdownOpen && (
                <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg py-2 z-50 border border-gray-200">
                  <Link
                    href="/admin/director-general/profile"
                    className="block px-4 py-2 text-gray-700 hover:bg-gray-100"
                  >
                    প্রোফাইল
                  </Link>
                  <Link
                    href="/admin/director-general/settings"
                    className="block px-4 py-2 text-gray-700 hover:bg-gray-100"
                  >
                    সেটিংস
                  </Link>
                  <hr className="my-1 border-gray-200" />
                  <button
                    onClick={handleLogout}
                    className="flex w-full items-center px-4 py-2 text-red-600 hover:bg-gray-100"
                  >
                    <LogOut className="h-4 w-4 mr-2" />
                    লগআউট
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6">
        {/* Navigation */}
        <div className="flex items-center mb-6">
          <Link href="/admin/director-general" className="flex items-center text-gray-500 hover:text-gray-700">
            <ArrowLeft className="h-5 w-5 mr-2" />
            ড্যাশবোর্ডে ফিরে যান
          </Link>
        </div>

        {/* Profile Header */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <div className="flex flex-col md:flex-row items-center md:items-start gap-6">
            <div className="relative">
              <div className="h-32 w-32 rounded-full bg-green-100 flex items-center justify-center overflow-hidden border-4 border-white shadow-md">
                <Image
                  src="/placeholder.svg?height=128&width=128"
                  alt={profile.name}
                  width={128}
                  height={128}
                  className="object-cover"
                />
              </div>
              {isEditing && (
                <button className="absolute bottom-0 right-0 bg-green-500 text-white p-2 rounded-full shadow-md hover:bg-green-600">
                  <Camera className="h-5 w-5" />
                </button>
              )}
            </div>
            <div className="flex-1 text-center md:text-left">
              <h1 className="text-2xl font-bold">{profile.name}</h1>
              <p className="text-gray-600 mt-1">{profile.position}</p>
              <p className="text-gray-500 mt-1">{profile.department}</p>
              <div className="mt-4 flex flex-wrap justify-center md:justify-start gap-3">
                {!isEditing ? (
                  <button
                    onClick={() => setIsEditing(true)}
                    className="flex items-center space-x-1 bg-green-100 hover:bg-green-200 text-green-700 px-4 py-2 rounded-lg text-sm font-medium"
                  >
                    <Edit className="h-4 w-4 mr-1" />
                    <span>প্রোফাইল সম্পাদনা</span>
                  </button>
                ) : (
                  <>
                    <button
                      onClick={handleSubmit}
                      className="flex items-center space-x-1 bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg text-sm font-medium"
                    >
                      <Save className="h-4 w-4 mr-1" />
                      <span>সংরক্ষণ করুন</span>
                    </button>
                    <button
                      onClick={() => setIsEditing(false)}
                      className="flex items-center space-x-1 bg-gray-100 hover:bg-gray-200 text-gray-700 px-4 py-2 rounded-lg text-sm font-medium"
                    >
                      <X className="h-4 w-4 mr-1" />
                      <span>বাতিল করুন</span>
                    </button>
                  </>
                )}
                <Link
                  href="/admin/director-general/settings"
                  className="flex items-center space-x-1 bg-gray-100 hover:bg-gray-200 text-gray-700 px-4 py-2 rounded-lg text-sm font-medium"
                >
                  <Settings className="h-4 w-4 mr-1" />
                  <span>সেটিংস</span>
                </Link>
              </div>
            </div>
          </div>
        </div>

        {/* Profile Content */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Personal Information */}
          <div className="bg-white rounded-lg shadow-sm p-6 md:col-span-2">
            <h2 className="text-lg font-semibold mb-4">ব্যক্তিগত তথ্য</h2>
            <form onSubmit={handleSubmit}>
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">নাম</label>
                    {isEditing ? (
                      <input
                        type="text"
                        value={profile.name}
                        onChange={(e) => setProfile({ ...profile, name: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-green-500 focus:border-green-500"
                      />
                    ) : (
                      <div className="flex items-start">
                        <User className="h-5 w-5 text-gray-400 mt-0.5 mr-2" />
                        <span>{profile.name}</span>
                      </div>
                    )}
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">ইমেইল</label>
                    {isEditing ? (
                      <input
                        type="email"
                        value={profile.email}
                        onChange={(e) => setProfile({ ...profile, email: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-green-500 focus:border-green-500"
                      />
                    ) : (
                      <div className="flex items-start">
                        <Mail className="h-5 w-5 text-gray-400 mt-0.5 mr-2" />
                        <span>{profile.email}</span>
                      </div>
                    )}
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">ফোন নম্বর</label>
                    {isEditing ? (
                      <input
                        type="text"
                        value={profile.phone}
                        onChange={(e) => setProfile({ ...profile, phone: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-green-500 focus:border-green-500"
                      />
                    ) : (
                      <div className="flex items-start">
                        <Phone className="h-5 w-5 text-gray-400 mt-0.5 mr-2" />
                        <span>{profile.phone}</span>
                      </div>
                    )}
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">ঠিকানা</label>
                    {isEditing ? (
                      <input
                        type="text"
                        value={profile.address}
                        onChange={(e) => setProfile({ ...profile, address: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-green-500 focus:border-green-500"
                      />
                    ) : (
                      <div className="flex items-start">
                        <MapPin className="h-5 w-5 text-gray-400 mt-0.5 mr-2" />
                        <span>{profile.address}</span>
                      </div>
                    )}
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">জন্ম তারিখ</label>
                    {isEditing ? (
                      <input
                        type="text"
                        value={profile.dateOfBirth}
                        onChange={(e) => setProfile({ ...profile, dateOfBirth: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-green-500 focus:border-green-500"
                      />
                    ) : (
                      <div className="flex items-start">
                        <Calendar className="h-5 w-5 text-gray-400 mt-0.5 mr-2" />
                        <span>{profile.dateOfBirth}</span>
                      </div>
                    )}
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">শিক্ষাগত যোগ্যতা</label>
                    {isEditing ? (
                      <input
                        type="text"
                        value={profile.education}
                        onChange={(e) => setProfile({ ...profile, education: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-green-500 focus:border-green-500"
                      />
                    ) : (
                      <div className="flex items-start">
                        <FileText className="h-5 w-5 text-gray-400 mt-0.5 mr-2" />
                        <span>{profile.education}</span>
                      </div>
                    )}
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">বায়োডাটা</label>
                  {isEditing ? (
                    <textarea
                      value={profile.bio}
                      onChange={(e) => setProfile({ ...profile, bio: e.target.value })}
                      rows={4}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-green-500 focus:border-green-500"
                    />
                  ) : (
                    <p className="text-gray-700">{profile.bio}</p>
                  )}
                </div>
              </div>
            </form>
          </div>

          {/* Professional Information & Security */}
          <div className="space-y-6">
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h2 className="text-lg font-semibold mb-4">পেশাগত তথ্য</h2>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">পদবি</label>
                  <div className="flex items-start">
                    <Briefcase className="h-5 w-5 text-gray-400 mt-0.5 mr-2" />
                    <span>{profile.position}</span>
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">বিভাগ</label>
                  <div className="flex items-start">
                    <Briefcase className="h-5 w-5 text-gray-400 mt-0.5 mr-2" />
                    <span>{profile.department}</span>
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">যোগদানের তারিখ</label>
                  <div className="flex items-start">
                    <Calendar className="h-5 w-5 text-gray-400 mt-0.5 mr-2" />
                    <span>{profile.joinDate}</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-lg shadow-sm p-6">
              <h2 className="text-lg font-semibold mb-4">সিকিউরিটি</h2>
              <div className="space-y-4">
                <div>
                  <Link
                    href="/admin/director-general/change-password"
                    className="flex items-center justify-between p-3 bg-gray-50 hover:bg-gray-100 rounded-lg"
                  >
                    <div className="flex items-center">
                      <Key className="h-5 w-5 text-gray-400 mr-3" />
                      <div>
                        <div className="font-medium">পাসওয়ার্ড পরিবর্তন করুন</div>
                        <div className="text-xs text-gray-500">আপনার অ্যাকাউন্টের নিরাপত্তা নিশ্চিত করুন</div>
                      </div>
                    </div>
                    <ChevronDown className="h-5 w-5 text-gray-400" />
                  </Link>
                </div>
                <div>
                  <Link
                    href="/admin/director-general/security-settings"
                    className="flex items-center justify-between p-3 bg-gray-50 hover:bg-gray-100 rounded-lg"
                  >
                    <div className="flex items-center">
                      <Shield className="h-5 w-5 text-gray-400 mr-3" />
                      <div>
                        <div className="font-medium">সিকিউরিটি সেটিংস</div>
                        <div className="text-xs text-gray-500">টু-ফ্যাক্টর অথেনটিকেশন এবং অন্যান্য সিকিউরিটি সেটিংস</div>
                      </div>
                    </div>
                    <ChevronDown className="h-5 w-5 text-gray-400" />
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}

