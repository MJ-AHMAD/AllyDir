"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { useParams, useRouter } from "next/navigation"
import {
  ArrowLeft,
  Clock,
  Download,
  Edit,
  ExternalLink,
  FileText,
  MessageSquare,
  MoreHorizontal,
  Users,
  ChevronDown,
  LogOut,
  Settings,
  Bell,
  Briefcase,
  CalendarDays,
  DollarSign,
  CheckCircle,
  AlertTriangle,
  XCircle,
} from "lucide-react"

// Sample project data
const projectsData = {
  "1": {
    id: 1,
    name: "স্ট্যান্ডার্ড উমরাহ প্যাকেজ",
    description:
      "বাংলাদেশী উমরাহ যাত্রীদের জন্য একটি সাশ্রয়ী এবং সম্পূর্ণ প্যাকেজ, যা স্টার ক্যাটাগরি হোটেল, ট্রান্সপোর্টেশন, ভিসা প্রসেসিং এবং অভিজ্ঞ গাইডের সুবিধা অন্তর্ভুক্ত।",
    status: "চলমান",
    category: "উমরাহ সার্ভিস",
    progress: 85,
    startDate: "১৫ জানুয়ারি, ২০২৫",
    endDate: "৩০ ডিসেম্বর, ২০২৫",
    budget: "৳ ২০,০০,০০০",
    spent: "৳ ১৭,০০,০০০",
    manager: "আবদুল করিম",
    teamSize: 8,
    lastUpdated: "১০ মে, ২০২৫, সকাল ১১:৩০",
    tasks: [
      {
        id: 101,
        title: "ভিসা প্রসেসিং",
        status: "সম্পন্ন",
        progress: 100,
        assignee: "মতিউর রহমান",
        dueDate: "১৫ মার্চ, ২০২৫",
      },
      {
        id: 102,
        title: "হোটেল বুকিং",
        status: "সম্পন্ন",
        progress: 100,
        assignee: "নাজমুল হাসান",
        dueDate: "২০ মার্চ, ২০২৫",
      },
      {
        id: 103,
        title: "ফ্লাইট বুকিং",
        status: "চলমান",
        progress: 75,
        assignee: "সাজেদা খাতুন",
        dueDate: "১৫ জুন, ২০২৫",
      },
      {
        id: 104,
        title: "লোকাল ট্রান্সপোর্টেশন",
        status: "চলমান",
        progress: 60,
        assignee: "কামাল হোসেন",
        dueDate: "২০ জুন, ২০২৫",
      },
      {
        id: 105,
        title: "গাইড নিয়োগ",
        status: "বাকি",
        progress: 30,
        assignee: "সায়মা আক্তার",
        dueDate: "১০ জুলাই, ২০২৫",
      },
    ],
    riskAssessment: [
      {
        id: 1,
        title: "সৌদি আরবে ভিসা পলিসি পরিবর্তন",
        impact: "উচ্চ",
        probability: "মাঝারি",
        mitigation: "নিয়মিত আপডেট পর্যবেক্ষণ এবং বিকল্প পরিকল্পনা প্রস্তুত করা",
        status: "মনিটরিং",
      },
      {
        id: 2,
        title: "ফ্লাইট কস্ট বৃদ্ধি",
        impact: "মাঝারি",
        probability: "উচ্চ",
        mitigation: "আগাম বুকিং এবং বিভিন্ন এয়ারলাইন্সের সাথে চুক্তি করা",
        status: "মিটিগেটেড",
      },
      {
        id: 3,
        title: "হোটেল অ্যাভেইলাবিলিটি",
        impact: "উচ্চ",
        probability: "নিম্ন",
        mitigation: "বিকল্প হোটেল সমূহের তালিকা তৈরি করা",
        status: "মনিটরিং",
      },
    ],
    updates: [
      {
        id: 1,
        date: "১০ মে, ২০২৫",
        author: "আবদুল করিম",
        content: "৩০ জন উমরাহ যাত্রী নিবন্ধন সম্পন্ন করেছেন। ভিসা প্রসেসিং চলছে।",
      },
      {
        id: 2,
        date: "০৫ মে, ২০২৫",
        author: "মতিউর রহমান",
        content: "মক্কা ও মদিনায় হোটেল বুকিং সম্পন্ন হয়েছে। সব যাত্রীদের জন্য রুম বরাদ্দ করা হয়েছে।",
      },
      {
        id: 3,
        date: "০১ মে, ২০২৫",
        author: "সাজেদা খাতুন",
        content: "ফ্লাইট বুকিং প্রক্রিয়া শুরু হয়েছে। সৌদি এয়ারলাইন্স, বিমান বাংলাদেশ এয়ারলাইন্স এবং ইতিহাদ এয়ারওয়েজের সাথে আলোচনা চলছে।",
      },
    ],
    files: [
      {
        id: 1,
        name: "বাজেট ব্রেকডাউন.xlsx",
        type: "Excel",
        size: "2.3 MB",
        updatedAt: "০৩ মে, ২০২৫",
      },
      {
        id: 2,
        name: "যাত্রী তালিকা.docx",
        type: "Word",
        size: "1.5 MB",
        updatedAt: "০৮ মে, ২০২৫",
      },
      {
        id: 3,
        name: "হোটেল বুকিং কনফার্মেশন.pdf",
        type: "PDF",
        size: "3.8 MB",
        updatedAt: "০৫ মে, ২০২৫",
      },
    ],
    team: [
      {
        id: 1,
        name: "আবদুল করিম",
        role: "প্রজেক্ট ম্যানেজার",
        photoUrl: "https://mj-ahmad.github.io/mja2025/img/hr00.png",
      },
      {
        id: 2,
        name: "মতিউর রহমান",
        role: "ভিসা কন্সালট্যান্ট",
        photoUrl: "https://mj-ahmad.github.io/mja2025/img/hr02.png",
      },
      {
        id: 3,
        name: "নাজমুল হাসান",
        role: "অ্যাকোমোডেশন কোঅর্ডিনেটর",
        photoUrl: "https://mj-ahmad.github.io/mja2025/img/hr01.png",
      },
      {
        id: 4,
        name: "সাজেদা খাতুন",
        role: "ট্রাভেল কোঅর্ডিনেটর",
        photoUrl: "https://mj-ahmad.github.io/mja2025/img/hr03.png",
      },
      {
        id: 5,
        name: "কামাল হোসেন",
        role: "ট্রান্সপোর্টেশন ম্যানেজার",
        photoUrl: "https://mj-ahmad.github.io/mja2025/img/hr00.png",
      },
      {
        id: 6,
        name: "সায়মা আক্তার",
        role: "গাইড কোঅর্ডিনেটর",
        photoUrl: "https://mj-ahmad.github.io/mja2025/img/hr04.png",
      },
    ],
  },
}

// Status colors and icons mapping
const statusConfig = {
  চলমান: {
    color: "bg-blue-100 text-blue-800",
    icon: Clock,
  },
  সম্পন্ন: {
    color: "bg-green-100 text-green-800",
    icon: CheckCircle,
  },
  বাকি: {
    color: "bg-yellow-100 text-yellow-800",
    icon: AlertTriangle,
  },
  বাতিল: {
    color: "bg-red-100 text-red-800",
    icon: XCircle,
  },
  মিটিগেটেড: {
    color: "bg-green-100 text-green-800",
    icon: CheckCircle,
  },
  মনিটরিং: {
    color: "bg-blue-100 text-blue-800",
    icon: Clock,
  },
}

export default function ProjectDetailPage() {
  const params = useParams()
  const router = useRouter()
  const [isDropdownOpen, setIsDropdownOpen] = useState(false)
  const [activeTab, setActiveTab] = useState("overview")
  const [notificationsOpen, setNotificationsOpen] = useState(false)

  // Get project ID from URL params
  const projectId = params.id as string
  const project = projectsData[projectId as keyof typeof projectsData]

  if (!project) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-800 mb-2">প্রকল্প পাওয়া যায়নি</h1>
          <p className="text-gray-600 mb-4">আপনার অনুরোধকৃত প্রকল্পটি খুঁজে পাওয়া যায়নি।</p>
          <Link href="/admin/director-general" className="inline-flex items-center text-green-600 hover:text-green-700">
            <ArrowLeft className="h-4 w-4 mr-2" />
            ড্যাশবোর্ডে ফিরে যান
          </Link>
        </div>
      </div>
    )
  }

  // Handle logout function
  const handleLogout = () => {
    router.push("/admin/login")
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-30">
        <div className="flex items-center justify-between p-4">
          <div className="flex items-center">
            <div className="flex items-center mr-10">
              <Image
                src="https://mj-ahmad.github.io/mja2025/img/icon.png"
                alt="T-ALLY Logo"
                width={40}
                height={40}
                className="mr-3"
              />
              <h1 className="text-xl font-bold text-green-600">TRUSTED-ALLY</h1>
            </div>
          </div>

          <div className="flex items-center space-x-5">
            {/* Notifications */}
            <div className="relative">
              <button
                className="p-1.5 rounded-full bg-gray-100 hover:bg-gray-200 relative"
                onClick={() => setNotificationsOpen(!notificationsOpen)}
              >
                <Bell className="h-5 w-5 text-gray-700" />
                <span className="absolute top-0 right-0 h-2 w-2 rounded-full bg-red-500"></span>
              </button>
            </div>

            {/* Settings button */}
            <button className="p-1.5 rounded-full bg-gray-100 hover:bg-gray-200">
              <Settings className="h-5 w-5 text-gray-700" />
            </button>

            {/* User profile */}
            <div className="relative">
              <button className="flex items-center space-x-3" onClick={() => setIsDropdownOpen(!isDropdownOpen)}>
                <div className="h-9 w-9 rounded-full bg-green-500 flex items-center justify-center text-white text-lg font-medium">
                  ম
                </div>
                <div className="hidden md:block text-right">
                  <div className="font-medium">মোঃ আনিসুর রহমান</div>
                  <div className="text-xs text-gray-500">মহাপরিচালক</div>
                </div>
                <ChevronDown
                  className={`h-4 w-4 text-gray-500 transition-transform duration-200 
                  ${isDropdownOpen ? "transform rotate-180" : ""}`}
                />
              </button>

              {/* Profile dropdown */}
              {isDropdownOpen && (
                <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg py-2 z-50 border border-gray-200">
                  <Link
                    href="/admin/director-general/profile"
                    className="block px-4 py-2 text-gray-700 hover:bg-gray-100"
                  >
                    প্রোফাইল
                  </Link>
                  <Link
                    href="/admin/director-general/settings"
                    className="block px-4 py-2 text-gray-700 hover:bg-gray-100"
                  >
                    সেটিংস
                  </Link>
                  <hr className="my-1 border-gray-200" />
                  <button
                    onClick={handleLogout}
                    className="flex w-full items-center px-4 py-2 text-red-600 hover:bg-gray-100"
                  >
                    <LogOut className="h-4 w-4 mr-2" />
                    লগআউট
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6">
        {/* Navigation */}
        <div className="flex items-center mb-6">
          <Link href="/admin/director-general" className="flex items-center text-gray-500 hover:text-gray-700">
            <ArrowLeft className="h-5 w-5 mr-2" />
            ড্যাশবোর্ডে ফিরে যান
          </Link>
        </div>

        {/* Project Header */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span
                  className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                    statusConfig[project.status as keyof typeof statusConfig].color
                  }`}
                >
                  {project.status}
                </span>
                <span className="text-sm text-gray-500">{project.category}</span>
              </div>
              <h1 className="text-2xl font-bold">{project.name}</h1>
              <p className="text-gray-600 mt-2">{project.description}</p>
            </div>
            <div className="flex gap-3">
              <button className="bg-gray-100 hover:bg-gray-200 text-gray-700 px-4 py-2 rounded-lg flex items-center">
                <FileText className="h-4 w-4 mr-2" />
                রিপোর্ট
              </button>
              <button className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg flex items-center">
                <Edit className="h-4 w-4 mr-2" />
                এডিট
              </button>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="border-b border-gray-200 mb-6">
          <div className="flex space-x-8">
            <button
              className={`py-3 px-1 border-b-2 font-medium text-sm transition-colors duration-150 ${
                activeTab === "overview"
                  ? "border-green-500 text-green-600"
                  : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
              }`}
              onClick={() => setActiveTab("overview")}
            >
              ওভারভিউ
            </button>
            <button
              className={`py-3 px-1 border-b-2 font-medium text-sm transition-colors duration-150 ${
                activeTab === "tasks"
                  ? "border-green-500 text-green-600"
                  : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
              }`}
              onClick={() => setActiveTab("tasks")}
            >
              টাস্ক
            </button>
            <button
              className={`py-3 px-1 border-b-2 font-medium text-sm transition-colors duration-150 ${
                activeTab === "team"
                  ? "border-green-500 text-green-600"
                  : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
              }`}
              onClick={() => setActiveTab("team")}
            >
              টিম
            </button>
            <button
              className={`py-3 px-1 border-b-2 font-medium text-sm transition-colors duration-150 ${
                activeTab === "files"
                  ? "border-green-500 text-green-600"
                  : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
              }`}
              onClick={() => setActiveTab("files")}
            >
              ফাইল
            </button>
            <button
              className={`py-3 px-1 border-b-2 font-medium text-sm transition-colors duration-150 ${
                activeTab === "updates"
                  ? "border-green-500 text-green-600"
                  : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
              }`}
              onClick={() => setActiveTab("updates")}
            >
              আপডেট
            </button>
            <button
              className={`py-3 px-1 border-b-2 font-medium text-sm transition-colors duration-150 ${
                activeTab === "risks"
                  ? "border-green-500 text-green-600"
                  : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
              }`}
              onClick={() => setActiveTab("risks")}
            >
              রিস্ক
            </button>
          </div>
        </div>

        {/* Tab Content */}
        {activeTab === "overview" && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Project Stats */}
            <div className="md:col-span-2">
              <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
                <h2 className="text-lg font-bold mb-4">প্রকল্প স্ট্যাটাস</h2>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <div className="flex flex-col p-4 border border-gray-200 rounded-lg">
                    <div className="flex items-center mb-2">
                      <Briefcase className="h-5 w-5 text-gray-500 mr-2" />
                      <span className="text-gray-500 text-sm">অগ্রগতি</span>
                    </div>
                    <div className="flex items-center">
                      <span className="text-xl font-bold mr-2">{project.progress}%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2 mt-2">
                      <div className="h-2 rounded-full bg-green-500" style={{ width: `${project.progress}%` }}></div>
                    </div>
                  </div>

                  <div className="flex flex-col p-4 border border-gray-200 rounded-lg">
                    <div className="flex items-center mb-2">
                      <CalendarDays className="h-5 w-5 text-gray-500 mr-2" />
                      <span className="text-gray-500 text-sm">সময়সীমা</span>
                    </div>
                    <div className="flex flex-col">
                      <span className="text-sm text-gray-500">শুরু: {project.startDate}</span>
                      <span className="text-sm font-medium">শেষ: {project.endDate}</span>
                    </div>
                  </div>

                  <div className="flex flex-col p-4 border border-gray-200 rounded-lg">
                    <div className="flex items-center mb-2">
                      <DollarSign className="h-5 w-5 text-gray-500 mr-2" />
                      <span className="text-gray-500 text-sm">বাজেট</span>
                    </div>
                    <div className="flex flex-col">
                      <span className="text-xl font-bold">{project.budget}</span>
                      <span className="text-sm text-gray-500">ব্যয়: {project.spent}</span>
                    </div>
                  </div>

                  <div className="flex flex-col p-4 border border-gray-200 rounded-lg">
                    <div className="flex items-center mb-2">
                      <Users className="h-5 w-5 text-gray-500 mr-2" />
                      <span className="text-gray-500 text-sm">টিম</span>
                    </div>
                    <div className="flex flex-col">
                      <span className="text-xl font-bold">{project.teamSize} জন</span>
                      <span className="text-sm text-gray-500">ম্যানেজার: {project.manager}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Task Overview */}
              <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
                <div className="flex justify-between items-center mb-4">
                  <h2 className="text-lg font-bold">টাস্ক ওভারভিউ</h2>
                  <button
                    className="text-sm text-green-600 hover:text-green-800 font-medium flex items-center"
                    onClick={() => setActiveTab("tasks")}
                  >
                    <span>সব দেখুন</span>
                    <ExternalLink className="h-4 w-4 ml-1" />
                  </button>
                </div>
                <div className="overflow-x-auto">
                  <table className="min-w-full">
                    <thead>
                      <tr className="text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        <th className="pb-3 pl-1">টাস্ক</th>
                        <th className="pb-3">অগ্রগতি</th>
                        <th className="pb-3">দায়িত্বপ্রাপ্ত</th>
                        <th className="pb-3">ডেডলাইন</th>
                        <th className="pb-3">অবস্থা</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                      {project.tasks.slice(0, 3).map((task) => (
                        <tr key={task.id}>
                          <td className="py-3 pl-1">
                            <div className="text-sm font-medium text-gray-900">{task.title}</div>
                          </td>
                          <td className="py-3">
                            <div className="flex items-center">
                              <div className="w-full bg-gray-200 rounded-full h-2 mr-2 max-w-[100px]">
                                <div
                                  className={`h-2 rounded-full ${
                                    task.progress >= 100
                                      ? "bg-green-500"
                                      : task.progress >= 60
                                        ? "bg-yellow-500"
                                        : "bg-red-500"
                                  }`}
                                  style={{ width: `${task.progress}%` }}
                                ></div>
                              </div>
                              <span className="text-xs font-medium text-gray-900">{task.progress}%</span>
                            </div>
                          </td>
                          <td className="py-3 text-sm">{task.assignee}</td>
                          <td className="py-3 text-sm">{task.dueDate}</td>
                          <td className="py-3">
                            <span
                              className={`inline-flex px-2 text-xs font-semibold rounded-full ${
                                statusConfig[task.status as keyof typeof statusConfig].color
                              }`}
                            >
                              {task.status}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Recent Updates */}
              <div className="bg-white rounded-lg shadow-sm p-6">
                <div className="flex justify-between items-center mb-4">
                  <h2 className="text-lg font-bold">সাম্প্রতিক আপডেট</h2>
                  <button
                    className="text-sm text-green-600 hover:text-green-800 font-medium flex items-center"
                    onClick={() => setActiveTab("updates")}
                  >
                    <span>সব দেখুন</span>
                    <ExternalLink className="h-4 w-4 ml-1" />
                  </button>
                </div>
                <div className="space-y-4">
                  {project.updates.map((update) => (
                    <div key={update.id} className="border-l-4 border-green-500 pl-4 py-2">
                      <div className="flex justify-between items-start">
                        <div>
                          <h3 className="font-medium">{update.author}</h3>
                          <p className="text-sm text-gray-600 mt-1">{update.content}</p>
                        </div>
                        <span className="text-xs text-gray-500">{update.date}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Sidebar */}
            <div className="md:col-span-1">
              {/* Project Team */}
              <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
                <div className="flex justify-between items-center mb-4">
                  <h2 className="text-lg font-bold">প্রজেক্ট টিম</h2>
                  <button
                    className="text-sm text-green-600 hover:text-green-800 font-medium flex items-center"
                    onClick={() => setActiveTab("team")}
                  >
                    <span>সব দেখুন</span>
                    <ExternalLink className="h-4 w-4 ml-1" />
                  </button>
                </div>
                <div className="space-y-4">
                  {project.team.slice(0, 4).map((member) => (
                    <div key={member.id} className="flex items-center">
                      <div className="flex-shrink-0 h-10 w-10 rounded-full overflow-hidden mr-4">
                        <Image
                          src={member.photoUrl || "/placeholder.svg"}
                          alt={member.name}
                          width={40}
                          height={40}
                          className="h-full w-full object-cover"
                        />
                      </div>
                      <div>
                        <h3 className="text-sm font-medium">{member.name}</h3>
                        <p className="text-xs text-gray-500">{member.role}</p>
                      </div>
                    </div>
                  ))}
                  <div className="text-center pt-2">
                    <button
                      className="text-sm text-green-600 hover:text-green-800 font-medium"
                      onClick={() => setActiveTab("team")}
                    >
                      {project.team.length - 4} জন আরও
                    </button>
                  </div>
                </div>
              </div>

              {/* Project Files */}
              <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
                <div className="flex justify-between items-center mb-4">
                  <h2 className="text-lg font-bold">প্রজেক্ট ফাইল</h2>
                  <button
                    className="text-sm text-green-600 hover:text-green-800 font-medium flex items-center"
                    onClick={() => setActiveTab("files")}
                  >
                    <span>সব দেখুন</span>
                    <ExternalLink className="h-4 w-4 ml-1" />
                  </button>
                </div>
                <div className="space-y-3">
                  {project.files.map((file) => (
                    <div key={file.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div className="flex items-center">
                        <FileText className="h-5 w-5 text-gray-500 mr-3" />
                        <div>
                          <p className="text-sm font-medium">{file.name}</p>
                          <p className="text-xs text-gray-500">
                            {file.type} • {file.size} • {file.updatedAt}
                          </p>
                        </div>
                      </div>
                      <button className="text-gray-500 hover:text-gray-700">
                        <Download className="h-5 w-5" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              {/* Risk Overview */}
              <div className="bg-white rounded-lg shadow-sm p-6">
                <div className="flex justify-between items-center mb-4">
                  <h2 className="text-lg font-bold">রিস্ক ওভারভিউ</h2>
                  <button
                    className="text-sm text-green-600 hover:text-green-800 font-medium flex items-center"
                    onClick={() => setActiveTab("risks")}
                  >
                    <span>সব দেখুন</span>
                    <ExternalLink className="h-4 w-4 ml-1" />
                  </button>
                </div>
                <div className="space-y-3">
                  {project.riskAssessment.map((risk) => (
                    <div key={risk.id} className="p-3 bg-gray-50 rounded-lg">
                      <div className="flex justify-between items-start mb-2">
                        <h3 className="text-sm font-medium">{risk.title}</h3>
                        <span
                          className={`inline-flex px-2 text-xs font-semibold rounded-full ${
                            statusConfig[risk.status as keyof typeof statusConfig].color
                          }`}
                        >
                          {risk.status}
                        </span>
                      </div>
                      <div className="flex text-xs text-gray-500 mb-2">
                        <span className="mr-3">ইমপ্যাক্ট: {risk.impact}</span>
                        <span>প্রোবাবিলিটি: {risk.probability}</span>
                      </div>
                      <p className="text-xs text-gray-600">{risk.mitigation}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Tasks Tab Content */}
        {activeTab === "tasks" && (
          <div className="bg-white rounded-lg shadow-sm p-6">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-lg font-bold">টাস্ক সমূহ</h2>
              <div className="flex items-center space-x-2">
                <div className="relative">
                  <input
                    type="text"
                    placeholder="টাস্ক খুঁজুন..."
                    className="bg-gray-100 rounded-lg py-2 pl-3 pr-10 w-64 focus:outline-none focus:ring-2 focus:ring-green-500 focus:bg-white"
                  />
                </div>
                <button className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg flex items-center">
                  <span>নতুন টাস্ক</span>
                  <ChevronDown className="h-4 w-4 ml-2" />
                </button>
              </div>
            </div>

            {/* Task Table */}
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th
                      scope="col"
                      className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                    >
                      টাস্ক
                    </th>
                    <th
                      scope="col"
                      className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                    >
                      অগ্রগতি
                    </th>
                    <th
                      scope="col"
                      className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                    >
                      দায়িত্বপ্রাপ্ত
                    </th>
                    <th
                      scope="col"
                      className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                    >
                      ডেডলাইন
                    </th>
                    <th
                      scope="col"
                      className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                    >
                      অবস্থা
                    </th>
                    <th
                      scope="col"
                      className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider"
                    >
                      একশন
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {project.tasks.map((task) => (
                    <tr key={task.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm font-medium text-gray-900">{task.title}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <div className="w-full bg-gray-200 rounded-full h-2 mr-2 max-w-[100px]">
                            <div
                              className={`h-2 rounded-full ${
                                task.progress >= 100
                                  ? "bg-green-500"
                                  : task.progress >= 60
                                    ? "bg-yellow-500"
                                    : "bg-red-500"
                              }`}
                              style={{ width: `${task.progress}%` }}
                            ></div>
                          </div>
                          <span className="text-xs font-medium text-gray-900">{task.progress}%</span>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">{task.assignee}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">{task.dueDate}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span
                          className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                            statusConfig[task.status as keyof typeof statusConfig].color
                          }`}
                        >
                          {task.status}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        <button className="text-gray-500 hover:text-gray-700">
                          <MoreHorizontal className="h-5 w-5" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Team Tab Content */}
        {activeTab === "team" && (
          <div className="bg-white rounded-lg shadow-sm p-6">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-lg font-bold">প্রকল্প টিম</h2>
              <button className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg flex items-center">
                <span>সদস্য যোগ করুন</span>
                <ChevronDown className="h-4 w-4 ml-2" />
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {project.team.map((member) => (
                <div
                  key={member.id}
                  className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow"
                >
                  <div className="flex items-start">
                    <div className="flex-shrink-0 mr-4">
                      <Image
                        src={member.photoUrl || "/placeholder.svg"}
                        alt={member.name}
                        width={60}
                        height={60}
                        className="rounded-full"
                      />
                    </div>
                    <div>
                      <h3 className="font-medium">{member.name}</h3>
                      <p className="text-sm text-gray-500">{member.role}</p>
                      <div className="flex space-x-2 mt-3">
                        <button className="text-sm px-2 py-1 bg-gray-100 rounded text-gray-700 hover:bg-gray-200">
                          মেসেজ
                        </button>
                        <button className="text-sm px-2 py-1 bg-gray-100 rounded text-gray-700 hover:bg-gray-200">
                          প্রোফাইল
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Files Tab Content */}
        {activeTab === "files" && (
          <div className="bg-white rounded-lg shadow-sm p-6">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-lg font-bold">প্রজেক্ট ফাইল</h2>
              <button className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg flex items-center">
                <span>ফাইল আপলোড</span>
                <ChevronDown className="h-4 w-4 ml-2" />
              </button>
            </div>

            <div className="space-y-4">
              {project.files.map((file) => (
                <div
                  key={file.id}
                  className="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
                >
                  <div className="flex items-center">
                    <FileText className="h-10 w-10 text-gray-500 mr-4" />
                    <div>
                      <h3 className="font-medium">{file.name}</h3>
                      <p className="text-sm text-gray-500">
                        {file.type} • {file.size} • আপডেট: {file.updatedAt}
                      </p>
                    </div>
                  </div>
                  <div className="flex space-x-2">
                    <button className="text-gray-500 hover:text-gray-700 p-2">
                      <Download className="h-5 w-5" />
                    </button>
                    <button className="text-gray-500 hover:text-gray-700 p-2">
                      <MoreHorizontal className="h-5 w-5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Updates Tab Content */}
        {activeTab === "updates" && (
          <div className="bg-white rounded-lg shadow-sm p-6">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-lg font-bold">প্রকল্প আপডেট</h2>
              <button className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg flex items-center">
                <span>নতুন আপডেট</span>
                <ChevronDown className="h-4 w-4 ml-2" />
              </button>
            </div>

            <div className="space-y-6">
              {project.updates.map((update) => (
                <div key={update.id} className="border-l-4 border-green-500 pl-6 py-4 bg-gray-50 rounded-r-lg">
                  <div className="flex justify-between items-start mb-3">
                    <h3 className="font-medium">{update.author}</h3>
                    <span className="text-sm text-gray-500">{update.date}</span>
                  </div>
                  <p className="text-gray-700">{update.content}</p>
                  <div className="flex space-x-4 mt-4">
                    <button className="text-sm text-gray-600 hover:text-gray-800 flex items-center">
                      <MessageSquare className="h-4 w-4 mr-1" />
                      <span>কমেন্ট</span>
                    </button>
                    <button className="text-sm text-gray-600 hover:text-gray-800 flex items-center">
                      <MoreHorizontal className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Risks Tab Content */}
        {activeTab === "risks" && (
          <div className="bg-white rounded-lg shadow-sm p-6">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-lg font-bold">রিস্ক অ্যাসেসমেন্ট</h2>
              <button className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg flex items-center">
                <span>নতুন রিস্ক</span>
                <ChevronDown className="h-4 w-4 ml-2" />
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th
                      scope="col"
                      className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                    >
                      রিস্ক
                    </th>
                    <th
                      scope="col"
                      className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                    >
                      ইমপ্যাক্ট
                    </th>
                    <th
                      scope="col"
                      className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                    >
                      প্রোবাবিলিটি
                    </th>
                    <th
                      scope="col"
                      className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                    >
                      মিটিগেশন প্ল্যান
                    </th>
                    <th
                      scope="col"
                      className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                    >
                      অবস্থা
                    </th>
                    <th
                      scope="col"
                      className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider"
                    >
                      একশন
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {project.riskAssessment.map((risk) => (
                    <tr key={risk.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4">
                        <div className="text-sm font-medium text-gray-900">{risk.title}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span
                          className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                            risk.impact === "উচ্চ"
                              ? "bg-red-100 text-red-800"
                              : risk.impact === "মাঝারি"
                                ? "bg-yellow-100 text-yellow-800"
                                : "bg-green-100 text-green-800"
                          }`}
                        >
                          {risk.impact}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span
                          className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                            risk.probability === "উচ্চ"
                              ? "bg-red-100 text-red-800"
                              : risk.probability === "মাঝারি"
                                ? "bg-yellow-100 text-yellow-800"
                                : "bg-green-100 text-green-800"
                          }`}
                        >
                          {risk.probability}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-sm text-gray-900">{risk.mitigation}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span
                          className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                            statusConfig[risk.status as keyof typeof statusConfig].color
                          }`}
                        >
                          {risk.status}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        <button className="text-gray-500 hover:text-gray-700">
                          <MoreHorizontal className="h-5 w-5" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </main>
    </div>
  )
}

