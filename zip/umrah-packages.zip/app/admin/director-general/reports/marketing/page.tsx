"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { useRouter } from "next/navigation"
import {
  ArrowLeft,
  Share,
  ArrowUpRight,
  ArrowDownRight,
  BarChart3,
  Users,
  ShoppingCart,
  Globe,
  ChevronDown,
  Calendar,
  FileText,
  LogOut,
  Settings,
  Bell,
} from "lucide-react"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
} from "recharts"

// Sample data for charts
const packageSalesData = [
  { month: "জানুয়ারি", উমরাহ: 32, হজ্জ: 15, অন্যান্য: 8 },
  { month: "ফেব্রুয়ারি", উমরাহ: 28, হজ্জ: 18, অন্যান্য: 10 },
  { month: "মার্চ", উমরাহ: 35, হজ্জ: 20, অন্যান্য: 12 },
  { month: "এপ্রিল", উমরাহ: 42, হজ্জ: 25, অন্যান্য: 15 },
  { month: "মে", উমরাহ: 50, হজ্জ: 30, অন্যান্য: 18 },
]

const customerSourceData = [
  { name: "সোশ্যাল মিডিয়া", value: 45 },
  { name: "রেফারেল", value: 25 },
  { name: "সার্চ ইঞ্জিন", value: 20 },
  { name: "অন্যান্য", value: 10 },
]

const packagePerformanceData = [
  { name: "স্ট্যান্ডার্ড উমরাহ", sales: 85, satisfaction: 92, growth: 15 },
  { name: "প্রিমিয়াম উমরাহ", sales: 65, satisfaction: 95, growth: 22 },
  { name: "ফ্যামিলি উমরাহ", sales: 72, satisfaction: 88, growth: 18 },
  { name: "রমজান উমরাহ", sales: 90, satisfaction: 90, growth: 25 },
  { name: "স্ট্যান্ডার্ড হজ্জ", sales: 45, satisfaction: 85, growth: 10 },
  { name: "ভিআইপি হজ্জ", sales: 35, satisfaction: 98, growth: 30 },
]

const customerFeedbackData = [
  { category: "সার্ভিস কোয়ালিটি", positive: 85, neutral: 10, negative: 5 },
  { category: "প্যাকেজ মূল্য", positive: 75, neutral: 15, negative: 10 },
  { category: "হোটেল সুবিধা", positive: 80, neutral: 12, negative: 8 },
  { category: "ফ্লাইট সুবিধা", positive: 70, neutral: 20, negative: 10 },
  { category: "গাইড সেবা", positive: 90, neutral: 8, negative: 2 },
]

const websiteTrafficData = [
  { day: "১", visitors: 240 },
  { day: "২", visitors: 280 },
  { day: "৩", visitors: 320 },
  { day: "৪", visitors: 290 },
  { day: "৫", visitors: 350 },
  { day: "৬", visitors: 380 },
  { day: "৭", visitors: 420 },
  { day: "৮", visitors: 450 },
  { day: "৯", visitors: 400 },
  { day: "১০", visitors: 380 },
  { day: "১১", visitors: 410 },
  { day: "১২", visitors: 440 },
  { day: "১৩", visitors: 480 },
  { day: "১৪", visitors: 460 },
  { day: "১৫", visitors: 490 },
  { day: "১৬", visitors: 520 },
  { day: "১৭", visitors: 550 },
  { day: "১৮", visitors: 500 },
  { day: "১৯", visitors: 480 },
  { day: "২০", visitors: 510 },
  { day: "২১", visitors: 540 },
  { day: "২২", visitors: 580 },
  { day: "২৩", visitors: 600 },
  { day: "২৪", visitors: 580 },
  { day: "২৫", visitors: 620 },
  { day: "২৬", visitors: 650 },
  { day: "২৭", visitors: 680 },
  { day: "২৮", visitors: 700 },
  { day: "২৯", visitors: 720 },
  { day: "৩০", visitors: 750 },
]

export default function MarketingReportPage() {
  const [isDropdownOpen, setIsDropdownOpen] = useState(false)
  const [dateRange, setDateRange] = useState("মে ২০২৫")
  const [notificationsOpen, setNotificationsOpen] = useState(false)
  const router = useRouter()

  // Handle logout function
  const handleLogout = () => {
    router.push("/admin/login")
  }

  const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042", "#8884D8"]

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-30">
        <div className="flex items-center justify-between p-4">
          <div className="flex items-center">
            <div className="flex items-center mr-10">
              <Image
                src="https://mj-ahmad.github.io/mja2025/img/icon.png"
                alt="T-ALLY Logo"
                width={40}
                height={40}
                className="mr-3"
              />
              <h1 className="text-xl font-bold text-green-600">TRUSTED-ALLY</h1>
            </div>
          </div>

          <div className="flex items-center space-x-5">
            {/* Notifications */}
            <div className="relative">
              <button
                className="p-1.5 rounded-full bg-gray-100 hover:bg-gray-200 relative"
                onClick={() => setNotificationsOpen(!notificationsOpen)}
              >
                <Bell className="h-5 w-5 text-gray-700" />
                <span className="absolute top-0 right-0 h-2 w-2 rounded-full bg-red-500"></span>
              </button>
            </div>

            {/* Settings button */}
            <button className="p-1.5 rounded-full bg-gray-100 hover:bg-gray-200">
              <Settings className="h-5 w-5 text-gray-700" />
            </button>

            {/* User profile */}
            <div className="relative">
              <button className="flex items-center space-x-3" onClick={() => setIsDropdownOpen(!isDropdownOpen)}>
                <div className="h-9 w-9 rounded-full bg-green-500 flex items-center justify-center text-white text-lg font-medium">
                  ম
                </div>
                <div className="hidden md:block text-right">
                  <div className="font-medium">মোঃ আনিসুর রহমান</div>
                  <div className="text-xs text-gray-500">মহাপরিচালক</div>
                </div>
                <ChevronDown
                  className={`h-4 w-4 text-gray-500 transition-transform duration-200 
                  ${isDropdownOpen ? "transform rotate-180" : ""}`}
                />
              </button>

              {/* Profile dropdown */}
              {isDropdownOpen && (
                <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg py-2 z-50 border border-gray-200">
                  <Link
                    href="/admin/director-general/profile"
                    className="block px-4 py-2 text-gray-700 hover:bg-gray-100"
                  >
                    প্রোফাইল
                  </Link>
                  <Link
                    href="/admin/director-general/settings"
                    className="block px-4 py-2 text-gray-700 hover:bg-gray-100"
                  >
                    সেটিংস
                  </Link>
                  <hr className="my-1 border-gray-200" />
                  <button
                    onClick={handleLogout}
                    className="flex w-full items-center px-4 py-2 text-red-600 hover:bg-gray-100"
                  >
                    <LogOut className="h-4 w-4 mr-2" />
                    লগআউট
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6">
        {/* Navigation */}
        <div className="flex items-center mb-6">
          <Link href="/admin/director-general" className="flex items-center text-gray-500 hover:text-gray-700">
            <ArrowLeft className="h-5 w-5 mr-2" />
            ড্যাশবোর্ডে ফিরে যান
          </Link>
        </div>

        {/* Report Header */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div>
              <h1 className="text-2xl font-bold">মার্কেটিং রিপোর্ট - {dateRange}</h1>
              <p className="text-gray-600 mt-1">পণ্য বিক্রয়, গ্রাহক আগমন, এবং মার্কেটিং কার্যক্রমের সামগ্রিক পারফরম্যান্স</p>
            </div>
            <div className="flex flex-wrap gap-3">
              <div className="relative">
                <button className="flex items-center space-x-1 bg-gray-100 hover:bg-gray-200 px-3 py-2 rounded-lg text-sm">
                  <Calendar className="h-4 w-4 mr-1" />
                  <span>{dateRange}</span>
                  <ChevronDown className="h-4 w-4 ml-1" />
                </button>
              </div>
              <button className="flex items-center space-x-1 bg-gray-100 hover:bg-gray-200 px-3 py-2 rounded-lg text-sm">
                <FileText className="h-4 w-4 mr-1" />
                <span>PDF</span>
                <ChevronDown className="h-4 w-4 ml-1" />
              </button>
              <button className="flex items-center space-x-1 bg-gray-100 hover:bg-gray-200 px-3 py-2 rounded-lg text-sm">
                <Share className="h-4 w-4 mr-1" />
                <span>শেয়ার</span>
              </button>
            </div>
          </div>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
          <div className="bg-white rounded-lg shadow-sm p-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-gray-500 text-sm">মোট বিক্রয়</p>
                <h3 className="text-2xl font-bold mt-1">১৭৮</h3>
                <div className="flex items-center mt-2 text-sm">
                  <div className="flex items-center text-green-600">
                    <ArrowUpRight className="h-3 w-3 mr-1" />
                    <span>১৮.৫%</span>
                  </div>
                  <span className="text-gray-500 ml-2">গত মাস থেকে</span>
                </div>
              </div>
              <div className="bg-blue-100 p-3 rounded-lg">
                <ShoppingCart className="h-6 w-6 text-blue-600" />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-sm p-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-gray-500 text-sm">নতুন গ্রাহক</p>
                <h3 className="text-2xl font-bold mt-1">৫৪</h3>
                <div className="flex items-center mt-2 text-sm">
                  <div className="flex items-center text-green-600">
                    <ArrowUpRight className="h-3 w-3 mr-1" />
                    <span>১২.৭%</span>
                  </div>
                  <span className="text-gray-500 ml-2">গত মাস থেকে</span>
                </div>
              </div>
              <div className="bg-green-100 p-3 rounded-lg">
                <Users className="h-6 w-6 text-green-600" />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-sm p-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-gray-500 text-sm">ওয়েবসাইট ভিজিটর</p>
                <h3 className="text-2xl font-bold mt-1">১২,৫৬০</h3>
                <div className="flex items-center mt-2 text-sm">
                  <div className="flex items-center text-green-600">
                    <ArrowUpRight className="h-3 w-3 mr-1" />
                    <span>২৫.৩%</span>
                  </div>
                  <span className="text-gray-500 ml-2">গত মাস থেকে</span>
                </div>
              </div>
              <div className="bg-purple-100 p-3 rounded-lg">
                <Globe className="h-6 w-6 text-purple-600" />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-sm p-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-gray-500 text-sm">কনভার্শন রেট</p>
                <h3 className="text-2xl font-bold mt-1">৪.২%</h3>
                <div className="flex items-center mt-2 text-sm">
                  <div className="flex items-center text-red-600">
                    <ArrowDownRight className="h-3 w-3 mr-1" />
                    <span>০.৮%</span>
                  </div>
                  <span className="text-gray-500 ml-2">গত মাস থেকে</span>
                </div>
              </div>
              <div className="bg-orange-100 p-3 rounded-lg">
                <BarChart3 className="h-6 w-6 text-orange-600" />
              </div>
            </div>
          </div>
        </div>

        {/* Charts Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          {/* Package Sales Chart */}
          <div className="bg-white rounded-lg shadow-sm p-6">
            <h2 className="text-lg font-semibold mb-4">প্যাকেজ বিক্রয় ট্রেন্ড</h2>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={packageSalesData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="উমরাহ" fill="#8884d8" />
                <Bar dataKey="হজ্জ" fill="#82ca9d" />
                <Bar dataKey="অন্যান্য" fill="#ffc658" />
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* Customer Source Chart */}
          <div className="bg-white rounded-lg shadow-sm p-6">
            <h2 className="text-lg font-semibold mb-4">গ্রাহক উৎস</h2>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={customerSourceData}
                  cx="50%"
                  cy="50%"
                  labelLine={true}
                  outerRadius={100}
                  fill="#8884d8"
                  dataKey="value"
                  label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                >
                  {customerSourceData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Package Performance Table */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <h2 className="text-lg font-semibold mb-4">প্যাকেজ পারফরম্যান্স</h2>
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th
                    scope="col"
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                  >
                    প্যাকেজ নাম
                  </th>
                  <th
                    scope="col"
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                  >
                    বিক্রয় (টার্গেট %)
                  </th>
                  <th
                    scope="col"
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                  >
                    গ্রাহক সন্তুষ্টি
                  </th>
                  <th
                    scope="col"
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                  >
                    বৃদ্ধি
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {packagePerformanceData.map((pkg, index) => (
                  <tr key={index}>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="font-medium text-gray-900">{pkg.name}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="w-full bg-gray-200 rounded-full h-2.5">
                          <div className="bg-blue-600 h-2.5 rounded-full" style={{ width: `${pkg.sales}%` }}></div>
                        </div>
                        <span className="ml-2 text-sm text-gray-500">{pkg.sales}%</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="w-full bg-gray-200 rounded-full h-2.5">
                          <div
                            className="bg-green-500 h-2.5 rounded-full"
                            style={{ width: `${pkg.satisfaction}%` }}
                          ></div>
                        </div>
                        <span className="ml-2 text-sm text-gray-500">{pkg.satisfaction}%</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                        +{pkg.growth}%
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Customer Feedback Chart */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <h2 className="text-lg font-semibold mb-4">গ্রাহক ফিডব্যাক</h2>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={customerFeedbackData} layout="vertical" margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis type="number" />
              <YAxis dataKey="category" type="category" width={150} />
              <Tooltip />
              <Legend />
              <Bar dataKey="positive" fill="#82ca9d" name="পজিটিভ" stackId="a" />
              <Bar dataKey="neutral" fill="#8884d8" name="নিউট্রাল" stackId="a" />
              <Bar dataKey="negative" fill="#ff8042" name="নেগেটিভ" stackId="a" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Website Traffic Chart */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <h2 className="text-lg font-semibold mb-4">ওয়েবসাইট ট্রাফিক (গত ৩০ দিন)</h2>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={websiteTrafficData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="day" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="visitors" stroke="#8884d8" activeDot={{ r: 8 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Recommendations Section */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <h2 className="text-lg font-semibold mb-4">মার্কেটিং সুপারিশ</h2>
          <div className="space-y-4">
            <div className="p-4 border border-green-200 rounded-lg bg-green-50">
              <h3 className="font-medium text-green-800">রমজান উমরাহ প্যাকেজ প্রমোশন বাড়ান</h3>
              <p className="mt-1 text-sm text-green-700">
                রমজান উমরাহ প্যাকেজের চাহিদা ২৫% বৃদ্ধি পেয়েছে। সোশ্যাল মিডিয়া এবং ইমেইল মার্কেটিং এর মাধ্যমে এই প্যাকেজের প্রমোশন বাড়ানো
                যেতে পারে।
              </p>
            </div>
            <div className="p-4 border border-blue-200 rounded-lg bg-blue-50">
              <h3 className="font-medium text-blue-800">ফ্যামিলি উমরাহ প্যাকেজে ডিসকাউন্ট অফার</h3>
              <p className="mt-1 text-sm text-blue-700">
                ফ্যামিলি উমরাহ প্যাকেজে আর্লি বুকিং ডিসকাউন্ট অফার করলে বিক্রয় বাড়ানো সম্ভব। গত বছরের তথ্য অনুযায়ী, এই সময়ে ফ্যামিলি
                প্যাকেজের চাহিদা বাড়ে।
              </p>
            </div>
            <div className="p-4 border border-purple-200 rounded-lg bg-purple-50">
              <h3 className="font-medium text-purple-800">সার্চ ইঞ্জিন অপটিমাইজেশন উন্নত করুন</h3>
              <p className="mt-1 text-sm text-purple-700">
                সার্চ ইঞ্জিন থেকে ট্রাফিক বাড়ানোর জন্য SEO উন্নত করা প্রয়োজন। 'উমরাহ প্যাকেজ', 'হজ্জ ট্যুর', এবং 'মক্কা মদিনা ভ্রমণ'
                কীওয়ার্ডগুলোতে র‍্যাঙ্কিং বাড়ানোর সুযোগ আছে।
              </p>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}

