"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { useRouter } from "next/navigation"
import {
  BarChart3,
  Users,
  Package,
  Calendar,
  TrendingUp,
  Bell,
  Settings,
  ChevronDown,
  LogOut,
  FileText,
  Briefcase,
  CreditCard,
  ArrowUpRight,
  ArrowDownRight,
  Search,
  Menu,
  X,
  Home,
  PieChart,
  Activity,
  MessageSquare,
  Clock,
  CheckCircle,
  AlertCircle,
  HelpCircle,
} from "lucide-react"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart as RePieChart,
  Pie,
  Cell,
} from "recharts"

// Sample data for charts
const revenueData = [
  { month: "জানুয়ারি", আয়: 4500000, ব্যয়: 3200000 },
  { month: "ফেব্রুয়ারি", আয়: 5200000, ব্যয়: 3800000 },
  { month: "মার্চ", আয়: 4800000, ব্যয়: 3500000 },
  { month: "এপ্রিল", আয়: 6000000, ব্যয়: 4200000 },
  { month: "মে", আয়: 6500000, ব্যয়: 4500000 },
  { month: "জুন", আয়: 7200000, ব্যয়: 5000000 },
]

const projectStatusData = [
  { name: "সম্পন্ন", value: 12 },
  { name: "চলমান", value: 8 },
  { name: "পরিকল্পিত", value: 5 },
  { name: "স্থগিত", value: 2 },
]

const packageSalesData = [
  { name: "উমরাহ প্যাকেজ", value: 178 },
  { name: "হজ্জ প্যাকেজ", value: 120 },
  { name: "ট্রান্সপোর্টেশন", value: 95 },
  { name: "হোটেল বুকিং", value: 85 },
  { name: "ফ্লাইট বুকিং", value: 65 },
]

const recentActivities = [
  {
    id: 1,
    title: "নতুন উমরাহ প্যাকেজ যোগ করা হয়েছে",
    time: "আজ, ১০:৩০ AM",
    status: "success",
  },
  {
    id: 2,
    title: "হজ্জ প্যাকেজের মূল্য আপডেট করা হয়েছে",
    time: "আজ, ০৯:১৫ AM",
    status: "info",
  },
  {
    id: 3,
    title: "মার্কেটিং রিপোর্ট প্রস্তুত করা হয়েছে",
    time: "গতকাল, ০৪:৪৫ PM",
    status: "success",
  },
  {
    id: 4,
    title: "নতুন কর্মচারী নিয়োগ দেওয়া হয়েছে",
    time: "গতকাল, ০২:৩০ PM",
    status: "success",
  },
  {
    id: 5,
    title: "সিস্টেম মেইনটেন্যান্স শিডিউল করা হয়েছে",
    time: "গতকাল, ১১:০০ AM",
    status: "warning",
  },
]

const upcomingTasks = [
  {
    id: 1,
    title: "মাসিক প্রজেক্ট রিভিউ মিটিং",
    date: "আগামীকাল, ১০:০০ AM",
    priority: "high",
  },
  {
    id: 2,
    title: "নতুন মার্কেটিং ক্যাম্পেইন লঞ্চ",
    date: "১৫ মে, ২০২৫",
    priority: "medium",
  },
  {
    id: 3,
    title: "কর্মচারী পারফরম্যান্স মূল্যায়ন",
    date: "২০ মে, ২০২৫",
    priority: "medium",
  },
  {
    id: 4,
    title: "বাজেট প্ল্যানিং মিটিং",
    date: "২৫ মে, ২০২৫",
    priority: "high",
  },
]

export default function DirectorGeneralDashboard() {
  const [isDropdownOpen, setIsDropdownOpen] = useState(false)
  const [isSidebarOpen, setIsSidebarOpen] = useState(true)
  const [notificationsOpen, setNotificationsOpen] = useState(false)
  const router = useRouter()

  // Handle logout function
  const handleLogout = () => {
    router.push("/admin/login")
  }

  const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042", "#8884D8"]

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-30">
        <div className="flex items-center justify-between p-4">
          <div className="flex items-center">
            <button
              className="p-1.5 rounded-lg text-gray-500 hover:bg-gray-100 lg:hidden mr-2"
              onClick={() => setIsSidebarOpen(!isSidebarOpen)}
            >
              {isSidebarOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
            <div className="flex items-center mr-10">
              <Image
                src="https://mj-ahmad.github.io/mja2025/img/icon.png"
                alt="T-ALLY Logo"
                width={40}
                height={40}
                className="mr-3"
              />
              <h1 className="text-xl font-bold text-green-600">TRUSTED-ALLY</h1>
            </div>
            <div className="hidden md:flex items-center bg-gray-100 rounded-lg px-3 py-2 max-w-md">
              <Search className="h-5 w-5 text-gray-500 mr-2" />
              <input
                type="text"
                placeholder="অনুসন্ধান করুন..."
                className="bg-transparent border-none focus:outline-none text-sm w-full"
              />
            </div>
          </div>

          <div className="flex items-center space-x-5">
            {/* Notifications */}
            <div className="relative">
              <button
                className="p-1.5 rounded-full bg-gray-100 hover:bg-gray-200 relative"
                onClick={() => setNotificationsOpen(!notificationsOpen)}
              >
                <Bell className="h-5 w-5 text-gray-700" />
                <span className="absolute top-0 right-0 h-2 w-2 rounded-full bg-red-500"></span>
              </button>
            </div>

            {/* Settings button */}
            <button className="p-1.5 rounded-full bg-gray-100 hover:bg-gray-200">
              <Settings className="h-5 w-5 text-gray-700" />
            </button>

            {/* User profile */}
            <div className="relative">
              <button className="flex items-center space-x-3" onClick={() => setIsDropdownOpen(!isDropdownOpen)}>
                <div className="h-9 w-9 rounded-full bg-green-500 flex items-center justify-center text-white text-lg font-medium">
                  ম
                </div>
                <div className="hidden md:block text-right">
                  <div className="font-medium">মোঃ আনিসুর রহমান</div>
                  <div className="text-xs text-gray-500">মহাপরিচালক</div>
                </div>
                <ChevronDown
                  className={`h-4 w-4 text-gray-500 transition-transform duration-200 
                  ${isDropdownOpen ? "transform rotate-180" : ""}`}
                />
              </button>

              {/* Profile dropdown */}
              {isDropdownOpen && (
                <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg py-2 z-50 border border-gray-200">
                  <Link
                    href="/admin/director-general/profile"
                    className="block px-4 py-2 text-gray-700 hover:bg-gray-100"
                  >
                    প্রোফাইল
                  </Link>
                  <Link
                    href="/admin/director-general/settings"
                    className="block px-4 py-2 text-gray-700 hover:bg-gray-100"
                  >
                    সেটিংস
                  </Link>
                  <hr className="my-1 border-gray-200" />
                  <button
                    onClick={handleLogout}
                    className="flex w-full items-center px-4 py-2 text-red-600 hover:bg-gray-100"
                  >
                    <LogOut className="h-4 w-4 mr-2" />
                    লগআউট
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </header>

      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar */}
        <aside
          className={`bg-white border-r border-gray-200 w-64 flex-shrink-0 fixed lg:sticky top-[73px] h-[calc(100vh-73px)] z-20 transition-transform duration-300 transform ${
            isSidebarOpen ? "translate-x-0" : "-translate-x-full"
          } lg:translate-x-0`}
        >
          <div className="h-full flex flex-col overflow-y-auto py-4">
            <nav className="flex-1 px-4 space-y-1">
              <div className="mb-6">
                <p className="px-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">মূল মেনু</p>
                <div className="mt-3 space-y-1">
                  <Link
                    href="/admin/director-general"
                    className="flex items-center px-3 py-2 text-sm font-medium rounded-lg bg-green-50 text-green-700"
                  >
                    <Home className="h-5 w-5 mr-3" />
                    ড্যাশবোর্ড
                  </Link>
                  <Link
                    href="/admin/director-general/projects"
                    className="flex items-center px-3 py-2 text-sm font-medium rounded-lg text-gray-700 hover:bg-gray-100"
                  >
                    <Briefcase className="h-5 w-5 mr-3" />
                    প্রকল্পসমূহ
                  </Link>
                  <Link
                    href="/admin/director-general/finance"
                    className="flex items-center px-3 py-2 text-sm font-medium rounded-lg text-gray-700 hover:bg-gray-100"
                  >
                    <CreditCard className="h-5 w-5 mr-3" />
                    আর্থিক ব্যবস্থাপনা
                  </Link>
                  <Link
                    href="/admin/director-general/hr"
                    className="flex items-center px-3 py-2 text-sm font-medium rounded-lg text-gray-700 hover:bg-gray-100"
                  >
                    <Users className="h-5 w-5 mr-3" />
                    মানব সম্পদ
                  </Link>
                </div>
              </div>

              <div className="mb-6">
                <p className="px-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">রিপোর্টস</p>
                <div className="mt-3 space-y-1">
                  <Link
                    href="/admin/director-general/reports/marketing"
                    className="flex items-center px-3 py-2 text-sm font-medium rounded-lg text-gray-700 hover:bg-gray-100"
                  >
                    <TrendingUp className="h-5 w-5 mr-3" />
                    মার্কেটিং রিপোর্ট
                  </Link>
                  <Link
                    href="/admin/director-general/reports/sales"
                    className="flex items-center px-3 py-2 text-sm font-medium rounded-lg text-gray-700 hover:bg-gray-100"
                  >
                    <BarChart3 className="h-5 w-5 mr-3" />
                    সেলস রিপোর্ট
                  </Link>
                  <Link
                    href="/admin/director-general/reports/finance"
                    className="flex items-center px-3 py-2 text-sm font-medium rounded-lg text-gray-700 hover:bg-gray-100"
                  >
                    <PieChart className="h-5 w-5 mr-3" />
                    ফাইনান্স রিপোর্ট
                  </Link>
                  <Link
                    href="/admin/director-general/reports/performance"
                    className="flex items-center px-3 py-2 text-sm font-medium rounded-lg text-gray-700 hover:bg-gray-100"
                  >
                    <Activity className="h-5 w-5 mr-3" />
                    পারফরম্যান্স রিপোর্ট
                  </Link>
                </div>
              </div>

              <div className="mb-6">
                <p className="px-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">অন্যান্য</p>
                <div className="mt-3 space-y-1">
                  <Link
                    href="/admin/director-general/messages"
                    className="flex items-center px-3 py-2 text-sm font-medium rounded-lg text-gray-700 hover:bg-gray-100"
                  >
                    <MessageSquare className="h-5 w-5 mr-3" />
                    বার্তা
                  </Link>
                  <Link
                    href="/admin/director-general/calendar"
                    className="flex items-center px-3 py-2 text-sm font-medium rounded-lg text-gray-700 hover:bg-gray-100"
                  >
                    <Calendar className="h-5 w-5 mr-3" />
                    ক্যালেন্ডার
                  </Link>
                  <Link
                    href="/admin/director-general/documents"
                    className="flex items-center px-3 py-2 text-sm font-medium rounded-lg text-gray-700 hover:bg-gray-100"
                  >
                    <FileText className="h-5 w-5 mr-3" />
                    ডকুমেন্টস
                  </Link>
                  <Link
                    href="/admin/director-general/help"
                    className="flex items-center px-3 py-2 text-sm font-medium rounded-lg text-gray-700 hover:bg-gray-100"
                  >
                    <HelpCircle className="h-5 w-5 mr-3" />
                    সাহায্য
                  </Link>
                </div>
              </div>
            </nav>
          </div>
        </aside>

        {/* Main content */}
        <main className="flex-1 overflow-y-auto p-6">
          <div className="mb-6">
            <h1 className="text-2xl font-bold">ড্যাশবোর্ড</h1>
            <p className="text-gray-600 mt-1">সকল প্রকল্পের সামগ্রিক অবস্থা এবং পরিসংখ্যান</p>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
            <div className="bg-white rounded-lg shadow-sm p-6">
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-gray-500 text-sm">মোট প্রকল্প</p>
                  <h3 className="text-2xl font-bold mt-1">২৭</h3>
                  <div className="flex items-center mt-2 text-sm">
                    <div className="flex items-center text-green-600">
                      <ArrowUpRight className="h-3 w-3 mr-1" />
                      <span>১২.৫%</span>
                    </div>
                    <span className="text-gray-500 ml-2">গত মাস থেকে</span>
                  </div>
                </div>
                <div className="bg-blue-100 p-3 rounded-lg">
                  <Briefcase className="h-6 w-6 text-blue-600" />
                </div>
              </div>
            </div>

            <div className="bg-white rounded-lg shadow-sm p-6">
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-gray-500 text-sm">মোট আয়</p>
                  <h3 className="text-2xl font-bold mt-1">৬.৫ কোটি</h3>
                  <div className="flex items-center mt-2 text-sm">
                    <div className="flex items-center text-green-600">
                      <ArrowUpRight className="h-3 w-3 mr-1" />
                      <span>১৮.৩%</span>
                    </div>
                    <span className="text-gray-500 ml-2">গত মাস থেকে</span>
                  </div>
                </div>
                <div className="bg-green-100 p-3 rounded-lg">
                  <CreditCard className="h-6 w-6 text-green-600" />
                </div>
              </div>
            </div>

            <div className="bg-white rounded-lg shadow-sm p-6">
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-gray-500 text-sm">মোট কর্মচারী</p>
                  <h3 className="text-2xl font-bold mt-1">১৫৬</h3>
                  <div className="flex items-center mt-2 text-sm">
                    <div className="flex items-center text-green-600">
                      <ArrowUpRight className="h-3 w-3 mr-1" />
                      <span>৫.৪%</span>
                    </div>
                    <span className="text-gray-500 ml-2">গত মাস থেকে</span>
                  </div>
                </div>
                <div className="bg-purple-100 p-3 rounded-lg">
                  <Users className="h-6 w-6 text-purple-600" />
                </div>
              </div>
            </div>

            <div className="bg-white rounded-lg shadow-sm p-6">
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-gray-500 text-sm">মোট বিক্রয়</p>
                  <h3 className="text-2xl font-bold mt-1">৫৪৩</h3>
                  <div className="flex items-center mt-2 text-sm">
                    <div className="flex items-center text-red-600">
                      <ArrowDownRight className="h-3 w-3 mr-1" />
                      <span>২.১%</span>
                    </div>
                    <span className="text-gray-500 ml-2">গত মাস থেকে</span>
                  </div>
                </div>
                <div className="bg-orange-100 p-3 rounded-lg">
                  <Package className="h-6 w-6 text-orange-600" />
                </div>
              </div>
            </div>
          </div>

          {/* Charts Section */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
            {/* Revenue Chart */}
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h2 className="text-lg font-semibold mb-4">আয়-ব্যয় বিশ্লেষণ</h2>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={revenueData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip formatter={(value) => `${(value / 100000).toFixed(2)} লক্ষ`} />
                  <Legend />
                  <Bar dataKey="আয়" fill="#8884d8" />
                  <Bar dataKey="ব্যয়" fill="#82ca9d" />
                </BarChart>
              </ResponsiveContainer>
            </div>

            {/* Project Status Chart */}
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h2 className="text-lg font-semibold mb-4">প্রকল্প স্ট্যাটাস</h2>
              <ResponsiveContainer width="100%" height={300}>
                <RePieChart>
                  <Pie
                    data={projectStatusData}
                    cx="50%"
                    cy="50%"
                    labelLine={true}
                    outerRadius={100}
                    fill="#8884d8"
                    dataKey="value"
                    label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                  >
                    {projectStatusData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </RePieChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Package Sales and Activities Section */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
            {/* Package Sales */}
            <div className="bg-white rounded-lg shadow-sm p-6 lg:col-span-1">
              <h2 className="text-lg font-semibold mb-4">প্যাকেজ বিক্রয়</h2>
              <div className="space-y-4">
                {packageSalesData.map((item, index) => (
                  <div key={index} className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div
                        className="w-3 h-3 rounded-full mr-3"
                        style={{ backgroundColor: COLORS[index % COLORS.length] }}
                      ></div>
                      <span className="text-sm font-medium">{item.name}</span>
                    </div>
                    <span className="text-sm font-semibold">{item.value}</span>
                  </div>
                ))}
              </div>
              <div className="mt-6">
                <Link
                  href="/admin/director-general/reports/sales"
                  className="text-sm text-blue-600 hover:text-blue-800 font-medium"
                >
                  বিস্তারিত দেখুন →
                </Link>
              </div>
            </div>

            {/* Recent Activities */}
            <div className="bg-white rounded-lg shadow-sm p-6 lg:col-span-1">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold">সাম্প্রতিক কার্যক্রম</h2>
                <Link
                  href="/admin/director-general/activities"
                  className="text-sm text-blue-600 hover:text-blue-800 font-medium"
                >
                  সব দেখুন
                </Link>
              </div>
              <div className="space-y-4">
                {recentActivities.map((activity) => (
                  <div key={activity.id} className="flex items-start">
                    <div className="flex-shrink-0 mt-1">
                      {activity.status === "success" && <CheckCircle className="h-5 w-5 text-green-500" />}
                      {activity.status === "warning" && <AlertCircle className="h-5 w-5 text-yellow-500" />}
                      {activity.status === "info" && <HelpCircle className="h-5 w-5 text-blue-500" />}
                    </div>
                    <div className="ml-3">
                      <p className="text-sm font-medium">{activity.title}</p>
                      <p className="text-xs text-gray-500 mt-0.5 flex items-center">
                        <Clock className="h-3 w-3 mr-1" />
                        {activity.time}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Upcoming Tasks */}
            <div className="bg-white rounded-lg shadow-sm p-6 lg:col-span-1">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold">আসন্ন কাজসমূহ</h2>
                <Link
                  href="/admin/director-general/tasks"
                  className="text-sm text-blue-600 hover:text-blue-800 font-medium"
                >
                  সব দেখুন
                </Link>
              </div>
              <div className="space-y-4">
                {upcomingTasks.map((task) => (
                  <div key={task.id} className="p-3 bg-gray-50 rounded-lg">
                    <div className="flex items-center justify-between">
                      <h3 className="text-sm font-medium">{task.title}</h3>
                      <span
                        className={`px-2 py-1 text-xs rounded-full ${
                          task.priority === "high" ? "bg-red-100 text-red-800" : "bg-yellow-100 text-yellow-800"
                        }`}
                      >
                        {task.priority === "high" ? "উচ্চ" : "মধ্যম"}
                      </span>
                    </div>
                    <p className="text-xs text-gray-500 mt-1 flex items-center">
                      <Calendar className="h-3 w-3 mr-1" />
                      {task.date}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Projects Overview */}
          <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold">প্রকল্প সংক্ষিপ্ত বিবরণ</h2>
              <Link
                href="/admin/director-general/projects"
                className="text-sm text-blue-600 hover:text-blue-800 font-medium"
              >
                সব প্রকল্প দেখুন
              </Link>
            </div>
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th
                      scope="col"
                      className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                    >
                      প্রকল্পের নাম
                    </th>
                    <th
                      scope="col"
                      className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                    >
                      অবস্থা
                    </th>
                    <th
                      scope="col"
                      className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                    >
                      অগ্রগতি
                    </th>
                    <th
                      scope="col"
                      className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                    >
                      দায়িত্বপ্রাপ্ত ব্যক্তি
                    </th>
                    <th
                      scope="col"
                      className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                    >
                      সময়সীমা
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  <tr>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="font-medium text-gray-900">উমরাহ প্যাকেজ ওয়েবসাইট</div>
                      <div className="text-sm text-gray-500">ওয়েব ডেভেলপমেন্ট</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className="px-2 py-1 text-xs rounded-full bg-green-100 text-green-800">চলমান</span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="w-full bg-gray-200 rounded-full h-2.5">
                          <div className="bg-blue-600 h-2.5 rounded-full" style={{ width: "85%" }}></div>
                        </div>
                        <span className="ml-2 text-sm text-gray-500">85%</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="h-8 w-8 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-800 font-medium text-sm mr-2">
                          আ
                        </div>
                        <div className="text-sm">আবদুল্লাহ আল মামুন</div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">৩০ মে, ২০২৫</td>
                  </tr>
                  <tr>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="font-medium text-gray-900">হজ্জ প্যাকেজ মার্কেটিং</div>
                      <div className="text-sm text-gray-500">মার্কেটিং</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className="px-2 py-1 text-xs rounded-full bg-yellow-100 text-yellow-800">পরিকল্পনা</span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="w-full bg-gray-200 rounded-full h-2.5">
                          <div className="bg-yellow-500 h-2.5 rounded-full" style={{ width: "40%" }}></div>
                        </div>
                        <span className="ml-2 text-sm text-gray-500">40%</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="h-8 w-8 rounded-full bg-green-100 flex items-center justify-center text-green-800 font-medium text-sm mr-2">
                          র
                        </div>
                        <div className="text-sm">রফিকুল ইসলাম</div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">১৫ জুন, ২০২৫</td>
                  </tr>
                  <tr>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="font-medium text-gray-900">মোবাইল অ্যাপ ডেভেলপমেন্ট</div>
                      <div className="text-sm text-gray-500">অ্যাপ ডেভেলপমেন্ট</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className="px-2 py-1 text-xs rounded-full bg-blue-100 text-blue-800">চলমান</span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="w-full bg-gray-200 rounded-full h-2.5">
                          <div className="bg-blue-600 h-2.5 rounded-full" style={{ width: "60%" }}></div>
                        </div>
                        <span className="ml-2 text-sm text-gray-500">60%</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="h-8 w-8 rounded-full bg-purple-100 flex items-center justify-center text-purple-800 font-medium text-sm mr-2">
                          ন
                        </div>
                        <div className="text-sm">নাজমুল হাসান</div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">১০ জুলাই, ২০২৫</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </main>
      </div>
    </div>
  )
}

