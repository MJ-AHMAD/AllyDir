import Image from "next/image"

export default function ManagementPage() {
  return (
    <div className="bg-white min-h-screen">
      {/* Hero Section */}
      <div className="bg-gradient-to-r from-green-800 to-green-600 text-white py-16">
        <div className="container mx-auto px-4">
          <h1 className="text-4xl md:text-5xl font-bold mb-4 text-center">পরিচালনা পরিষদ</h1>
          <p className="text-xl text-center max-w-3xl mx-auto">টি-অ্যালি উমরাহ প্যাকেজেস এর সুষ্ঠু পরিচালনা ও ব্যবস্থাপনা সিস্টেম</p>
        </div>
      </div>

      {/* Management Philosophy */}
      <section className="py-12 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold mb-8 text-center text-green-800">আমাদের ব্যবস্থাপনা দর্শন</h2>
          <div className="max-w-4xl mx-auto">
            <p className="text-lg mb-6">
              টি-অ্যালি উমরাহ প্যাকেজেস এর ব্যবস্থাপনা দর্শন মূলত সেবা, স্বচ্ছতা এবং দক্ষতার উপর ভিত্তি করে গড়ে উঠেছে। আমরা বিশ্বাস করি যে
              হজ্জ ও উমরাহ যাত্রীদের সেবা করা একটি পবিত্র দায়িত্ব, যা আমরা সর্বোচ্চ নিষ্ঠা ও আন্তরিকতার সাথে পালন করি।
            </p>
            <p className="text-lg mb-6">
              আমাদের ব্যবস্থাপনা কাঠামো এমনভাবে সাজানো হয়েছে যাতে প্রতিটি বিভাগ সুচারুরূপে কাজ করতে পারে এবং যাত্রীদের সর্বোচ্চ সেবা নিশ্চিত করা
              যায়। আমাদের প্রতিটি কর্মকর্তা ও কর্মচারী তাদের নির্দিষ্ট দায়িত্ব পালনের মাধ্যমে সামগ্রিক লক্ষ্য অর্জনে অবদান রাখে।
            </p>
          </div>
        </div>
      </section>

      {/* Organizational Structure */}
      <section className="py-12">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold mb-8 text-center text-green-800">সাংগঠনিক কাঠামো</h2>

          <div className="max-w-5xl mx-auto bg-white rounded-lg shadow-lg p-6 mb-12">
            <div className="flex flex-col items-center">
              <div className="bg-green-700 text-white rounded-lg p-4 mb-4 w-64 text-center">
                <h3 className="font-bold">ব্যবস্থাপনা পরিচালক</h3>
                <p className="text-sm">সর্বোচ্চ নির্বাহী কর্মকর্তা</p>
              </div>

              <div className="w-1 h-8 bg-gray-400"></div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
                <div className="bg-green-600 text-white rounded-lg p-4 text-center">
                  <h3 className="font-bold">পরিচালক (অপারেশন্স)</h3>
                </div>
                <div className="bg-green-600 text-white rounded-lg p-4 text-center">
                  <h3 className="font-bold">পরিচালক (অর্থ ও হিসাব)</h3>
                </div>
                <div className="bg-green-600 text-white rounded-lg p-4 text-center">
                  <h3 className="font-bold">পরিচালক (মার্কেটিং)</h3>
                </div>
              </div>

              <div className="w-3/4 h-1 bg-gray-400 mb-8"></div>

              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="bg-green-500 text-white rounded-lg p-3 text-center">
                  <h3 className="font-bold">প্যাকেজ ব্যবস্থাপনা</h3>
                </div>
                <div className="bg-green-500 text-white rounded-lg p-3 text-center">
                  <h3 className="font-bold">যাত্রী সেবা</h3>
                </div>
                <div className="bg-green-500 text-white rounded-lg p-3 text-center">
                  <h3 className="font-bold">হিসাব ও বিনিয়োগ</h3>
                </div>
                <div className="bg-green-500 text-white rounded-lg p-3 text-center">
                  <h3 className="font-bold">বিক্রয় ও প্রচার</h3>
                </div>
              </div>
            </div>
          </div>

          <p className="text-lg text-center max-w-4xl mx-auto mb-8">
            আমাদের সাংগঠনিক কাঠামো পিরামিড আকারে সাজানো, যেখানে ব্যবস্থাপনা পরিচালক সর্বোচ্চ পদে অবস্থান করেন এবং তিনজন পরিচালক তাঁর অধীনে কাজ
            করেন। প্রতিটি পরিচালকের অধীনে বিভিন্ন বিভাগ রয়েছে, যেগুলো নির্দিষ্ট কার্যক্রম পরিচালনা করে।
          </p>
        </div>
      </section>

      {/* Management Team */}
      <section className="py-12 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold mb-8 text-center text-green-800">পরিচালনা টিম</h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {/* CEO */}
            <div className="bg-white rounded-lg shadow-lg overflow-hidden">
              <div className="p-6">
                <div className="w-32 h-32 rounded-full bg-gray-200 mx-auto mb-4 overflow-hidden">
                  <Image
                    src="/placeholder.svg?height=128&width=128"
                    alt="ব্যবস্থাপনা পরিচালক"
                    width={128}
                    height={128}
                    className="object-cover"
                  />
                </div>
                <h3 className="text-xl font-bold text-center mb-2">মোহাম্মদ আবদুল্লাহ</h3>
                <p className="text-green-700 text-center font-medium mb-4">ব্যবস্থাপনা পরিচালক</p>
                <p className="text-gray-600 mb-4">
                  ২০ বছরের অভিজ্ঞতা সহ হজ্জ ও উমরাহ ব্যবস্থাপনায় বিশেষজ্ঞ। সামগ্রিক কোম্পানির দিকনির্দেশনা ও রণনীতি নির্ধারণ করেন।
                </p>
                <div className="border-t pt-4">
                  <h4 className="font-bold mb-2">প্রধান দায়িত্বসমূহ:</h4>
                  <ul className="list-disc pl-5 text-gray-600">
                    <li>কোম্পানির সামগ্রিক দিকনির্দেশনা</li>
                    <li>রণনৈতিক সিদ্ধান্ত গ্রহণ</li>
                    <li>বোর্ডের সাথে যোগাযোগ</li>
                    <li>উচ্চ পর্যায়ের চুক্তি সম্পাদন</li>
                  </ul>
                </div>
              </div>
            </div>

            {/* Operations Director */}
            <div className="bg-white rounded-lg shadow-lg overflow-hidden">
              <div className="p-6">
                <div className="w-32 h-32 rounded-full bg-gray-200 mx-auto mb-4 overflow-hidden">
                  <Image
                    src="/placeholder.svg?height=128&width=128"
                    alt="পরিচালক (অপারেশন্স)"
                    width={128}
                    height={128}
                    className="object-cover"
                  />
                </div>
                <h3 className="text-xl font-bold text-center mb-2">ফারহানা রহমান</h3>
                <p className="text-green-700 text-center font-medium mb-4">পরিচালক (অপারেশন্স)</p>
                <p className="text-gray-600 mb-4">
                  ১৫ বছরের অভিজ্ঞতা সহ ট্যুর অপারেশন ও লজিস্টিক ব্যবস্থাপনায় দক্ষ। সমস্ত অপারেশনাল কার্যক্রম তত্ত্বাবধান করেন।
                </p>
                <div className="border-t pt-4">
                  <h4 className="font-bold mb-2">প্রধান দায়িত্বসমূহ:</h4>
                  <ul className="list-disc pl-5 text-gray-600">
                    <li>প্যাকেজ পরিচালনা</li>
                    <li>ভিসা প্রসেসিং</li>
                    <li>যাত্রী সেবা নিশ্চিতকরণ</li>
                    <li>পরিবহন ও আবাসন ব্যবস্থাপনা</li>
                  </ul>
                </div>
              </div>
            </div>

            {/* Finance Director */}
            <div className="bg-white rounded-lg shadow-lg overflow-hidden">
              <div className="p-6">
                <div className="w-32 h-32 rounded-full bg-gray-200 mx-auto mb-4 overflow-hidden">
                  <Image
                    src="/placeholder.svg?height=128&width=128"
                    alt="পরিচালক (অর্থ ও হিসাব)"
                    width={128}
                    height={128}
                    className="object-cover"
                  />
                </div>
                <h3 className="text-xl font-bold text-center mb-2">মাহমুদুল হাসান</h3>
                <p className="text-green-700 text-center font-medium mb-4">পরিচালক (অর্থ ও হিসাব)</p>
                <p className="text-gray-600 mb-4">
                  চার্টার্ড একাউন্টেন্ট হিসেবে ১২ বছরের অভিজ্ঞতা। কোম্পানির সমস্ত আর্থিক বিষয় ও বিনিয়োগ পরিচালনা করেন।
                </p>
                <div className="border-t pt-4">
                  <h4 className="font-bold mb-2">প্রধান দায়িত্বসমূহ:</h4>
                  <ul className="list-disc pl-5 text-gray-600">
                    <li>আর্থিক ব্যবস্থাপনা</li>
                    <li>বাজেট প্রণয়ন</li>
                    <li>বিনিয়োগ পরিচালনা</li>
                    <li>লভ্যাংশ বিতরণ</li>
                  </ul>
                </div>
              </div>
            </div>

            {/* Marketing Director */}
            <div className="bg-white rounded-lg shadow-lg overflow-hidden">
              <div className="p-6">
                <div className="w-32 h-32 rounded-full bg-gray-200 mx-auto mb-4 overflow-hidden">
                  <Image
                    src="/placeholder.svg?height=128&width=128"
                    alt="পরিচালক (মার্কেটিং)"
                    width={128}
                    height={128}
                    className="object-cover"
                  />
                </div>
                <h3 className="text-xl font-bold text-center mb-2">নাজমুল হক</h3>
                <p className="text-green-700 text-center font-medium mb-4">পরিচালক (মার্কেটিং)</p>
                <p className="text-gray-600 mb-4">
                  ট্যুরিজম মার্কেটিং এ ১০ বছরের অভিজ্ঞতা। কোম্পানির সমস্ত বিপণন, প্রচার ও বিক্রয় কার্যক্রম পরিচালনা করেন।
                </p>
                <div className="border-t pt-4">
                  <h4 className="font-bold mb-2">প্রধান দায়িত্বসমূহ:</h4>
                  <ul className="list-disc pl-5 text-gray-600">
                    <li>মার্কেটিং স্ট্র্যাটেজি</li>
                    <li>ব্র্যান্ড প্রমোশন</li>
                    <li>বিক্রয় বৃদ্ধি</li>
                    <li>গ্রাহক সম্পর্ক উন্নয়ন</li>
                  </ul>
                </div>
              </div>
            </div>

            {/* HR Manager */}
            <div className="bg-white rounded-lg shadow-lg overflow-hidden">
              <div className="p-6">
                <div className="w-32 h-32 rounded-full bg-gray-200 mx-auto mb-4 overflow-hidden">
                  <Image
                    src="/placeholder.svg?height=128&width=128"
                    alt="ম্যানেজার (এইচআর)"
                    width={128}
                    height={128}
                    className="object-cover"
                  />
                </div>
                <h3 className="text-xl font-bold text-center mb-2">সাবরিনা আহমেদ</h3>
                <p className="text-green-700 text-center font-medium mb-4">ম্যানেজার (এইচআর)</p>
                <p className="text-gray-600 mb-4">
                  মানব সম্পদ ব্যবস্থাপনায় ৮ বছরের অভিজ্ঞতা। কর্মী নিয়োগ, প্রশিক্ষণ ও কর্মী সম্পর্ক পরিচালনা করেন।
                </p>
                <div className="border-t pt-4">
                  <h4 className="font-bold mb-2">প্রধান দায়িত্বসমূহ:</h4>
                  <ul className="list-disc pl-5 text-gray-600">
                    <li>কর্মী নিয়োগ ও বাছাই</li>
                    <li>প্রশিক্ষণ ব্যবস্থাপনা</li>
                    <li>কর্মী মূল্যায়ন</li>
                    <li>কর্মী কল্যাণ</li>
                  </ul>
                </div>
              </div>
            </div>

            {/* IT Manager */}
            <div className="bg-white rounded-lg shadow-lg overflow-hidden">
              <div className="p-6">
                <div className="w-32 h-32 rounded-full bg-gray-200 mx-auto mb-4 overflow-hidden">
                  <Image
                    src="/placeholder.svg?height=128&width=128"
                    alt="ম্যানেজার (আইটি)"
                    width={128}
                    height={128}
                    className="object-cover"
                  />
                </div>
                <h3 className="text-xl font-bold text-center mb-2">তানভীর হোসেন</h3>
                <p className="text-green-700 text-center font-medium mb-4">ম্যানেজার (আইটি)</p>
                <p className="text-gray-600 mb-4">
                  আইটি ম্যানেজমেন্টে ৭ বছরের অভিজ্ঞতা। কোম্পানির সমস্ত প্রযুক্তিগত বিষয়, ওয়েবসাইট ও সফটওয়্যার পরিচালনা করেন।
                </p>
                <div className="border-t pt-4">
                  <h4 className="font-bold mb-2">প্রধান দায়িত্বসমূহ:</h4>
                  <ul className="list-disc pl-5 text-gray-600">
                    <li>ওয়েবসাইট পরিচালনা</li>
                    <li>সফটওয়্যার ব্যবস্থাপনা</li>
                    <li>ডাটা সিকিউরিটি</li>
                    <li>টেকনিক্যাল সাপোর্ট</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Departments and Responsibilities */}
      <section className="py-12">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold mb-8 text-center text-green-800">বিভাগসমূহ ও দায়িত্ব বণ্টন</h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-6xl mx-auto">
            {/* Operations Department */}
            <div className="bg-white rounded-lg shadow-lg p-6">
              <h3 className="text-xl font-bold mb-4 text-green-700">অপারেশন্স বিভাগ</h3>
              <p className="mb-4">
                এই বিভাগ সমস্ত অপারেশনাল কার্যক্রম পরিচালনা করে, যার মধ্যে রয়েছে প্যাকেজ ব্যবস্থাপনা, ভিসা প্রসেসিং, যাত্রী সেবা, পরিবহন ও
                আবাসন ব্যবস্থাপনা।
              </p>
              <h4 className="font-bold mt-4 mb-2">কর্মী সংখ্যা: ১৫ জন</h4>
              <ul className="list-disc pl-5 text-gray-600">
                <li>অপারেশন্স ম্যানেজার (১ জন)</li>
                <li>প্যাকেজ কোঅর্ডিনেটর (২ জন)</li>
                <li>ভিসা প্রসেসিং অফিসার (২ জন)</li>
                <li>যাত্রী সেবা প্রতিনিধি (৪ জন)</li>
                <li>পরিবহন কোঅর্ডিনেটর (২ জন)</li>
                <li>আবাসন কোঅর্ডিনেটর (২ জন)</li>
                <li>লজিস্টিক অফিসার (২ জন)</li>
              </ul>
            </div>

            {/* Finance Department */}
            <div className="bg-white rounded-lg shadow-lg p-6">
              <h3 className="text-xl font-bold mb-4 text-green-700">অর্থ ও হিসাব বিভাগ</h3>
              <p className="mb-4">
                এই বিভাগ কোম্পানির সমস্ত আর্থিক বিষয়, হিসাব-নিকাশ, বাজেট প্রণয়ন, বিনিয়োগ পরিচালনা ও লভ্যাংশ বিতরণ পরিচালনা করে।
              </p>
              <h4 className="font-bold mt-4 mb-2">কর্মী সংখ্যা: ১০ জন</h4>
              <ul className="list-disc pl-5 text-gray-600">
                <li>ফিনান্স ম্যানেজার (১ জন)</li>
                <li>একাউন্টস অফিসার (২ জন)</li>
                <li>বাজেট অ্যানালিস্ট (১ জন)</li>
                <li>ইনভেস্টমেন্ট অফিসার (২ জন)</li>
                <li>ডিভিডেন্ড ম্যানেজমেন্ট অফিসার (১ জন)</li>
                <li>অডিট অফিসার (১ জন)</li>
                <li>একাউন্টস এক্সিকিউটিভ (২ জন)</li>
              </ul>
            </div>

            {/* Marketing Department */}
            <div className="bg-white rounded-lg shadow-lg p-6">
              <h3 className="text-xl font-bold mb-4 text-green-700">মার্কেটিং বিভাগ</h3>
              <p className="mb-4">এই বিভাগ কোম্পানির সমস্ত বিপণন, প্রচার, বিক্রয় ও গ্রাহক সম্পর্ক উন্নয়ন কার্যক্রম পরিচালনা করে।</p>
              <h4 className="font-bold mt-4 mb-2">কর্মী সংখ্যা: ১২ জন</h4>
              <ul className="list-disc pl-5 text-gray-600">
                <li>মার্কেটিং ম্যানেজার (১ জন)</li>
                <li>ব্র্যান্ড ম্যানেজার (১ জন)</li>
                <li>সেলস এক্সিকিউটিভ (৪ জন)</li>
                <li>ডিজিটাল মার্কেটিং স্পেশালিস্ট (২ জন)</li>
                <li>কন্টেন্ট ক্রিয়েটর (২ জন)</li>
                <li>কাস্টমার রিলেশন অফিসার (২ জন)</li>
              </ul>
            </div>

            {/* HR Department */}
            <div className="bg-white rounded-lg shadow-lg p-6">
              <h3 className="text-xl font-bold mb-4 text-green-700">মানব সম্পদ বিভাগ</h3>
              <p className="mb-4">
                এই বিভাগ কোম্পানির সমস্ত মানব সম্পদ বিষয়ক কার্যক্রম, যেমন কর্মী নিয়োগ, প্রশিক্ষণ, মূল্যায়ন ও কর্মী কল্যাণ পরিচালনা করে।
              </p>
              <h4 className="font-bold mt-4 mb-2">কর্মী সংখ্যা: ৬ জন</h4>
              <ul className="list-disc pl-5 text-gray-600">
                <li>এইচআর ম্যানেজার (১ জন)</li>
                <li>রিক্রুটমেন্ট স্পেশালিস্ট (১ জন)</li>
                <li>ট্রেনিং অ্যান্ড ডেভেলপমেন্ট অফিসার (১ জন)</li>
                <li>পারফরম্যান্স ম্যানেজমেন্ট অফিসার (১ জন)</li>
                <li>এমপ্লয়ি রিলেশন অফিসার (১ জন)</li>
                <li>এইচআর এক্সিকিউটিভ (১ জন)</li>
              </ul>
            </div>

            {/* IT Department */}
            <div className="bg-white rounded-lg shadow-lg p-6">
              <h3 className="text-xl font-bold mb-4 text-green-700">আইটি বিভাগ</h3>
              <p className="mb-4">
                এই বিভাগ কোম্পানির সমস্ত প্রযুক্তিগত বিষয়, ওয়েবসাইট, সফটওয়্যার, ডাটা সিকিউরিটি ও টেকনিক্যাল সাপোর্ট পরিচালনা করে।
              </p>
              <h4 className="font-bold mt-4 mb-2">কর্মী সংখ্যা: ৭ জন</h4>
              <ul className="list-disc pl-5 text-gray-600">
                <li>আইটি ম্যানেজার (১ জন)</li>
                <li>ওয়েব ডেভেলপার (২ জন)</li>
                <li>সফটওয়্যার ডেভেলপার (১ জন)</li>
                <li>সিস্টেম অ্যাডমিনিস্ট্রেটর (১ জন)</li>
                <li>ডাটা সিকিউরিটি স্পেশালিস্ট (১ জন)</li>
                <li>টেকনিক্যাল সাপোর্ট এক্সিকিউটিভ (১ জন)</li>
              </ul>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

