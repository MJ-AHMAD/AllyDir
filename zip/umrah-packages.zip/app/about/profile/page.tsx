import Link from "next/link"

export default function ProfilePage() {
  return (
    <div className="min-h-screen bg-white">
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-5xl mx-auto">
          <h1 className="text-3xl md:text-4xl font-bold text-green-700 mb-6 border-b-2 border-green-600 pb-2">
            Trusted Ally Umrah & Hajj Services - প্রোফাইল
          </h1>

          <div className="bg-green-50 p-6 rounded-lg mb-8">
            <h2 className="text-xl font-bold text-green-800 mb-3">সংক্ষিপ্ত পরিচিতি</h2>
            <p className="mb-4">
              <strong>Trusted Ally Umrah & Hajj Services</strong> হল{" "}
              <Link href="https://v0-trusted-ally-website-ten.vercel.app/" className="text-blue-600 hover:underline">
                TRUSTED-ALLY
              </Link>{" "}
              এর একটি অন্যতম প্রকল্প, যা বাংলাদেশী মুসলিম ভাইবোনদের জন্য উমরাহ ও হজ্জ পালনের সুবিধা প্রদান করে। এই সেবাটি পবিত্র মক্কা ও
              মদিনায় যাত্রা, অবস্থান, এবং ধর্মীয় কর্মকাণ্ড সম্পাদনের জন্য সম্পূর্ণ সমাধান প্রদান করে।
            </p>
            <div className="border-l-4 border-green-600 pl-4 py-2 bg-green-100 mb-4">
              <p className="italic">
                <span className="font-semibold">TRUSTED-ALLY স্লোগান:</span> Together Towards a Brighter Future
              </p>
              <p className="mt-2">
                <span className="font-semibold">লক্ষ্য:</span> Be the Change You Wish to See
              </p>
            </div>
            <p>
              At TRUSTED-ALLY, we believe in the power of collective effort to shape a brighter tomorrow. This is your
              opportunity to be part of a movement that inspires, educates, and uplifts. Whether you dream of empowering
              young minds through education, driving impactful social initiatives, or protecting our planet for future
              generations—your contribution matters. Together, we can break barriers, ignite hope, and create lasting
              change.
            </p>
          </div>

          <section className="mb-10">
            <h2 className="text-2xl font-bold text-green-700 mb-4 border-b border-green-300 pb-2">
              Trusted Ally Umrah & Hajj Services - উদ্দেশ্য ও লক্ষ্য
            </h2>
            <div className="pl-4 border-l-2 border-green-500">
              <h3 className="text-xl font-semibold mb-2">প্রধান উদ্দেশ্য</h3>
              <ul className="list-disc pl-5 mb-4 space-y-2">
                <li>বাংলাদেশী মুসলিম ভাইবোনদের জন্য সহজ, নিরাপদ ও আধ্যাত্মিকভাবে সমৃদ্ধ উমরাহ ও হজ্জ যাত্রা নিশ্চিত করা</li>
                <li>সাশ্রয়ী মূল্যে উচ্চমানের সেবা প্রদান করা</li>
                <li>যাত্রীদের ধর্মীয় অনুশীলনে সহায়তা করা এবং আধ্যাত্মিক অভিজ্ঞতা বৃদ্ধি করা</li>
                <li>পবিত্র স্থানগুলোতে নিরাপদ ও আরামদায়ক অবস্থান নিশ্চিত করা</li>
              </ul>

              <h3 className="text-xl font-semibold mb-2">দীর্ঘমেয়াদী লক্ষ্য</h3>
              <ul className="list-disc pl-5 mb-4 space-y-2">
                <li>বাংলাদেশে উমরাহ ও হজ্জ সেবা প্রদানকারী প্রতিষ্ঠানগুলোর মধ্যে শীর্ষস্থান অর্জন করা</li>
                <li>প্রতি বছর অন্তত ১০,০০০ যাত্রীকে সেবা প্রদান করা</li>
                <li>ডিজিটাল প্ল্যাটফর্মের মাধ্যমে সেবা প্রদান প্রক্রিয়াকে আরও সহজ ও স্বচ্ছ করা</li>
                <li>বিনিয়োগকারীদের জন্য উচ্চ রিটার্ন নিশ্চিত করা</li>
              </ul>
            </div>
          </section>

          <section className="mb-10">
            <h2 className="text-2xl font-bold text-green-700 mb-4 border-b border-green-300 pb-2">
              ওয়েবসাইট পেইজ ও সাবপেইজ সমূহ
            </h2>

            <div className="space-y-6">
              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="text-xl font-semibold text-green-700 mb-2">
                  <Link href="/" className="text-blue-600 hover:underline">
                    হোম পেইজ
                  </Link>
                </h3>
                <p className="mb-2">
                  Trusted Ally Umrah & Hajj Services এর প্রধান প্রবেশদ্বার, যেখানে সংস্থার পরিচিতি, প্রধান সেবাসমূহ, জনপ্রিয় প্যাকেজ
                  এবং যোগাযোগের তথ্য রয়েছে।
                </p>
                <p>প্রধান বৈশিষ্ট্য: হিরো সেকশন, জনপ্রিয় প্যাকেজ, টেস্টিমোনিয়াল, কল টু অ্যাকশন বাটন</p>
              </div>

              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="text-xl font-semibold text-green-700 mb-2">
                  <Link href="/packages" className="text-blue-600 hover:underline">
                    প্যাকেজ পেইজ
                  </Link>
                </h3>
                <p className="mb-2">সকল উমরাহ ও হজ্জ প্যাকেজের বিস্তারিত তথ্য, মূল্য, সুবিধা এবং বুকিং অপশন সহ।</p>
                <p className="mb-2">উপলব্ধ প্যাকেজ সমূহ:</p>
                <ul className="list-disc pl-8 mb-2 space-y-1">
                  <li>
                    <Link href="/packages/7-day-economy" className="text-blue-600 hover:underline">
                      ৭ দিনের ইকোনমি উমরাহ প্যাকেজ
                    </Link>
                  </li>
                  <li>
                    <Link href="/packages/10-day-standard" className="text-blue-600 hover:underline">
                      ১০ দিনের স্ট্যান্ডার্ড উমরাহ প্যাকেজ
                    </Link>
                  </li>
                  <li>
                    <Link href="/packages/15-day-premium" className="text-blue-600 hover:underline">
                      ১৫ দিনের প্রিমিয়াম উমরাহ প্যাকেজ
                    </Link>
                  </li>
                  <li>
                    <Link href="/packages/hajj-package" className="text-blue-600 hover:underline">
                      সম্পূর্ণ হজ্জ প্যাকেজ ২০২৫
                    </Link>
                  </li>
                  <li>
                    <Link href="/packages/family-umrah" className="text-blue-600 hover:underline">
                      ফ্যামিলি উমরাহ প্যাকেজ
                    </Link>
                  </li>
                  <li>
                    <Link href="/packages/ramadan-umrah" className="text-blue-600 hover:underline">
                      রমজান উমরাহ স্পেশাল
                    </Link>
                  </li>
                </ul>
              </div>

              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="text-xl font-semibold text-green-700 mb-2">
                  <Link href="/services" className="text-blue-600 hover:underline">
                    সার্ভিসেস পেইজ
                  </Link>
                </h3>
                <p className="mb-2">Trusted Ally Umrah & Hajj Services দ্বারা প্রদত্ত সকল সেবার বিস্তারিত বিবরণ।</p>
                <p className="mb-2">প্রধান সেবাসমূহ:</p>
                <ul className="list-disc pl-8 mb-2 space-y-1">
                  <li>
                    <Link href="/services/transportation" className="text-blue-600 hover:underline">
                      ট্রান্সপোর্টেশন সার্ভিস
                    </Link>{" "}
                    - পবিত্র স্থানগুলোতে যাতায়াতের জন্য বিভিন্ন ধরনের পরিবহন সেবা
                  </li>
                  <li>
                    <Link href="/services/accommodation" className="text-blue-600 hover:underline">
                      আবাসন সেবা
                    </Link>{" "}
                    - মক্কা ও মদিনায় বিভিন্ন মানের হোটেল ও আবাসন ব্যবস্থা
                  </li>
                  <li>
                    <Link href="/services/dining" className="text-blue-600 hover:underline">
                      খাদ্য সেবা
                    </Link>{" "}
                    - বাংলাদেশী ও আন্তর্জাতিক খাবারের ব্যবস্থা
                  </li>
                  <li>
                    <Link href="/services/guided-tours" className="text-blue-600 hover:underline">
                      গাইডেড টুর
                    </Link>{" "}
                    - অভিজ্ঞ গাইডের সাথে ঐতিহাসিক স্থান পরিদর্শন
                  </li>
                  <li>
                    <Link href="/services/flights" className="text-blue-600 hover:underline">
                      ফ্লাইট সার্ভিস
                    </Link>{" "}
                    - বাংলাদেশ থেকে সৌদি আরব পর্যন্ত বিমান সেবা
                  </li>
                </ul>
              </div>

              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="text-xl font-semibold text-green-700 mb-2">
                  <Link href="/about" className="text-blue-600 hover:underline">
                    অ্যাবাউট পেইজ
                  </Link>
                </h3>
                <p className="mb-2">
                  Trusted Ally Umrah & Hajj Services এর পরিচিতি, মিশন, ভিশন এবং সেবা সম্পর্কিত বিস্তারিত তথ্য।
                </p>
                <p className="mb-2">সাবপেইজ:</p>
                <ul className="list-disc pl-8 mb-2 space-y-1">
                  <li>
                    <Link href="/about/management" className="text-blue-600 hover:underline">
                      ম্যানেজমেন্ট টিম
                    </Link>{" "}
                    - প্রতিষ্ঠানের পরিচালনা টিমের সদস্যদের পরিচিতি
                  </li>
                  <li>
                    <Link href="/about/profile" className="text-blue-600 hover:underline">
                      প্রোফাইল পেইজ
                    </Link>{" "}
                    - প্রতিষ্ঠানের বিস্তারিত প্রোফাইল (বর্তমান পেইজ)
                  </li>
                </ul>
              </div>

              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="text-xl font-semibold text-green-700 mb-2">
                  <Link href="/contact" className="text-blue-600 hover:underline">
                    কন্টাক্ট পেইজ
                  </Link>
                </h3>
                <p className="mb-2">যোগাযোগের বিভিন্ন মাধ্যম, অফিসের ঠিকানা, ফোন নম্বর, ইমেইল এবং কন্টাক্ট ফর্ম সহ।</p>
                <p>বৈশিষ্ট্য: ইন্টারেক্টিভ কন্টাক্ট ফর্ম, অফিস লোকেশন, অফিস আওয়ার্স</p>
              </div>

              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="text-xl font-semibold text-green-700 mb-2">
                  <Link href="/hajj-umrah-guidance" className="text-blue-600 hover:underline">
                    হজ্জ-উমরাহ গাইডেন্স পেইজ
                  </Link>
                </h3>
                <p className="mb-2">হজ্জ ও উমরাহ পালনের নিয়ম-কানুন, প্রস্তুতি, দোয়া এবং অন্যান্য গুরুত্বপূর্ণ তথ্য।</p>
                <p>বৈশিষ্ট্য: পবিত্র স্থানের তথ্য, আচরণবিধি, প্রশ্নোত্তর সেকশন</p>
              </div>

              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="text-xl font-semibold text-green-700 mb-2">
                  <Link href="/makkah" className="text-blue-600 hover:underline">
                    মক্কা পেইজ
                  </Link>
                </h3>
                <p className="mb-2">মক্কা শহর, মসজিদুল হারাম এবং আশেপাশের গুরুত্বপূর্ণ স্থান সম্পর্কে বিস্তারিত তথ্য।</p>
                <p className="mb-2">প্রধান সাবপেইজ সমূহ:</p>
                <ul className="list-disc pl-8 mb-2 space-y-1">
                  <li>
                    <Link href="/makkah/learn-more" className="text-blue-600 hover:underline">
                      আরও জানুন
                    </Link>
                  </li>
                  <li>
                    <Link href="/makkah/sanctuary" className="text-blue-600 hover:underline">
                      হারাম শরীফ
                    </Link>
                  </li>
                  <li>
                    <Link href="/makkah/kaaba" className="text-blue-600 hover:underline">
                      কাবা শরীফ
                    </Link>
                  </li>
                  <li>
                    <Link href="/makkah/zamzam" className="text-blue-600 hover:underline">
                      জমজম কূপ
                    </Link>
                  </li>
                  <li>
                    <Link href="/makkah/holy-sites" className="text-blue-600 hover:underline">
                      পবিত্র স্থানসমূহ
                    </Link>{" "}
                    (মিনা, আরাফাত, মুজদালিফা)
                  </li>
                  <li>
                    <Link href="/makkah/attractions" className="text-blue-600 hover:underline">
                      দর্শনীয় স্থানসমূহ
                    </Link>
                  </li>
                  <li>
                    <Link href="/makkah/services" className="text-blue-600 hover:underline">
                      সেবাসমূহ
                    </Link>
                  </li>
                </ul>
              </div>

              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="text-xl font-semibold text-green-700 mb-2">
                  <Link href="/madinah" className="text-blue-600 hover:underline">
                    মদিনা পেইজ
                  </Link>
                </h3>
                <p className="mb-2">মদিনা শহর, মসজিদে নববী এবং আশেপাশের ঐতিহাসিক স্থান সম্পর্কে বিস্তারিত তথ্য।</p>
                <p>বৈশিষ্ট্য: মসজিদে নববী, জান্নাতুল বাকি, কুবা মসজিদ, উহুদ পাহাড় সম্পর্কিত তথ্য</p>
              </div>

              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="text-xl font-semibold text-green-700 mb-2">
                  <Link href="/investment" className="text-blue-600 hover:underline">
                    ইনভেস্টমেন্ট পেইজ
                  </Link>
                </h3>
                <p className="mb-2">
                  Trusted Ally Umrah & Hajj Services এ বিনিয়োগের সুযোগ, প্যাকেজ এবং রিটার্ন সম্পর্কিত তথ্য।
                </p>
                <p className="mb-2">সাবপেইজ সমূহ:</p>
                <ul className="list-disc pl-8 mb-2 space-y-1">
                  <li>
                    <Link href="/investment/apply" className="text-blue-600 hover:underline">
                      বিনিয়োগ আবেদন
                    </Link>
                  </li>
                  <li>
                    <Link href="/investment/starter" className="text-blue-600 hover:underline">
                      স্টার্টার প্যাকেজ
                    </Link>
                  </li>
                  <li>
                    <Link href="/investment/premium" className="text-blue-600 hover:underline">
                      প্রিমিয়াম প্যাকেজ
                    </Link>
                  </li>
                  <li>
                    <Link href="/investment/enterprise" className="text-blue-600 hover:underline">
                      এন্টারপ্রাইজ প্যাকেজ
                    </Link>
                  </li>
                  <li>
                    <Link href="/investment/dividend-calculator" className="text-blue-600 hover:underline">
                      ডিভিডেন্ড ক্যালকুলেটর
                    </Link>
                  </li>
                </ul>
              </div>

              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="text-xl font-semibold text-green-700 mb-2">
                  <Link href="/investor" className="text-blue-600 hover:underline">
                    ইনভেস্টর পেইজ
                  </Link>
                </h3>
                <p className="mb-2">বিনিয়োগকারীদের জন্য লগইন এবং ড্যাশবোর্ড সিস্টেম।</p>
                <p className="mb-2">সাবপেইজ সমূহ:</p>
                <ul className="list-disc pl-8 mb-2 space-y-1">
                  <li>
                    <Link href="/investor/login" className="text-blue-600 hover:underline">
                      লগইন পেইজ
                    </Link>
                  </li>
                  <li>
                    <Link href="/investor/dashboard/[id]" className="text-blue-600 hover:underline">
                      ইনভেস্টর ড্যাশবোর্ড
                    </Link>
                  </li>
                  <li>
                    <Link href="/investor/emergency/[id]" className="text-blue-600 hover:underline">
                      ইমার্জেন্সি ড্যাশবোর্ড
                    </Link>
                  </li>
                  <li>
                    <Link href="/investor/agreements" className="text-blue-600 hover:underline">
                      চুক্তিপত্র
                    </Link>
                  </li>
                </ul>
              </div>

              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="text-xl font-semibold text-green-700 mb-2">বুকিং পেইজ সমূহ</h3>
                <p className="mb-2">বিভিন্ন সেবা বুকিং এর জন্য পেইজ সমূহ:</p>
                <ul className="list-disc pl-8 mb-2 space-y-1">
                  <li>
                    <Link href="/book/[id]" className="text-blue-600 hover:underline">
                      প্যাকেজ বুকিং
                    </Link>
                  </li>
                  <li>
                    <Link href="/book-accommodation/[id]" className="text-blue-600 hover:underline">
                      আবাসন বুকিং
                    </Link>
                  </li>
                  <li>
                    <Link href="/book-transportation/[id]" className="text-blue-600 hover:underline">
                      পরিবহন বুকিং
                    </Link>
                  </li>
                  <li>
                    <Link href="/book-haramain-train/[route]" className="text-blue-600 hover:underline">
                      হারামাইন ট্রেন বুকিং
                    </Link>
                  </li>
                  <li>
                    <Link href="/book-flight/[id]" className="text-blue-600 hover:underline">
                      ফ্লাইট বুকিং
                    </Link>
                  </li>
                </ul>
              </div>

              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="text-xl font-semibold text-green-700 mb-2">অন্যান্য পেইজ</h3>
                <ul className="list-disc pl-8 mb-2 space-y-1">
                  <li>
                    <Link href="/terms" className="text-blue-600 hover:underline">
                      টার্মস অ্যান্ড কন্ডিশনস
                    </Link>
                  </li>
                  <li>
                    <Link href="/privacy" className="text-blue-600 hover:underline">
                      প্রাইভেসি পলিসি
                    </Link>
                  </li>
                </ul>
              </div>
            </div>
          </section>

          <section className="mb-10">
            <h2 className="text-2xl font-bold text-green-700 mb-4 border-b border-green-300 pb-2">প্রধান কার্যক্রম সমূহ</h2>
            <div className="space-y-4">
              <div className="pl-4 border-l-2 border-green-500">
                <h3 className="text-xl font-semibold mb-2">উমরাহ সেবা</h3>
                <p className="mb-2">
                  বছরের যেকোনো সময় উমরাহ পালনের জন্য বিভিন্ন ধরনের প্যাকেজ প্রদান করা হয়। এর মধ্যে রয়েছে ইকোনমি, স্ট্যান্ডার্ড, প্রিমিয়াম,
                  ফ্যামিলি এবং রমজান স্পেশাল প্যাকেজ।
                </p>
                <p>প্রতিটি প্যাকেজে অন্তর্ভুক্ত: ভিসা প্রসেসিং, ফ্লাইট, হোটেল, পরিবহন, খাবার, গাইড সেবা এবং জিয়ারত ভ্রমণ।</p>
              </div>

              <div className="pl-4 border-l-2 border-green-500">
                <h3 className="text-xl font-semibold mb-2">হজ্জ সেবা</h3>
                <p className="mb-2">প্রতি বছর হজ্জ মৌসুমে বাংলাদেশী হাজীদের জন্য সম্পূর্ণ হজ্জ প্যাকেজ প্রদান করা হয়।</p>
                <p>
                  প্রতিটি হজ্জ প্যাকেজে অন্তর্ভুক্ত: হজ্জ ভিসা, ফ্লাইট, মক্কা ও মদিনায় হোটেল, মিনা-আরাফাত-মুজদালিফায় তাঁবু, সম্পূর্ণ খাবার, পরিবহন,
                  হজ্জ গাইড, প্রশিক্ষণ এবং মেডিকেল সাপোর্ট।
                </p>
              </div>

              <div className="pl-4 border-l-2 border-green-500">
                <h3 className="text-xl font-semibold mb-2">বিনিয়োগ সুযোগ</h3>
                <p className="mb-2">
                  Trusted Ally Umrah & Hajj Services বিনিয়োগকারীদের জন্য আকর্ষণীয় রিটার্ন সহ বিভিন্ন বিনিয়োগ প্যাকেজ প্রদান করে।
                </p>
                <p className="mb-2">প্রধান বিনিয়োগ প্যাকেজ:</p>
                <ul className="list-disc pl-8 mb-2 space-y-1">
                  <li>স্টার্টার প্যাকেজ - ৫ লাখ টাকা থেকে শুরু, বার্ষিক ১২% লাভাংশ</li>
                  <li>প্রিমিয়াম প্যাকেজ - ২৫ লাখ টাকা থেকে শুরু, বার্ষিক ১৮% লাভাংশ</li>
                  <li>এন্টারপ্রাইজ প্যাকেজ - ১ কোটি টাকা থেকে শুরু, বার্ষিক ২০% লাভাংশ</li>
                </ul>
                <p>বিনিয়োগকারীদের জন্য অনলাইন ড্যাশবোর্ড, নিয়মিত আপডেট, এবং উমরাহ-হজ্জ প্যাকেজে বিশেষ ছাড় প্রদান করা হয়।</p>
              </div>

              <div className="pl-4 border-l-2 border-green-500">
                <h3 className="text-xl font-semibold mb-2">পরিবহন সেবা</h3>
                <p className="mb-2">
                  জেদ্দা এয়ারপোর্ট থেকে মক্কা-মদিনা, মক্কা-মদিনা যাতায়াত, এবং পবিত্র স্থানগুলোতে ভ্রমণের জন্য বিভিন্ন ধরনের পরিবহন সেবা প্রদান
                  করা হয়।
                </p>
                <p>পরিবহন অপশন: প্রাইভেট কার, মাইক্রোবাস, মিনিবাস, বড় বাস, হারামাইন ট্রেন, হোলি সাইট টুর, ডেইলি হারাম ট্রান্সফার।</p>
              </div>

              <div className="pl-4 border-l-2 border-green-500">
                <h3 className="text-xl font-semibold mb-2">আবাসন সেবা</h3>
                <p className="mb-2">
                  মক্কা ও মদিনায় বিভিন্ন মানের হোটেল ও আবাসন ব্যবস্থা প্রদান করা হয়, যা যাত্রীদের বাজেট ও প্রয়োজন অনুযায়ী নির্বাচন করা যায়।
                </p>
                <p>আবাসন ক্যাটাগরি: ইকোনমি, মিড-রেঞ্জ, লাক্সারি। বিশেষ উমরাহ ও হজ্জ আবাসন প্যাকেজও রয়েছে।</p>
              </div>
            </div>
          </section>

          <section className="mb-10">
            <h2 className="text-2xl font-bold text-green-700 mb-4 border-b border-green-300 pb-2">
              TRUSTED-ALLY এর অন্যান্য প্রকল্প সমূহ
            </h2>
            <div className="space-y-4">
              <div className="bg-blue-50 p-4 rounded-lg">
                <h3 className="text-xl font-semibold text-blue-700 mb-2">
                  <Link
                    href="https://v0-trusted-ally-website-ten.vercel.app/"
                    className="text-blue-600 hover:underline"
                  >
                    TRUSTED-ALLY
                  </Link>
                </h3>
                <p className="mb-2">
                  TRUSTED-ALLY হল একটি বহুমুখী সংস্থা যা শিক্ষা, সামাজিক উন্নয়ন, এবং পরিবেশ সংরক্ষণের মাধ্যমে একটি উজ্জ্বল ভবিষ্যত গড়ার
                  লক্ষ্যে কাজ করে।
                </p>
                <p>স্লোগান: Together Towards a Brighter Future - সকলের সম্মিলিত প্রচেষ্টায় একটি উজ্জ্বল ভবিষ্যত গড়ার অঙ্গীকার।</p>
              </div>

              <div className="bg-blue-50 p-4 rounded-lg">
                <h3 className="text-xl font-semibold text-blue-700 mb-2">
                  <Link
                    href="https://v0-trusted-ally-website-ten.vercel.app/projects/al-quran-journey"
                    className="text-blue-600 hover:underline"
                  >
                    AlQuranJourney
                  </Link>
                </h3>
                <p className="mb-2">
                  AlQuranJourney হল একটি ডিজিটাল প্ল্যাটফর্ম যা কুরআন শিক্ষা, অনুবাদ, তাফসীর এবং ইসলামিক জ্ঞান প্রদানের মাধ্যমে মুসলিম
                  সম্প্রদায়কে সেবা প্রদান করে।
                </p>
                <p>বৈশিষ্ট্য: কুরআন শিক্ষা, অনলাইন ক্লাস, ইসলামিক রিসোর্স, কমিউনিটি ফোরাম।</p>
              </div>

              <div className="bg-blue-50 p-4 rounded-lg">
                <h3 className="text-xl font-semibold text-blue-700 mb-2">
                  <Link
                    href="https://v0-trusted-ally-website-ten.vercel.app/projects/techally-ventures"
                    className="text-blue-600 hover:underline"
                  >
                    TechAlly Ventures
                  </Link>
                </h3>
                <p className="mb-2">
                  TechAlly Ventures হল TRUSTED-ALLY এর টেকনোলজি-ফোকাসড প্রকল্প, যা ডিজিটাল সমাধান, সফটওয়্যার ডেভেলপমেন্ট, এবং টেক
                  স্টার্টআপ সাপোর্ট প্রদান করে।
                </p>
                <p>বৈশিষ্ট্য: টেক ইনকিউবেশন, সফটওয়্যার ডেভেলপমেন্ট, ডিজিটাল ট্রান্সফরমেশন কনসালটেন্সি।</p>
              </div>

              <div className="bg-blue-50 p-4 rounded-lg">
                <h3 className="text-xl font-semibold text-blue-700 mb-2">
                  <Link
                    href="https://v0-trusted-ally-website-ten.vercel.app/projects"
                    className="text-blue-600 hover:underline"
                  >
                    Ally Voyage
                  </Link>
                </h3>
                <p className="mb-2">
                  Ally Voyage হল TRUSTED-ALLY এর ট্রাভেল এবং টুরিজম প্রকল্প, যা বাংলাদেশ ও আন্তর্জাতিক ভ্রমণের জন্য বিভিন্ন সেবা প্রদান
                  করে।
                </p>
                <p>বৈশিষ্ট্য: ট্রাভেল প্যাকেজ, হোটেল বুকিং, ট্রান্সপোর্টেশন, গাইডেড টুর।</p>
              </div>

              <div className="bg-blue-50 p-4 rounded-lg">
                <h3 className="text-xl font-semibold text-blue-700 mb-2">
                  <Link
                    href="https://v0-trusted-ally-website-ten.vercel.app/education-program"
                    className="text-blue-600 hover:underline"
                  >
                    Education Program
                  </Link>
                </h3>
                <p className="mb-2">
                  TRUSTED-ALLY Education Program হল একটি শিক্ষামূলক উদ্যোগ যা বাংলাদেশের অনগ্রসর এলাকার শিশুদের জন্য মানসম্মত শিক্ষা
                  প্রদান করে।
                </p>
                <p>বৈশিষ্ট্য: স্কুল সাপোর্ট, শিক্ষা উপকরণ, স্কলারশিপ, টিচার ট্রেনিং।</p>
              </div>

              <div className="bg-blue-50 p-4 rounded-lg">
                <h3 className="text-xl font-semibold text-blue-700 mb-2">
                  <Link
                    href="https://v0-trusted-ally-website-ten.vercel.app/social-initiatives"
                    className="text-blue-600 hover:underline"
                  >
                    Social Initiatives
                  </Link>
                </h3>
                <p className="mb-2">
                  TRUSTED-ALLY Social Initiatives হল সামাজিক উন্নয়ন ও কল্যাণমূলক কার্যক্রম যা দরিদ্র ও সুবিধাবঞ্চিত জনগোষ্ঠীর জীবনমান
                  উন্নয়নে কাজ করে।
                </p>
                <p>বৈশিষ্ট্য: দারিদ্র্য বিমোচন, স্বাস্থ্যসেবা, নারী উন্নয়ন, যুব উন্নয়ন কার্যক্রম।</p>
              </div>

              <div className="bg-blue-50 p-4 rounded-lg">
                <h3 className="text-xl font-semibold text-blue-700 mb-2">
                  <Link
                    href="https://v0-trusted-ally-website-ten.vercel.app/environmental-development"
                    className="text-blue-600 hover:underline"
                  >
                    Environmental Development
                  </Link>
                </h3>
                <p className="mb-2">
                  TRUSTED-ALLY Environmental Development হল পরিবেশ সংরক্ষণ ও টেকসই উন্নয়নের লক্ষ্যে পরিচালিত প্রকল্প।
                </p>
                <p>বৈশিষ্ট্য: বৃক্ষরোপণ, পরিবেশ সচেতনতা, বর্জ্য ব্যবস্থাপনা, নবায়নযোগ্য শক্তি প্রকল্প।</p>
              </div>

              <div className="bg-blue-50 p-4 rounded-lg">
                <h3 className="text-xl font-semibold text-blue-700 mb-2">
                  <Link
                    href="https://v0-cox-bazar-travel-project.vercel.app/"
                    className="text-blue-600 hover:underline"
                  >
                    Discover Cox's Bazar
                  </Link>
                </h3>
                <p className="mb-2">
                  Discover Cox's Bazar হল TRUSTED-ALLY এর একটি টুরিজম প্রকল্প, যা বাংলাদেশের সবচেয়ে জনপ্রিয় পর্যটন কেন্দ্র
                  কক্সবাজারের প্রচার ও উন্নয়নে কাজ করে।
                </p>
                <p>বৈশিষ্ট্য: ট্রাভেল গাইড, হোটেল বুকিং, টুর প্যাকেজ, লোকাল এক্সপেরিয়েন্স।</p>
              </div>
            </div>
          </section>

          <section className="mb-10">
            <h2 className="text-2xl font-bold text-green-700 mb-4 border-b border-green-300 pb-2">
              যোগাযোগ ও অফিস লোকেশন
            </h2>
            <div className="grid md:grid-cols-2 gap-6">
              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="text-xl font-semibold mb-3">যুক্তরাজ্য অফিস</h3>
                <p className="mb-1">121 Islamic Center, Ally Street, UK</p>
                <p className="mb-1">ফোন: +44 14 40574345</p>
                <p className="mb-1">ইমেইল: mjahmad2024@outlook.com</p>
                <p className="mb-3">অফিস আওয়ার্স: সোমবার-শুক্রবার (৯:০০ AM - ৬:০০ PM), শনিবার (১০:০০ AM - ৪:০০ PM)</p>
              </div>

              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="text-xl font-semibold mb-3">বাংলাদেশ অফিস</h3>
                <p className="mb-1">Quraner Fariwala, 27 Purana Pantan, Dhaka -1000</p>
                <p className="mb-1">ফোন: +880 1892051303</p>
                <p className="mb-1">ইমেইল: info@t-ally-umrah.com</p>
                <p className="mb-3">অফিস আওয়ার্স: সোমবার-শুক্রবার (৯:০০ AM - ৬:০০ PM), শনিবার (১০:০০ AM - ৪:০০ PM)</p>
              </div>
            </div>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-green-700 mb-4 border-b border-green-300 pb-2">ভবিষ্যৎ পরিকল্পনা</h2>
            <div className="pl-4 border-l-2 border-green-500 space-y-4">
              <div>
                <h3 className="text-xl font-semibold mb-2">সেবা সম্প্রসারণ</h3>
                <p>
                  আগামী বছরগুলোতে Trusted Ally Umrah & Hajj Services আরও বেশি সংখ্যক যাত্রীকে সেবা প্রদানের লক্ষ্যে কাজ করছে। ২০২৫
                  সালের মধ্যে বার্ষিক ১০,০০০ যাত্রী এবং ২০৩০ সালের মধ্যে ২৫,০০০ যাত্রীকে সেবা প্রদানের লক্ষ্যমাত্রা নির্ধারণ করা হয়েছে।
                </p>
              </div>

              <div>
                <h3 className="text-xl font-semibold mb-2">ডিজিটাল ট্রান্সফরমেশন</h3>
                <p>
                  সম্পূর্ণ ডিজিটাল প্ল্যাটফর্ম তৈরি করে যাত্রীদের জন্য অনলাইন বুকিং, পেমেন্ট, ট্র্যাকিং, এবং সাপোর্ট সিস্টেম আরও উন্নত করা
                  হবে। মোবাইল অ্যাপ ডেভেলপমেন্ট এবং AI-ভিত্তিক কাস্টমার সাপোর্ট সিস্টেম চালু করার পরিকল্পনা রয়েছে।
                </p>
              </div>

              <div>
                <h3 className="text-xl font-semibold mb-2">নিজস্ব অবকাঠামো উন্নয়ন</h3>
                <p>
                  মক্কা ও মদিনায় নিজস্ব হোটেল ও পরিবহন ব্যবস্থা স্থাপনের মাধ্যমে সেবার মান আরও উন্নত করা এবং খরচ কমানোর পরিকল্পনা রয়েছে।
                  এছাড়া বাংলাদেশে আরও শাখা অফিস খোলার পরিকল্পনাও রয়েছে।
                </p>
              </div>

              <div>
                <h3 className="text-xl font-semibold mb-2">সামাজিক দায়বদ্ধতা</h3>
                <p>
                  প্রতি বছর নির্দিষ্ট সংখ্যক অসচ্ছল ব্যক্তিদের বিনামূল্যে উমরাহ করানোর জন্য "উমরাহ ফর অল" প্রোগ্রাম চালু করার পরিকল্পনা রয়েছে।
                  এছাড়া পরিবেশ বান্ধব "গ্রিন হজ্জ" ইনিশিয়েটিভ চালু করার পরিকল্পনাও রয়েছে।
                </p>
              </div>
            </div>
          </section>
        </div>
      </div>
    </div>
  )
}

