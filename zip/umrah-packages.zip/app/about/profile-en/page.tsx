import Link from "next/link"

export default function ProfilePageEnglish() {
  return (
    <div className="min-h-screen bg-white">
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-5xl mx-auto">
          <h1 className="text-3xl md:text-4xl font-bold text-green-700 mb-6 border-b-2 border-green-600 pb-2">
            Trusted Ally Umrah & Hajj Services - Profile
          </h1>

          <div className="bg-green-50 p-6 rounded-lg mb-8">
            <h2 className="text-xl font-bold text-green-800 mb-3">Brief Introduction</h2>
            <p className="mb-4">
              <strong>Trusted Ally Umrah & Hajj Services</strong> is one of the prominent projects of{" "}
              <Link href="https://v0-trusted-ally-website-ten.vercel.app/" className="text-blue-600 hover:underline">
                TRUSTED-ALLY
              </Link>{" "}
              that provides Umrah and Hajj services for Bangladeshi Muslims. This service offers complete solutions for
              travel, accommodation, and religious activities in the holy cities of Makkah and Madinah.
            </p>
            <div className="border-l-4 border-green-600 pl-4 py-2 bg-green-100 mb-4">
              <p className="italic">
                <span className="font-semibold">TRUSTED-ALLY Slogan:</span> Together Towards a Brighter Future
              </p>
              <p className="mt-2">
                <span className="font-semibold">Mission:</span> Be the Change You Wish to See
              </p>
            </div>
            <p>
              At TRUSTED-ALLY, we believe in the power of collective effort to shape a brighter tomorrow. This is your
              opportunity to be part of a movement that inspires, educates, and uplifts. Whether you dream of empowering
              young minds through education, driving impactful social initiatives, or protecting our planet for future
              generations—your contribution matters. Together, we can break barriers, ignite hope, and create lasting
              change.
            </p>
          </div>

          <section className="mb-10">
            <h2 className="text-2xl font-bold text-green-700 mb-4 border-b border-green-300 pb-2">
              Trusted Ally Umrah & Hajj Services - Objectives and Goals
            </h2>
            <div className="pl-4 border-l-2 border-green-500">
              <h3 className="text-xl font-semibold mb-2">Main Objectives</h3>
              <ul className="list-disc pl-5 mb-4 space-y-2">
                <li>Ensure easy, safe, and spiritually enriching Umrah and Hajj journeys for Bangladeshi Muslims</li>
                <li>Provide high-quality services at affordable prices</li>
                <li>Assist pilgrims in their religious practices and enhance their spiritual experience</li>
                <li>Ensure safe and comfortable accommodation at the holy sites</li>
              </ul>

              <h3 className="text-xl font-semibold mb-2">Long-term Goals</h3>
              <ul className="list-disc pl-5 mb-4 space-y-2">
                <li>Achieve a leading position among Umrah and Hajj service providers in Bangladesh</li>
                <li>Serve at least 10,000 pilgrims annually</li>
                <li>Make the service delivery process easier and more transparent through digital platforms</li>
                <li>Ensure high returns for investors</li>
              </ul>
            </div>
          </section>

          <section className="mb-10">
            <h2 className="text-2xl font-bold text-green-700 mb-4 border-b border-green-300 pb-2">
              Website Pages and Subpages
            </h2>

            <div className="space-y-6">
              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="text-xl font-semibold text-green-700 mb-2">
                  <Link href="/" className="text-blue-600 hover:underline">
                    Home Page
                  </Link>
                </h3>
                <p className="mb-2">
                  The main gateway to Trusted Ally Umrah & Hajj Services, featuring the organization&apos;s
                  introduction, main services, popular packages, and contact information.
                </p>
                <p>Key features: Hero section, popular packages, testimonials, call-to-action buttons</p>
              </div>

              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="text-xl font-semibold text-green-700 mb-2">
                  <Link href="/packages" className="text-blue-600 hover:underline">
                    Packages Page
                  </Link>
                </h3>
                <p className="mb-2">
                  Detailed information about all Umrah and Hajj packages, including prices, benefits, and booking
                  options.
                </p>
                <p className="mb-2">Available packages:</p>
                <ul className="list-disc pl-8 mb-2 space-y-1">
                  <li>
                    <Link href="/packages/7-day-economy" className="text-blue-600 hover:underline">
                      7-Day Economy Umrah Package
                    </Link>
                  </li>
                  <li>
                    <Link href="/packages/10-day-standard" className="text-blue-600 hover:underline">
                      10-Day Standard Umrah Package
                    </Link>
                  </li>
                  <li>
                    <Link href="/packages/15-day-premium" className="text-blue-600 hover:underline">
                      15-Day Premium Umrah Package
                    </Link>
                  </li>
                  <li>
                    <Link href="/packages/hajj-package" className="text-blue-600 hover:underline">
                      Complete Hajj Package 2025
                    </Link>
                  </li>
                  <li>
                    <Link href="/packages/family-umrah" className="text-blue-600 hover:underline">
                      Family Umrah Package
                    </Link>
                  </li>
                  <li>
                    <Link href="/packages/ramadan-umrah" className="text-blue-600 hover:underline">
                      Ramadan Umrah Special
                    </Link>
                  </li>
                </ul>
              </div>

              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="text-xl font-semibold text-green-700 mb-2">
                  <Link href="/services" className="text-blue-600 hover:underline">
                    Services Page
                  </Link>
                </h3>
                <p className="mb-2">
                  Detailed description of all services provided by Trusted Ally Umrah & Hajj Services.
                </p>
                <p className="mb-2">Main services:</p>
                <ul className="list-disc pl-8 mb-2 space-y-1">
                  <li>
                    <Link href="/services/transportation" className="text-blue-600 hover:underline">
                      Transportation Service
                    </Link>{" "}
                    - Various transportation options for travel to and within the holy sites
                  </li>
                  <li>
                    <Link href="/services/accommodation" className="text-blue-600 hover:underline">
                      Accommodation Service
                    </Link>{" "}
                    - Various quality hotels and accommodation options in Makkah and Madinah
                  </li>
                  <li>
                    <Link href="/services/dining" className="text-blue-600 hover:underline">
                      Dining Service
                    </Link>{" "}
                    - Bangladeshi and international food options
                  </li>
                  <li>
                    <Link href="/services/guided-tours" className="text-blue-600 hover:underline">
                      Guided Tours
                    </Link>{" "}
                    - Visiting historical sites with experienced guides
                  </li>
                  <li>
                    <Link href="/services/flights" className="text-blue-600 hover:underline">
                      Flight Service
                    </Link>{" "}
                    - Air travel from Bangladesh to Saudi Arabia
                  </li>
                </ul>
              </div>

              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="text-xl font-semibold text-green-700 mb-2">
                  <Link href="/about" className="text-blue-600 hover:underline">
                    About Page
                  </Link>
                </h3>
                <p className="mb-2">
                  Introduction, mission, vision, and detailed information about Trusted Ally Umrah & Hajj Services.
                </p>
                <p className="mb-2">Subpages:</p>
                <ul className="list-disc pl-8 mb-2 space-y-1">
                  <li>
                    <Link href="/about/management" className="text-blue-600 hover:underline">
                      Management Team
                    </Link>{" "}
                    - Introduction to the organization&apos;s management team members
                  </li>
                  <li>
                    <Link href="/about/profile" className="text-blue-600 hover:underline">
                      Profile Page (Bengali)
                    </Link>{" "}
                    - Detailed profile of the organization
                  </li>
                  <li>
                    <Link href="/about/profile-en" className="text-blue-600 hover:underline">
                      Profile Page (English)
                    </Link>{" "}
                    - Detailed profile of the organization in English (current page)
                  </li>
                </ul>
              </div>

              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="text-xl font-semibold text-green-700 mb-2">
                  <Link href="/contact" className="text-blue-600 hover:underline">
                    Contact Page
                  </Link>
                </h3>
                <p className="mb-2">
                  Various contact methods, office addresses, phone numbers, email, and contact form.
                </p>
                <p>Features: Interactive contact form, office location, office hours</p>
              </div>

              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="text-xl font-semibold text-green-700 mb-2">
                  <Link href="/hajj-umrah-guidance" className="text-blue-600 hover:underline">
                    Hajj-Umrah Guidance Page
                  </Link>
                </h3>
                <p className="mb-2">
                  Rules and regulations for performing Hajj and Umrah, preparations, prayers, and other important
                  information.
                </p>
                <p>Features: Information about holy sites, code of conduct, Q&A section</p>
              </div>

              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="text-xl font-semibold text-green-700 mb-2">
                  <Link href="/makkah" className="text-blue-600 hover:underline">
                    Makkah Page
                  </Link>
                </h3>
                <p className="mb-2">
                  Detailed information about Makkah city, Masjid al-Haram, and important surrounding locations.
                </p>
                <p className="mb-2">Main subpages:</p>
                <ul className="list-disc pl-8 mb-2 space-y-1">
                  <li>
                    <Link href="/makkah/learn-more" className="text-blue-600 hover:underline">
                      Learn More
                    </Link>
                  </li>
                  <li>
                    <Link href="/makkah/sanctuary" className="text-blue-600 hover:underline">
                      Haram Sharif
                    </Link>
                  </li>
                  <li>
                    <Link href="/makkah/kaaba" className="text-blue-600 hover:underline">
                      Kaaba
                    </Link>
                  </li>
                  <li>
                    <Link href="/makkah/zamzam" className="text-blue-600 hover:underline">
                      Zamzam Well
                    </Link>
                  </li>
                  <li>
                    <Link href="/makkah/holy-sites" className="text-blue-600 hover:underline">
                      Holy Sites
                    </Link>{" "}
                    (Mina, Arafat, Muzdalifah)
                  </li>
                  <li>
                    <Link href="/makkah/attractions" className="text-blue-600 hover:underline">
                      Attractions
                    </Link>
                  </li>
                  <li>
                    <Link href="/makkah/services" className="text-blue-600 hover:underline">
                      Services
                    </Link>
                  </li>
                </ul>
              </div>

              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="text-xl font-semibold text-green-700 mb-2">
                  <Link href="/madinah" className="text-blue-600 hover:underline">
                    Madinah Page
                  </Link>
                </h3>
                <p className="mb-2">
                  Detailed information about Madinah city, Masjid al-Nabawi, and surrounding historical sites.
                </p>
                <p>Features: Information about Masjid al-Nabawi, Jannatul Baqi, Quba Mosque, Mount Uhud</p>
              </div>

              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="text-xl font-semibold text-green-700 mb-2">
                  <Link href="/investment" className="text-blue-600 hover:underline">
                    Investment Page
                  </Link>
                </h3>
                <p className="mb-2">
                  Information about investment opportunities, packages, and returns at Trusted Ally Umrah & Hajj
                  Services.
                </p>
                <p className="mb-2">Subpages:</p>
                <ul className="list-disc pl-8 mb-2 space-y-1">
                  <li>
                    <Link href="/investment/apply" className="text-blue-600 hover:underline">
                      Investment Application
                    </Link>
                  </li>
                  <li>
                    <Link href="/investment/starter" className="text-blue-600 hover:underline">
                      Starter Package
                    </Link>
                  </li>
                  <li>
                    <Link href="/investment/premium" className="text-blue-600 hover:underline">
                      Premium Package
                    </Link>
                  </li>
                  <li>
                    <Link href="/investment/enterprise" className="text-blue-600 hover:underline">
                      Enterprise Package
                    </Link>
                  </li>
                  <li>
                    <Link href="/investment/dividend-calculator" className="text-blue-600 hover:underline">
                      Dividend Calculator
                    </Link>
                  </li>
                </ul>
              </div>

              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="text-xl font-semibold text-green-700 mb-2">
                  <Link href="/investor" className="text-blue-600 hover:underline">
                    Investor Page
                  </Link>
                </h3>
                <p className="mb-2">Login and dashboard system for investors.</p>
                <p className="mb-2">Subpages:</p>
                <ul className="list-disc pl-8 mb-2 space-y-1">
                  <li>
                    <Link href="/investor/login" className="text-blue-600 hover:underline">
                      Login Page
                    </Link>
                  </li>
                  <li>
                    <Link href="/investor/dashboard/[id]" className="text-blue-600 hover:underline">
                      Investor Dashboard
                    </Link>
                  </li>
                  <li>
                    <Link href="/investor/emergency/[id]" className="text-blue-600 hover:underline">
                      Emergency Dashboard
                    </Link>
                  </li>
                  <li>
                    <Link href="/investor/agreements" className="text-blue-600 hover:underline">
                      Agreements
                    </Link>
                  </li>
                </ul>
              </div>

              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="text-xl font-semibold text-green-700 mb-2">Booking Pages</h3>
                <p className="mb-2">Pages for booking various services:</p>
                <ul className="list-disc pl-8 mb-2 space-y-1">
                  <li>
                    <Link href="/book/[id]" className="text-blue-600 hover:underline">
                      Package Booking
                    </Link>
                  </li>
                  <li>
                    <Link href="/book-accommodation/[id]" className="text-blue-600 hover:underline">
                      Accommodation Booking
                    </Link>
                  </li>
                  <li>
                    <Link href="/book-transportation/[id]" className="text-blue-600 hover:underline">
                      Transportation Booking
                    </Link>
                  </li>
                  <li>
                    <Link href="/book-haramain-train/[route]" className="text-blue-600 hover:underline">
                      Haramain Train Booking
                    </Link>
                  </li>
                  <li>
                    <Link href="/book-flight/[id]" className="text-blue-600 hover:underline">
                      Flight Booking
                    </Link>
                  </li>
                </ul>
              </div>

              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="text-xl font-semibold text-green-700 mb-2">Other Pages</h3>
                <ul className="list-disc pl-8 mb-2 space-y-1">
                  <li>
                    <Link href="/terms" className="text-blue-600 hover:underline">
                      Terms and Conditions
                    </Link>
                  </li>
                  <li>
                    <Link href="/privacy" className="text-blue-600 hover:underline">
                      Privacy Policy
                    </Link>
                  </li>
                </ul>
              </div>
            </div>
          </section>

          <section className="mb-10">
            <h2 className="text-2xl font-bold text-green-700 mb-4 border-b border-green-300 pb-2">Main Activities</h2>
            <div className="space-y-4">
              <div className="pl-4 border-l-2 border-green-500">
                <h3 className="text-xl font-semibold mb-2">Umrah Services</h3>
                <p className="mb-2">
                  Various types of packages are provided for performing Umrah throughout the year. These include
                  Economy, Standard, Premium, Family, and Ramadan Special packages.
                </p>
                <p>
                  Each package includes: Visa processing, flights, hotels, transportation, meals, guide services, and
                  ziyarat tours.
                </p>
              </div>

              <div className="pl-4 border-l-2 border-green-500">
                <h3 className="text-xl font-semibold mb-2">Hajj Services</h3>
                <p className="mb-2">
                  Complete Hajj packages are provided for Bangladeshi pilgrims during the Hajj season every year.
                </p>
                <p>
                  Each Hajj package includes: Hajj visa, flights, hotels in Makkah and Madinah, tents in
                  Mina-Arafat-Muzdalifah, complete meals, transportation, Hajj guide, training, and medical support.
                </p>
              </div>

              <div className="pl-4 border-l-2 border-green-500">
                <h3 className="text-xl font-semibold mb-2">Investment Opportunities</h3>
                <p className="mb-2">
                  Trusted Ally Umrah & Hajj Services offers various investment packages with attractive returns for
                  investors.
                </p>
                <p className="mb-2">Main investment packages:</p>
                <ul className="list-disc pl-8 mb-2 space-y-1">
                  <li>Starter Package - Starting from 5 lakh BDT, 12% annual dividend</li>
                  <li>Premium Package - Starting from 25 lakh BDT, 18% annual dividend</li>
                  <li>Enterprise Package - Starting from 1 crore BDT, 20% annual dividend</li>
                </ul>
                <p>
                  Investors receive online dashboard access, regular updates, and special discounts on Umrah-Hajj
                  packages.
                </p>
              </div>

              <div className="pl-4 border-l-2 border-green-500">
                <h3 className="text-xl font-semibold mb-2">Transportation Services</h3>
                <p className="mb-2">
                  Various transportation services are provided for travel from Jeddah Airport to Makkah-Madinah, between
                  Makkah-Madinah, and for visiting the holy sites.
                </p>
                <p>
                  Transportation options: Private cars, microbuses, minibuses, large buses, Haramain Train, Holy Site
                  tours, daily Haram transfers.
                </p>
              </div>

              <div className="pl-4 border-l-2 border-green-500">
                <h3 className="text-xl font-semibold mb-2">Accommodation Services</h3>
                <p className="mb-2">
                  Various quality hotels and accommodation options are provided in Makkah and Madinah, which can be
                  selected according to pilgrims&apos; budget and needs.
                </p>
                <p>
                  Accommodation categories: Economy, Mid-range, Luxury. Special Umrah and Hajj accommodation packages
                  are also available.
                </p>
              </div>
            </div>
          </section>

          <section className="mb-10">
            <h2 className="text-2xl font-bold text-green-700 mb-4 border-b border-green-300 pb-2">
              Other TRUSTED-ALLY Projects
            </h2>
            <div className="space-y-4">
              <div className="bg-blue-50 p-4 rounded-lg">
                <h3 className="text-xl font-semibold text-blue-700 mb-2">
                  <Link
                    href="https://v0-trusted-ally-website-ten.vercel.app/"
                    className="text-blue-600 hover:underline"
                  >
                    TRUSTED-ALLY
                  </Link>
                </h3>
                <p className="mb-2">
                  TRUSTED-ALLY is a multifaceted organization working towards building a brighter future through
                  education, social development, and environmental conservation.
                </p>
                <p>
                  Slogan: Together Towards a Brighter Future - A commitment to building a brighter future through
                  collective efforts.
                </p>
              </div>

              <div className="bg-blue-50 p-4 rounded-lg">
                <h3 className="text-xl font-semibold text-blue-700 mb-2">
                  <Link
                    href="https://v0-trusted-ally-website-ten.vercel.app/projects/al-quran-journey"
                    className="text-blue-600 hover:underline"
                  >
                    AlQuranJourney
                  </Link>
                </h3>
                <p className="mb-2">
                  AlQuranJourney is a digital platform that serves the Muslim community by providing Quran education,
                  translation, tafsir, and Islamic knowledge.
                </p>
                <p>Features: Quran education, online classes, Islamic resources, community forum.</p>
              </div>

              <div className="bg-blue-50 p-4 rounded-lg">
                <h3 className="text-xl font-semibold text-blue-700 mb-2">
                  <Link
                    href="https://v0-trusted-ally-website-ten.vercel.app/projects/techally-ventures"
                    className="text-blue-600 hover:underline"
                  >
                    TechAlly Ventures
                  </Link>
                </h3>
                <p className="mb-2">
                  TechAlly Ventures is TRUSTED-ALLY&apos;s technology-focused project that provides digital solutions,
                  software development, and tech startup support.
                </p>
                <p>Features: Tech incubation, software development, digital transformation consultancy.</p>
              </div>

              <div className="bg-blue-50 p-4 rounded-lg">
                <h3 className="text-xl font-semibold text-blue-700 mb-2">
                  <Link
                    href="https://v0-trusted-ally-website-ten.vercel.app/projects"
                    className="text-blue-600 hover:underline"
                  >
                    Ally Voyage
                  </Link>
                </h3>
                <p className="mb-2">
                  Ally Voyage is TRUSTED-ALLY&apos;s travel and tourism project that provides various services for
                  domestic and international travel.
                </p>
                <p>Features: Travel packages, hotel booking, transportation, guided tours.</p>
              </div>

              <div className="bg-blue-50 p-4 rounded-lg">
                <h3 className="text-xl font-semibold text-blue-700 mb-2">
                  <Link
                    href="https://v0-trusted-ally-website-ten.vercel.app/education-program"
                    className="text-blue-600 hover:underline"
                  >
                    Education Program
                  </Link>
                </h3>
                <p className="mb-2">
                  TRUSTED-ALLY Education Program is an educational initiative that provides quality education for
                  children in underprivileged areas of Bangladesh.
                </p>
                <p>Features: School support, educational materials, scholarships, teacher training.</p>
              </div>

              <div className="bg-blue-50 p-4 rounded-lg">
                <h3 className="text-xl font-semibold text-blue-700 mb-2">
                  <Link
                    href="https://v0-trusted-ally-website-ten.vercel.app/social-initiatives"
                    className="text-blue-600 hover:underline"
                  >
                    Social Initiatives
                  </Link>
                </h3>
                <p className="mb-2">
                  TRUSTED-ALLY Social Initiatives are social development and welfare activities that work to improve the
                  living standards of poor and disadvantaged communities.
                </p>
                <p>Features: Poverty alleviation, healthcare, women&apos;s development, youth development programs.</p>
              </div>

              <div className="bg-blue-50 p-4 rounded-lg">
                <h3 className="text-xl font-semibold text-blue-700 mb-2">
                  <Link
                    href="https://v0-trusted-ally-website-ten.vercel.app/environmental-development"
                    className="text-blue-600 hover:underline"
                  >
                    Environmental Development
                  </Link>
                </h3>
                <p className="mb-2">
                  TRUSTED-ALLY Environmental Development is a project conducted for environmental conservation and
                  sustainable development.
                </p>
                <p>Features: Tree planting, environmental awareness, waste management, renewable energy projects.</p>
              </div>

              <div className="bg-blue-50 p-4 rounded-lg">
                <h3 className="text-xl font-semibold text-blue-700 mb-2">
                  <Link
                    href="https://v0-cox-bazar-travel-project.vercel.app/"
                    className="text-blue-600 hover:underline"
                  >
                    Discover Cox&apos;s Bazar
                  </Link>
                </h3>
                <p className="mb-2">
                  Discover Cox&apos;s Bazar is a tourism project of TRUSTED-ALLY that works to promote and develop
                  Bangladesh&apos;s most popular tourist destination, Cox&apos;s Bazar.
                </p>
                <p>Features: Travel guide, hotel booking, tour packages, local experiences.</p>
              </div>
            </div>
          </section>

          <section className="mb-10">
            <h2 className="text-2xl font-bold text-green-700 mb-4 border-b border-green-300 pb-2">
              Contact and Office Locations
            </h2>
            <div className="grid md:grid-cols-2 gap-6">
              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="text-xl font-semibold mb-3">UK Office</h3>
                <p className="mb-1">121 Islamic Center, Ally Street, UK</p>
                <p className="mb-1">Phone: +44 14 40574345</p>
                <p className="mb-1">Email: mjahmad2024@outlook.com</p>
                <p className="mb-3">Office Hours: Monday-Friday (9:00 AM - 6:00 PM), Saturday (10:00 AM - 4:00 PM)</p>
              </div>

              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="text-xl font-semibold mb-3">Bangladesh Office</h3>
                <p className="mb-1">Quraner Fariwala, 27 Purana Pantan, Dhaka -1000</p>
                <p className="mb-1">Phone: +880 1892051303</p>
                <p className="mb-1">Email: info@t-ally-umrah.com</p>
                <p className="mb-3">Office Hours: Monday-Friday (9:00 AM - 6:00 PM), Saturday (10:00 AM - 4:00 PM)</p>
              </div>
            </div>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-green-700 mb-4 border-b border-green-300 pb-2">Future Plans</h2>
            <div className="pl-4 border-l-2 border-green-500 space-y-4">
              <div>
                <h3 className="text-xl font-semibold mb-2">Service Expansion</h3>
                <p>
                  In the coming years, Trusted Ally Umrah & Hajj Services is working to serve more pilgrims. The target
                  is to serve 10,000 pilgrims annually by 2025 and 25,000 pilgrims annually by 2030.
                </p>
              </div>

              <div>
                <h3 className="text-xl font-semibold mb-2">Digital Transformation</h3>
                <p>
                  By creating a complete digital platform, the online booking, payment, tracking, and support systems
                  will be further improved for pilgrims. There are plans to launch mobile app development and AI-based
                  customer support systems.
                </p>
              </div>

              <div>
                <h3 className="text-xl font-semibold mb-2">Infrastructure Development</h3>
                <p>
                  There are plans to establish our own hotels and transportation systems in Makkah and Madinah to
                  further improve service quality and reduce costs. There are also plans to open more branch offices in
                  Bangladesh.
                </p>
              </div>

              <div>
                <h3 className="text-xl font-semibold mb-2">Social Responsibility</h3>
                <p>
                  There are plans to launch an "Umrah for All" program to provide free Umrah for a certain number of
                  underprivileged individuals each year. There are also plans to launch an environmentally friendly
                  "Green Hajj" initiative.
                </p>
              </div>
            </div>
          </section>
        </div>
      </div>
    </div>
  )
}

