import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "TRUSTED-ALLY Umrah & Hajj Services",
  description: "Umrah Packages for Bangladeshi Pilgrims",
  keywords: "Umrah Packages for Bangladeshi Pilgrims",
  icons: {
    icon: "/icon.png",
  },
  openGraph: {
    description: "Umrah Packages for Bangladeshi Pilgrims",
    images: [
      {
        url: "https://mj-ahmad.github.io/mja2025/img/tr000.png",
        width: 1200,
        height: 630,
        alt: "Umrah & Hajj Services for Bangladeshi Pilgrims",
      },
    ],
  },
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en">
      <body className={inter.className}>{children}</body>
    </html>
  )
}



import './globals.css'