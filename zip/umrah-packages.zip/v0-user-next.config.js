/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    domains: ["mj-ahmad.github.io", "www.nusuk.sa", "v0.blob.com"],
  },
}

module.exports = nextConfig

