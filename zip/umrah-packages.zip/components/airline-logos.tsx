import Image from "next/image"

interface AirlineLogoProps {
  airline: string
  width?: number
  height?: number
  className?: string
}

export function AirlineLogo({ airline, width = 120, height = 40, className = "" }: AirlineLogoProps) {
  const getAirlineLogo = (airline: string): string => {
    const logos: Record<string, string> = {
      "Biman Bangladesh": "https://mj-ahmad.github.io/mja2025/img/biman-logo.png",
      Emirates: "https://mj-ahmad.github.io/mja2025/img/emirates-logo.png",
      Flynas: "https://mj-ahmad.github.io/mja2025/img/flynas-logo.png",
      "Qatar Airways": "https://mj-ahmad.github.io/mja2025/img/qatar-logo.png",
      Saudia: "https://mj-ahmad.github.io/mja2025/img/saudia-logo.png",
      "US-Bangla Airlines": "https://mj-ahmad.github.io/mja2025/img/usbangla-logo.png",
    }
    return logos[airline] || "/placeholder.svg?height=40&width=120"
  }

  return (
    <div className={`relative ${className}`} style={{ width, height }}>
      <Image
        src={getAirlineLogo(airline) || "/placeholder.svg"}
        alt={`${airline} logo`}
        fill
        className="object-contain"
      />
    </div>
  )
}

