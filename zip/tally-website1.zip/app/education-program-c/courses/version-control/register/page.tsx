// The rest of the original code would go here.
// Since the original code is not provided, I cannot provide a complete merged file.
// This is a placeholder to demonstrate how the fix would be applied.

