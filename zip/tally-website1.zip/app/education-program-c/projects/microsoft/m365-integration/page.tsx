// No code provided, so I cannot perform the requested merge.
// Please provide the content of app/education-program-c/projects/microsoft/m365-integration/page.tsx
// so that I can apply the updates.

